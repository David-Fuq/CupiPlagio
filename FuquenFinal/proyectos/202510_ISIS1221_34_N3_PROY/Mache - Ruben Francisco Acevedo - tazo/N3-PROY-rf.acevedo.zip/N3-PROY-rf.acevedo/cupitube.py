#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    lista_dicc = {}
    archivo = open(archivo, "r", encoding="utf-8")
    titulos = archivo.readline().strip().split(",")
    print(titulos)
    
    linea = archivo.readline().strip()
    while len(linea) > 0:
        pais_lista = []
        datos = linea.split(",")
        pais = datos[7]
        
        cupituber = {}
        cupituber["rank"] = int(datos[0])
        cupituber["cupituber"] = datos[1]
        cupituber["subscribers"] = int(datos[2])
        cupituber["video_views"] = int(datos[3])
        cupituber["video_count"] = int(datos[4])
        cupituber["category"] = datos[5]
        cupituber["started"] = datos[6]
        cupituber["monetization_type"] = datos[8]
        cupituber["description"] = datos[9]
        
        pais_lista.append(cupituber)
        
        if pais in lista_dicc:
            lista_dicc[pais] += pais_lista
            
        else:
            lista_dicc[pais] = pais_lista
            
        linea = archivo.readline().strip()
        
    archivo.close()
    return lista_dicc

lista_dicc = cargar_cupitube("cupitube.csv")
        
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    lista_final = []
    
    for each_country in cupitube:
        
        for each_cupituber in cupitube[each_country]:
            
            if each_cupituber["subscribers"] >= suscriptores_min and each_cupituber["subscribers"] <= suscriptores_max and each_cupituber["category"] == categoria_buscada:
                lista_final.append(each_cupituber)
                
    return lista_final


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
   
   lista_final = [] 
   
   if pais_buscado in cupitube:
       
       for each_cupituber in cupitube[pais_buscado]:
           
           if each_cupituber["category"] == categoria_buscada and each_cupituber["monetization_type"] == monetizacion_buscada:
               lista_final.append(each_cupituber)
               
   return lista_final

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    menor_fetcha_lista = None
   
    for each_country in cupitube:
       
       for each_cupituber in cupitube[each_country]:
           
            fetcha_lista = each_cupituber["started"].split("-")
            
            if menor_fetcha_lista == None:
                menor_fetcha_lista = fetcha_lista
                cupituber_mas_antiguo = each_cupituber
            
            if fetcha_lista[0] < menor_fetcha_lista[0]:
                menor_fetcha_lista = fetcha_lista
                cupituber_mas_antiguo = each_cupituber
                
            elif fetcha_lista[0] == menor_fetcha_lista[0] and fetcha_lista[1] < menor_fetcha_lista[1]:
                menor_fetcha_lista = fetcha_lista
                cupituber_mas_antiguo = each_cupituber
            
            elif fetcha_lista[0] == menor_fetcha_lista[0] and fetcha_lista[1] == menor_fetcha_lista[1] and fetcha_lista[2] < menor_fetcha_lista[2]:
                menor_fetcha_lista = fetcha_lista
                cupituber_mas_antiguo = each_cupituber
                
    return cupituber_mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total_video_views = 0
    
    for each_country in cupitube:
       
       for each_cupituber in cupitube[each_country]:
           
           if each_cupituber["category"] == categoria_buscada:
               
               total_video_views += each_cupituber["video_views"]
               
    return total_video_views

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    todos_categorias_views = {}
    
    for each_country in cupitube:
       
       for each_cupituber in cupitube[each_country]:
           
           if each_cupituber["category"] in todos_categorias_views:
               
               todos_categorias_views[each_cupituber["category"]] += each_cupituber["video_views"]
               
           else:
               
               todos_categorias_views[each_cupituber["category"]] = each_cupituber["video_views"]
               
    visitas_mayores = None
    categoria_con_mas_visitas = {}
   
    for each_category in todos_categorias_views:
            
        if visitas_mayores == None:
                visitas_mayores = todos_categorias_views[each_category]
                categoria_con_mas_visitas[each_category] = todos_categorias_views[each_category]
            
        if todos_categorias_views[each_category] > visitas_mayores:
                visitas_mayores = todos_categorias_views[each_category]
                categoria_con_mas_visitas[each_category] = todos_categorias_views[each_category]
    
    return categoria_con_mas_visitas
    
# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
     
    for each_country in cupitube:
       
       for each_cupituber in cupitube[each_country]:
           
           if each_cupituber["cupituber"].isalnum() == True:
               
               if len(each_cupituber["cupituber"]) <= 15:
              
                   correo = each_cupituber["cupituber"].lower() + "." + str(each_cupituber["started"][2:4]) + str(each_cupituber["started"][5:7]) + "@cupitube.com"
                   each_cupituber["correo"] = correo
                   
               else:
                   name = each_cupituber["cupituber"][:15].lower()
                   correo = name + "." + str(each_cupituber["started"][2:4]) + str(each_cupituber["started"][5:7]) + "@cupitube.com"
                   each_cupituber["correo"] = correo
                   
           else:
               
               cupituber_list = []
               
               for each_character in each_cupituber["cupituber"]:
                   
                   if each_character.isalnum() == True:
                       cupituber_list.append(each_character)
                       
               new_cupituber = ''.join(cupituber_list).lower()
               
               if len(new_cupituber) <= 15:
              
                   correo = new_cupituber + "." + str(each_cupituber["started"][2:4]) + str(each_cupituber["started"][5:7]) + "@cupitube.com"
                   each_cupituber["correo"] = correo
                   
               else:
                   new_cupituber = new_cupituber[:15]
                   correo = new_cupituber + "." + str(each_cupituber["started"][2:4]) + str(each_cupituber["started"][5:7]) + "@cupitube.com"
                   each_cupituber["correo"] = correo
               
    return 

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    categoria_con_mas_visitas = obtener_categoria_con_mas_visitas(lista_dicc)
    
    recomendar_cupituber_dicc = {}
    cupituber_found = False
        
    for each_country in cupitube:
       
        for each_cupituber in cupitube[each_country]:
           
            if each_cupituber["category"] in categoria_con_mas_visitas:
               
                if each_cupituber["subscribers"] >= suscriptores_min and each_cupituber["subscribers"] <= suscriptores_max:
                   
                    if each_cupituber["started"] >= fecha_minima and each_cupituber["started"] <= fecha_maxima:
                   
                        if each_cupituber["video_count"] >= videos_minimos:
                           
                            if palabra_clave.lower() in each_cupituber["description"].lower():
                                
                                if cupituber_found == False:
                                    recomendar_cupituber_dicc[each_cupituber["cupituber"]] = each_cupituber
                                    cupituber_found = True
                                
                                
    return recomendar_cupituber_dicc

# Función 9:
def paises_por_categoria(cupitube: dict) -> list:
    
    categoria_lista = []
    categoria_dicc = {}
    
    for each_country in cupitube:
       
       for each_cupituber in cupitube[each_country]:
               
               if each_cupituber["category"] not in categoria_lista:
                   
                   categoria_lista.append(each_cupituber["category"])
                   
    for each_country in cupitube:
       
       for each_cupituber in cupitube[each_country]:
           
           for each_category in categoria_lista:
               
               if each_cupituber["category"] == each_category:
        
                   if each_category not in categoria_dicc:
                       
                       categoria_dicc[each_category] = [each_country]
                       
                   else:
                       
                       if each_country not in categoria_dicc[each_category]:
                           
                           categoria_dicc[each_category].append(each_country)
                           
    return categoria_dicc