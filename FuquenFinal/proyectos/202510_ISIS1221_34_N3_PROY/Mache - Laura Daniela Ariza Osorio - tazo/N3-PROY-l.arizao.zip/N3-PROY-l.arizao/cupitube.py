#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    paises = {}

    archivo = open("cupitube.csv", "r", encoding="utf-8" ) 
    titulos = archivo.readline().strip() #Leer titulos
   
    linea = archivo.readline().strip()
    
    while len(linea)>0:
        datos = linea.split(",")
        
        pais = datos[7]
        if pais in paises:
            lista_pais = paises[pais]
        else:
            lista_pais = []
        
        cupituber = {}
        cupituber["rank"] = int(datos[0])
        cupituber["cupituber"] = datos[1].strip()
        cupituber["suscribers"] = int(datos[2])
        cupituber["video_views"] = int(datos[3])
        cupituber["video_count"] = int(datos[4])
        cupituber["category"] = datos[5].strip()
        cupituber["started"] = datos[6].strip()
        cupituber["country"] = datos[7].strip()
        cupituber["monetizacion_type"] = datos[8].strip()
        cupituber["description"] = datos[9].strip()
        lista_pais.append(cupituber)
        paises[pais] = lista_pais
        
        linea= archivo.readline().strip()
          
    archivo.close()
    return paises
        

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    
    resultado = []
    
    for pais in cupitube: #recorre los paises en cupitube
        lista = cupitube[pais] #lista de cupitubers 
        for i in lista:
            if i["category"] == categoria_buscada: #si la categoria es igual a la buscada
               if suscriptores_min <= i["suscribers"] <= suscriptores_max:
                   resultado.append(i) #se agrega a la lista el resuldado
    
    return resultado
  

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    resultado = []
    
    if pais_buscado in cupitube:
        lista = cupitube[pais_buscado] #busca en cupitube la lista de los cupitubers del el pais que se qiere buscar
        for i in lista:
             if i["category"] == categoria_buscada and i["monetizacion_type"] == monetizacion_buscada:
                 resultado.append(i)
                 
    return resultado


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    resultado = {}
    
    for pais in cupitube:
        lista = cupitube[pais]
        for i in lista:
            if resultado == {} or i["started"] < resultado["started"]:
                resultado = i
                
    return resultado

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    x = 0
    for pais in cupitube:
        lista = cupitube[pais]
        for i in lista:
            if i["category"] == categoria_buscada:
                x += i["video_views"]
    
    return x


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    respuesta = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            
            if categoria in respuesta:
                respuesta[categoria] += cupituber["video_views"]
            else:
                respuesta [categoria] = cupituber["video_views"]
                
    categoria_mas_vista = None
    visitas_maximas = 0
    
    for cateoria, visitas in respuesta.items():
        if visitas > visitas_maximas:
           categoria_mas_vista = categoria
           visitas_maximas = visitas
           
    return {"categoria": categoria_mas_vista, "visitas": visitas_maximas}


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
       
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            #quitar los simbolos
            x = ""
            for i in cupituber["cupituber"]:
                if i.isalnum():
                    x += i
                    
            #maximo 15 caracteres
            x = x[:15]  
            #tener los 2 digitos del año
            año = cupituber["started"][:4]
            y = año[-2:]
            #dos ultimos del mes
            z = cupituber["started"][5:7]
            
            #armar el correo
            parte = [x,".",y,z,"@cupitube.com"]
            
            correo = "". join(parte)
            
            cupituber["correo"] = correo
            

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    respuesta = None
    vistas_max = -1 #porque puede tener minimo 0 vistas
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            vistas = cupituber["video_views"]
            if respuesta is None or vistas > vistas_max:
                respuesta = categoria
                vistas_max = vistas
                
            
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (cupituber["category"] == respuesta and 
                suscriptores_min <= cupituber["subscribers"] <= suscriptores_max and 
                cupituber["video_count"] >= videos_minimos and 
                fecha_minima <= cupituber["started"] <= fecha_maxima and 
                palabra_clave.lower() in cupituber["description"].lower()):
                return cupituber
            
    return {}


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    respuesta = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            c = cupituber["category"]
        
        if c not in respuesta:
            respuesta[c] = []
            
        if pais not in respuesta[c]:
            respuesta[c].append(pais)

    
    return respuesta 



