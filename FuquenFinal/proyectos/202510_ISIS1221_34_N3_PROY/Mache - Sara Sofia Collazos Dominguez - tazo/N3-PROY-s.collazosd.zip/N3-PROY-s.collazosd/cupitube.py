# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    cupitubers = {}
    archivo_csv = open(archivo, "r", encoding="utf-8")
    archivo_csv.readline()
    
    linea = archivo_csv.readline().strip()
    while linea != "":
        datos = linea.split(",")
        pais = datos[7].strip()
        cupituber = {}
        cupituber["rank"] = int(datos[0])
        cupituber["cupituber"] = datos[1].strip()
        cupituber["subscribers"] = int(datos[2])
        cupituber["video_views"] = int(datos[3])
        cupituber["video_count"] = int(datos[4])
        cupituber["category"] = datos[5].strip()
        cupituber["started"] = datos[6].strip()
        cupituber["monetization_type"] = datos[8].strip()
        cupituber["description"] = datos[9].strip()
        
        
        if pais in cupitubers:
            cupitubers[pais].append(cupituber)
        else:
            cupitubers[pais] = [cupituber]
            
        linea = archivo_csv.readline().strip()
        
    archivo_csv.close()
    return cupitubers


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:

    lista = []
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        
        for cada_cupituber in lista_cupitubers:
            if (cada_cupituber["category"] == categoria_buscada) and (suscriptores_min <= cada_cupituber["subscribers"] <= suscriptores_max):
                lista.append(cada_cupituber)
                
    return lista 
    

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
   
    lista = []
    
    if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]
        
        for cada_cupituber in lista_cupitubers:
            if (cada_cupituber["category"] == categoria_buscada) and (cada_cupituber["monetization_type"] == monetizacion_buscada):
                lista.append(cada_cupituber)
                
    return lista


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    cupituber_antiguo = None
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber_antiguo == None:
                cupituber_antiguo = cupituber
            elif cupituber["started"] < cupituber_antiguo["started"]:
                cupituber_antiguo = cupituber
                
    return cupituber_antiguo


# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total_visitas = 0
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada:
                total_visitas += cupituber["video_views"]
                
    return total_visitas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
   
    categoria_visitas = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            
            if categoria in categoria_visitas:
                categoria_visitas[categoria] += visitas
            else:
                categoria_visitas[categoria] = visitas
                
    categoria_mayor = ""
    visitas_mayor = 0

    for categoria in categoria_visitas:
        if categoria_visitas[categoria] > visitas_mayor:
            categoria_mayor = categoria
            visitas_mayor = categoria_visitas[categoria]
            
    resultado = {"categoria": categoria_mayor, "visitas": visitas_mayor}
    return resultado


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre_original = cupituber["cupituber"]
            nombre_nuevo = ""
            for cada_letra in nombre_original:
                if cada_letra.isalnum():
                    nombre_nuevo += cada_letra
            nombre_nuevo = nombre_nuevo.lower()
           
            if len(nombre_nuevo) > 15:
                nombre_nuevo = nombre_nuevo[:15]
            
            fecha = cupituber["started"]  
            anio = fecha[2:4]   
            mes  = fecha[5:7]  
            correo = nombre_nuevo + "." + anio + mes + "@cupitube.com"
            cupituber["correo"] = correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
   
    categorias = obtener_categoria_con_mas_visitas(cupitube)
    categoria_mas_visitas = categorias["categoria"]
    
    resultado = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (cupituber["category"] == categoria_mas_visitas) and (suscriptores_min <= cupituber["subscribers"] <= suscriptores_max) and (cupituber["video_count"] >= videos_minimos) and (fecha_minima <= cupituber["started"] <= fecha_maxima)and (palabra_clave.lower() in cupituber["description"].lower()):
                resultado = cupituber

    return resultado 
    

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    categorias_paises = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]

            if categoria in categorias_paises:
                if pais not in categorias_paises[categoria]:
                    categorias_paises[categoria].append(pais)
            else:
                categorias_paises[categoria] = [pais]

    return categorias_paises
