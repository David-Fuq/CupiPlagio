#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitube = {}
    abrir = open(archivo, encoding="utf-8")
    titulos = abrir.readline().split(",")
    print(titulos)
    linea = abrir.readline()
    
    while len(linea) > 0:
        dato = linea.split(",")
        estado = dato[0]
        
        if estado not in cupitube:
            cupitube[estado] = []
            
        cupitubers={}
        cupitubers["rank"]= int(dato[0])
        cupitubers["cupituber"] = dato[1]
        cupitubers["subscribers"] = int(dato[2])
        cupitubers["video_views"] =int(dato[3])
        cupitubers["video_count"] =int(dato[4])
        cupitubers["category"] = dato[5]
        cupitubers["started"] = dato[6]
        cupitubers["monetization_type"] = dato[7]
        cupitubers["description"] = dato[8]
        cupitube[estado].append(cupitubers)
       
        linea = archivo.readline()
             
    archivo.close()
    
    return cupitube

archivo = cargar_cupitube("cupitube.csv")
print(archivo)

        
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    categoria_y_rango_suscriptores = []
    for lista in cupitube.values():
        for x in lista:
            if(x["category"]==categoria_buscada and suscriptores_min <= x["subscribers"] <= suscriptores_max):
                categoria_y_rango_suscriptores.append(x)
    return categoria_y_rango_suscriptores


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    pais_categoria_monetizacion = []
    for pais_buscado in cupitube:
        for x in cupitube[pais_buscado]:
            if (x["category"]==categoria_buscada and x["monetization_type"]==monetizacion_buscada):
                pais_categoria_monetizacion.append(x)
    return pais_categoria_monetizacion            


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None
    for lista in cupitube.values():
        for c in lista:
            if mas_antiguo is None or c["started"] < mas_antiguo["started"]:
                mas_antiguo = c
    return mas_antiguo


# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0
    for lista in cupitube.values():
        for x in lista:
            if x["category"] == categoria_buscada:
                total +=x["video_views"]
    return total


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {}
    for lista in cupitube.values():
        for x in lista:
            cate = x["category"]
            if cate in visitas_por_categoria:
                visitas_por_categoria[cate] += x["video_views"]
            else:
                visitas_por_categoria[cate] = x["video_views"]
    categorias = []
    for clave in visitas_por_categoria:
        categorias.append(clave)
    mayor_categoria = None
    max_visitas = -1
    i = 0
    while i < len(categorias):
        categoria = categorias[i]
        visitas = visitas_por_categoria[categoria]
        if visitas > max_visitas:
            mayor_categoria = categoria
            max_visitas = visitas
        i += 1
    return {"categoria": mayor_categoria, "visitas": max_visitas}



# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    valores = list(cupitube.values())
    i = 0
    while i < len(valores):
        lista = valores[i]
        j = 0
        while j < len(lista):
            x = lista[j]
            original = x["cupituber"]
            limpio = ""
            k = 0
            while k < len(original):
                if original[k].isalnum():
                    limpio += original[k]
                k += 1
            limpio = limpio[:15]
            fecha = x["started"]
            correo = (limpio + "." + fecha[2:4] + fecha[5:7] + "@cupitube.com").lower()
            x["correo"] = correo
            j += 1
        i += 1


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    categoria_mas_vistas = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    for lista in cupitube.values():
        for x in lista:
            if (x["category"] == categoria_mas_vistas and
                suscriptores_min <= x["subscribers"] <= suscriptores_max and
                fecha_minima <= x["started"] <= fecha_maxima and
                x["video_count"] >= videos_minimos and
                palabra_clave.lower() in x["description"].lower()):
                return x
    return {}


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}
    paises = []
    for clave in cupitube:
        paises.append(clave)
    i = 0
    while i < len(paises):
        pais = paises[i]
        lista = cupitube[pais]
        for x in lista:
            cate = x["category"]
            if cate not in resultado:
                resultado[cate] = []
            if pais not in resultado[cate]:
                resultado[cate].append(pais)
        i += 1
    return resultado

