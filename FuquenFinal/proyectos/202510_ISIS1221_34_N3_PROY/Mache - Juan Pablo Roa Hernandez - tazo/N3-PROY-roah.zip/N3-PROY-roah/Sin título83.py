# -*- coding: utf-8 -*-
"""
Created on Sun Apr 27 20:04:13 2025

@author: JuanP
"""

    mas_visitas = obtener_categoria_con_mas_visitas(cupitube)
    rango_ca = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, mas_visitas)
    recomendar = None
    for cantidad in cupitube:
        
        if cupitube[cantidad]["video_count"] >= videos_minimos:
            if mas_visitas == cupitube[cantidad]["video_views"]:
                if cupitube[cantidad]["subscribers"] in rango_ca:
                    if cupitube[cantidad]["subscribers"] in range(fecha_minima, fecha_maxima +1):
                        if cupitube[cantidad]["description"].lower() in palabra_clave.lower():
                            recomendar = cupitube[cantidad]
    return recomendar


{'rank': 1, 'subscribers': 222000000, 'video_views': 198459090822, 'video_count': 17317, 'category': 'Music', 'started': '2006-11-15', 'country': 'India', 'monetization_type': 'AdSense', 'description': 'bEST UnBOxInG ViDEos!\n'}