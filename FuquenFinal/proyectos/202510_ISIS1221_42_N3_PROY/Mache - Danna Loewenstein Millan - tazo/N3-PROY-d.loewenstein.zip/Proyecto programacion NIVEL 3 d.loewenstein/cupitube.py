#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitube= {}
    
    #paso 1: Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers
    abrir_archivo= open(archivo, "r" , encoding="utf-8")
    
    #Leerlo y cerrarlo
    contenido = abrir_archivo.readlines()
    abrir_archivo.close()
    
    #establecer encabezados para saber el indice del pais.
    encabezados= contenido[0].strip().split(",")
    indice_country= encabezados.index("country")
    
    #Al diccionario que cree al inicio le agrego como llaves todos los paises de mi csv. Con un BUCLE.
    for linea in contenido[1:]: #Desde 1 porque ya leimos el encabezado.
        cupitubers= linea.strip().split(",") #Se crea una lista de cada cupituber
        analizar_country= cupitubers[indice_country] #Se extrae el pais de cada cupituber, esto usando el indice donde ya sabemos que esta ubicado gracias a el encabezado.
        
        if analizar_country not in cupitube: #Preguntar si el pais del cupituber ya esta presente en mi diccionario
            cupitube[analizar_country]= [] #Si no lo esta, lo va a agregar como llave y a la vez su valor sera una lista vacia. 
            
    #Ahora lo mas importante es asignar cada cupituber a su respectivo pais.
    
    for linea in contenido[1:]:
        cupitubers= linea.strip().split(",") #Se crea una lista de cada cupituber de nuevo
        analizar_country= cupitubers[indice_country] #se analiza su pais para asignarlo al diccionario en el lugar que corresponde
        
        rank= int(cupitubers[0])
        cupituber= str(cupitubers[1])
        subscribers= int(cupitubers[2])
        video_views= int(cupitubers[3])
        video_count= int(cupitubers[4])
        category= str(cupitubers[5])
        started= str(cupitubers[6])
        monetization_type= str(cupitubers[8])
        description=str(cupitubers[9])
        
        
        if analizar_country in cupitube: #preguntar si el pais del cupituber esta presente en el diccionario cupitube.
            cupitube[analizar_country].append({"rank": rank,
                                                                "cupituber": cupituber,
                                                                "subscribers": subscribers,
                                                                "video_views": video_views,
                                                                "video_count": video_count,
                                                                "category": category,
                                                                "started": started,
                                                                "monetization_type": monetization_type,
                                                                "description": description,}) #si esta presente en el diccionario basicamente en la lista vacia que esta como valor actual del pais respectivo(llave) se añadiran estos datos.
    
    
    return cupitube
        
        
        

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    #creamos una lista vacía
    cupitubers_por_categoria = []
    
    #vamos pais por pais en el diccionario creado anteriormente, quiero extraer los datos de los cupitubers agrupados por pais.
    for country in cupitube:
        cupitubers_del_pais= cupitube[country] #Con esto ya tenemos una lista de diccionario sobre los cupitubers.
        
        for cupituber in cupitubers_del_pais: #en español seria, por cada cupituber que este en la lista del pais..
            categoria_del_cupituber= cupituber["category"]
            validacion_subscriptores= cupituber["subscribers"]
            
            if categoria_del_cupituber == categoria_buscada and suscriptores_min<= validacion_subscriptores <= suscriptores_max:
                cupitubers_por_categoria.append(cupituber)
                
    return cupitubers_por_categoria
                


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    
    #crear lista vacia
    cupitubers_por_pais_categoria_monetizacion= []
    
    #Este seria un recorrido parcial, ya que solo necesita los cupitubers de un pais en especifico.
    if pais_buscado in cupitube:
        cupitubers_del_pais= cupitube[pais_buscado]
        
        for cupituber in cupitubers_del_pais: #en español seria, por cada cupituber que este en la lista del pais..Revisa su categoria y monetizacion.
            categoria_del_cupituber= cupituber["category"].title()
            Tipo_monetizacion= cupituber["monetization_type"].title()
            
            if categoria_del_cupituber == categoria_buscada and Tipo_monetizacion == monetizacion_buscada:
                cupitubers_por_pais_categoria_monetizacion.append(cupituber)
                
    return cupitubers_por_pais_categoria_monetizacion
        
        
 
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None #Temporalmente, para iniciar no hay ningun cupituber guardado.

    for pais in cupitube: # paso 1: recorrer cupitube
        lista_pais = cupitube[pais] # paso 2: lista de cupitubers de ese país

    for cupituber in lista_pais: # paso 3: recorrer lista del país actual del cupituber.
        if mas_antiguo is None: # paso 5: si sigue igual que en el principio..
            mas_antiguo = cupituber # guardar el primero que aparezca, (Ahi ya tenemos uno de los requerimientos de la funcion cumplidos)
            
        else:
            if cupituber["started"] < mas_antiguo["started"]: # paso 6: comparar fechas
                mas_antiguo = cupituber # actualizar si el actual es más antiguo

    return mas_antiguo # paso 7: devolver el más antiguo

  
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
            
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    cantidad_total_de_visitas= 0
    
    for country in cupitube: #recorrer cada pais de mi diccionario
        cupitubers_del_pais= cupitube[country]
        
        for cupituber in cupitubers_del_pais: #recorrer cada cupituber que esta en el diccionario de las listas de cada pais.
            seleccionar_categoria= cupituber["category"]#validar su respectiva categoria
            
            if seleccionar_categoria == categoria_buscada:
                vistas_cupituber= int(cupituber["video_views"])
                cantidad_total_de_visitas+= vistas_cupituber
                
    return cantidad_total_de_visitas
                
            


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categorias_con_sus_visitas= [] #crear una lista en la  cual ubicaremos diccionarios de cada categoria con su suma total de visitas.
    
    for country in cupitube: #recorrer cada pais de mi diccionario
        cupitubers_del_pais= cupitube[country]
        
        for cupituber in cupitubers_del_pais: #recorrer cada cupituber que esta en el diccionario de las listas de cada pais.
            categoria= cupituber["category"]#extraer su respectiva categoria
            visitas= int(cupituber["video_views"])#extraer la cantidad de vistas 
            
            si_esta= False #esta variable me ayudara a agregar a mi lista que esta vacia los datos necesarios, organizados por diccionarios.
            
            for categorias in categorias_con_sus_visitas: #para categorias en la lista...
                if categorias["categoria"]== categoria: #haz que se valide si ya esta..
                    categorias["visitas"]+=visitas #si ya lo esta simplemente a su valor de la llave visitas sumale las visitas de cada cupituber de su cateegoria.
                    si_esta= True #Automaticamente la variable de si esta se pondra en positivo.
                    
            if not si_esta: #Si no esta la categoria en el dicionario se adicionara.
                categorias_con_sus_visitas.append({"categoria": categoria,
                                                   "visitas": visitas})
                
                        
    #crear un diccionario temporal que usare en el siguiente bucle para comparar.
    mayor_visitas_temporal={"categoria": "", "visitas": -1}
    
    for nuevo_diccionario in categorias_con_sus_visitas:
        if nuevo_diccionario["visitas"] > mayor_visitas_temporal["visitas"]:
            mayor_visitas_temporal = nuevo_diccionario
            
            
    return mayor_visitas_temporal
            


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    #Primero para construir el correo necesitamos datos especificos como , nombre , fecha de inicio que esta en un formato especifico.
    #Eso lo hago recorriendo mi diccionario de nuevo y por cada cupituber de cada pais extraer esto.
    
    for country in cupitube:
        cupitubers_del_pais = cupitube[country]
        
        for cupituber in cupitubers_del_pais:
            extraer_nombre= cupituber["cupituber"]
            fecha_completa= cupituber["started"]
            
            #para tener el nombre limpio y maximo 15 caracteres primero necesito sacarle valores especiales como -.. etc
            #Para eso empezamos con una variables la cual se le va a asignar cada nombre del cupituber despues de limpio.
            
            nombre_sin_caracteres_especiales= "" #Aqui no tenia ni idea de como borrar caracteres especiales pero busque HARTO y encontre  los bucles usando .isalnum().
            for caracteres in extraer_nombre:
                if caracteres.isalnum():
                    nombre_sin_caracteres_especiales+=caracteres
                    
            nombre_limpio= nombre_sin_caracteres_especiales[:15] #Aqui me aseguro que se corte cuando ya llegue a un maximo de 15 caracteres.
            nombre_limpio= nombre_limpio.lower() #me aseguro de que todo sea en minuscula
            
            #Ahora se necesita extraer los datos que quiere el correo sobre la fecha de inicio.
            
            Últimos_dos_dígitos= fecha_completa[2:4]
            dos_dígitos_del_mes= fecha_completa[-4:-6]
            
            #Con estos datos ya faciles de manejar y creados hago el formato del correo.
            
            correo_completo = f"{nombre_limpio}.{Últimos_dos_dígitos}{dos_dígitos_del_mes}@cupitube.com"
            
            #como ultimo todo esto hay que anexarlo al diccionario.
            
            cupituber["correo"]= correo_completo
            
            


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    
    cupituber_mas_recomendado= {}
    #Necesito dividir las fechas en partes para poder comparar cada palabra en un rango.
    #primero voy a extraer el año
    año_fecha_minima= (fecha_minima[:4])
    año_fecha_maxima= (fecha_maxima[:4])
    #Luego extraigo el mes
    mes_fecha_minima=(fecha_minima[5:7])
    mes_fecha_maxima=(fecha_maxima[5:7])
    #Luego el dia
    dia_fecha_minima=(fecha_minima[8:])
    dia_fecha_maxima=(fecha_maxima[8:])
    
    extraer_categoria_mas_views= obtener_categoria_con_mas_visitas(cupitube)
    nombre_categoria_mas_views=extraer_categoria_mas_views["categoria"]
    
    
    for country in cupitube:
        cupitubers_del_pais = cupitube[country]
        
        for cupituber in cupitubers_del_pais:
            
            suscriptores= (cupituber["subscribers"])
            cantidad_videos_publicados= (cupituber["video_count"])
            fecha_inicio_publicacion= (cupituber["started"])
            cadena_de_descripcion= cupituber["description"]
            
            str_1 = (suscriptores_min)
            str_2 = (suscriptores_max)
            
            
            
            if (str_1 <= suscriptores <= str_2 
                and cantidad_videos_publicados >= videos_minimos
                and año_fecha_minima <= fecha_inicio_publicacion[:4] <= año_fecha_maxima 
                and mes_fecha_minima <= fecha_inicio_publicacion[5:7] <= mes_fecha_maxima 
                and dia_fecha_minima <= fecha_inicio_publicacion[8:] <= dia_fecha_maxima):
            
                validacion = cadena_de_descripcion.split()
                
                for palabras in validacion :
                    if palabra_clave.lower() in palabras.lower():
                        cupituber_mas_recomendado= cupituber
                        
                        #Por ahora en el diccionario esta el cupituber que cumple con todas las expectativas, menos una. La cual es la categoria con mas visitas totales.
                        #Hay que filtrar los datos que tenemos con la categoria con maximo de views para ya obtener el cupituber mas recomendable.

                        
                        if cupituber_mas_recomendado["category"] == nombre_categoria_mas_views:
                            return cupituber_mas_recomendado
                        
                        
                        
                        

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    country_por_categoria= {}
    
    for country in cupitube:
        cupitubers_del_pais = cupitube[country]
        
        for cupituber in cupitubers_del_pais:
            categoria= cupituber["category"]
            
            if categoria not in country_por_categoria:
                country_por_categoria[categoria]= []
                
            if country not in country_por_categoria[categoria]:
                country_por_categoria[categoria].append(country)
                
    return country_por_categoria
  
  
