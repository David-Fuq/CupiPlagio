#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    cupitube =  open(archivo, "r", encoding="utf-8") 
    archivo_cupitube = {}
    headers = cupitube.readline().strip().split(",")
    data = cupitube.readline().strip()
    
    while data != ("") :
        separacion = data.split(",")
        diccionario_cupitube = {headers[0]: int(separacion[0]),
                                headers[1]: separacion[1],
                                headers[2]: int(separacion[2]),
                                headers[3]: int(separacion[3]),
                                headers[4]: int(separacion[4]),
                                headers[5]: separacion[5],
                                headers[6]: separacion[6],
                                headers[8]: separacion[8],
                                headers[9]: separacion[9]
                                }
        data = cupitube.readline().strip()
        
        country = separacion[7].strip().lower()
        
        if country != ("") :
            if country not in archivo_cupitube:
                archivo_cupitube[country] = []
            archivo_cupitube[country].append(diccionario_cupitube)
            
    cupitube.close()
    return archivo_cupitube
#son 10 funciones en total la numero siete es paises y lo demas es de 0 a 9 tipo de posiciones 



# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    categoria_y_rango_sub = []

    for lista_cupitubers in cupitube.values():
        for caracteristicas_dadas in lista_cupitubers:
            if (caracteristicas_dadas["category"].lower() == categoria_buscada.lower()) and (suscriptores_min <= caracteristicas_dadas["subscribers"] <= suscriptores_max):
                categoria_y_rango_sub.append(caracteristicas_dadas)
        
    return categoria_y_rango_sub
        
    

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cupitubers_need = []
    
    for country in cupitube.keys():
        if pais_buscado.lower() in cupitube:
            
            for cada_cupitube in cupitube[pais_buscado.lower()]:
                if cada_cupitube["category"].lower() == categoria_buscada.lower() and cada_cupitube["monetization_type"].lower() == monetizacion_buscada.lower():
                    cupitubers_need.append(cada_cupitube)
    return cupitubers_need


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    cupi_tuber_m_a = None 
    for cada_pais in cupitube:
        cupi_tubers = cada_pais
        for cada_cupituber in cupi_tubers:
            if cupi_tuber_m_a == None:
                cupi_tuber_m_a = cada_cupituber
            elif cada_cupituber["started"] < cupi_tuber_m_a ["started"]:
                cupi_tuber_m_a = cada_cupituber
    return cupi_tuber_m_a
 

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    numero_total = 0
    for vistas_category in cupitube.values():
        for cada_cupituber in vistas_category:
            if categoria_buscada.lower() == cada_cupituber["category"].lower():
                numero_total = numero_total + cada_cupituber["video_views"]
    return numero_total



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categoria_con_mas_vistas_encupi = {}
    
    for cada_categoria in cupitube.values():
        categoria = cada_categoria["category"]
        vistas_del_cupituber = cada_categoria["video_views"]
       
        if categoria in categoria_con_mas_vistas_encupi:
            categoria_con_mas_vistas_encupi[categoria] += vistas_del_cupituber
        else:
            categoria_con_mas_vistas_encupi[categoria] = vistas_del_cupituber
        
    categoria_con_masvistass = ""
    max_category_vistas = 0
    
    for categoria in categoria_con_mas_vistas_encupi:
        vistas_numero_total = categoria_con_mas_vistas_encupi[categoria]
        if vistas_numero_total > max_category_vistas:
            max_category_vistas = vistas_numero_total
            categoria_con_masvistass = categoria
   
    categoria_con_mas_vistas_encupi = {"categoria": categoria_con_masvistass, "vistas": max_category_vistas}
    
    return categoria_con_mas_vistas_encupi
        



# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    i = 0 
    nombre = cupitube["cupituber"].strip(" ")
    correo = ""
    while i < len(cupitube.values()):
        cupitubers = cupitube.values()[i]
        j = 0 
        while j <len(cupitubers):
             if  nombre[j] > 15:
                 nombre = nombre[0:14]
                 if nombre[j].isalnum():
                    nombre.strip(" ")
                 j = j + 1
        
        started =  cupituber["started"]
        x = started[2:4]
        z = started[5:7]
  
        corree = f"({nombre}.{x}{z}@cupitube.com)"
        correo = corree.lower()
        cupitube.values()["correo"]=correo
        i = i + 1
    return None
        
#esta funcion tinee algo raro sin embargo se comprende la estructura de la funcion, jajjaj no entiendo que esta mal 


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    cupituber_recomendado = {}
    condicion = False 
    i=0
    categoria_buscada = obtener_categoria_con_mas_visitas(cupitube)
    categoriaa = categoria_buscada["categoria"]
    
    while condicion == False  and i <len(cupitube.values()):
        cupitubers = cupitube.values()[i]
        j=0
        while condicion == False and j < len(cupitubers):
            cupituber = cupitubers[j]
            if categoriaa.lower() == cupituber["category"].lower():
                if palabra_clave.lower() in cupitubers["description"].lower():
                    if suscriptores_min <= cupitubers["subscribers"] <= suscriptores_max:
                        if fecha_minima <= cupitubers["strated"] <= fecha_maxima :
                            if videos_minimos <= cupitubers["video_count"]:
                                condicion = True
                                cupituber_recomendado = cupituber
            j = j + 1
        i = i + 1
    return cupituber_recomendado
            

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    pais_category = {}
    
    for cada_pais in cupitube.values():
        categoria = cada_pais["category"]
        pais_que_quiero = cada_pais["country"]
        
        if categoria not in pais_category:
            pais_category[categoria] = []
        if pais_que_quiero in pais_category[categoria]:
            pais_category[categoria].appedn(pais_que_quiero)
            
    return pais_category
        
    
