#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:    
    archivitos = open(archivo, "r", encoding="utf-8")
    cupicupi = {}
    enca = archivitos.readline().strip().split(",")
    data = archivitos.readline().strip()

    while data !="":
        listin = []
        algo = data.split(",")
        influensher = {
            enca[0] : algo[0],
            enca[1] : algo[1],
            enca[2] : algo[2],
            enca[3] : algo[3],
            enca[4] : algo[4],
            enca[5] : algo[5],
            enca[6] : algo[6],
            enca[8] : algo[8],
            enca[9] : algo[9],
            }
        listin.append(influensher)
        if algo[7] not in cupicupi:
            cupicupi[algo[7]] = listin
        else:
            cupicupi[algo[7]].append(influensher)
        data = archivitos.readline().strip()
        
    archivitos.close()
    
    return cupicupi
    
cargar = (cargar_cupitube("cupitube.csv"))

    #TODO 1: Implemente la función tal y como se describe en la documentación.


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    otrocupicupi = []

    for cada_pais in cupitube.values():
        for cada_cupituber in cada_pais:
            if (cada_cupituber["category"]).lower() == (categoria_buscada).lower() and suscriptores_min<= int(cada_cupituber["subscribers"]) <= suscriptores_max:
                otrocupicupi.append(cada_cupituber)
    return otrocupicupi


"""
    
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    #TODO 2: Implemente la función tal y como se describe en la documentación.


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resp = []

    for cada_pais in cupitube:
        nombre_pais = cupitube[cada_pais]
        if str(cada_pais).lower() == str(pais_buscado).lower():
            for cada_cupi in nombre_pais:
                if cada_cupi["category"].title() == categoria_buscada.title() and cada_cupi["monetization_type"].title() == monetizacion_buscada.title():
                    resp.append(cada_cupi)
    
    return resp
"""
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    #TODO 3: Implemente la función tal y como se describe en la documentación.



# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    otrocupicupi = {}
    for cada_pais in cupitube.values():
        for cada_cupituber in cada_pais:
            if len(otrocupicupi) == 0:
                otrocupicupi = cada_cupituber
            else:
                if otrocupicupi["started"] > cada_cupituber["started"]:
                    otrocupicupi = cada_cupituber
    return otrocupicupi

"""
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    #TODO 4: Implemente la función tal y como se describe en la documentación.
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    visitas = 0
    for cada_pais in cupitube.values():
        for cada_cupituber in cada_pais:
            if (str(cada_cupituber["category"])).title() == (str(categoria_buscada)).title():
                visitas += int(cada_cupituber["video_views"])
    return visitas

    
"""
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    #TODO 5: Implemente la función tal y como se describe en la documentación.



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict)->dict:
   otrocupicupi = {}
   visitas = 0
   for cada_pais in cupitube.values():
        for cada_cupituber in cada_pais:
            if len(otrocupicupi) == 0:
                visitas = (obtener_visitas_por_categoria(cupitube, cada_cupituber["category"])) 
                otrocupicupi[cada_cupituber["category"]] = visitas
            elif cada_cupituber["category"] not in otrocupicupi:
                if (obtener_visitas_por_categoria(cupitube, cada_cupituber["category"])) > visitas:
                    visitas = (obtener_visitas_por_categoria(cupitube, cada_cupituber["category"]))
                    otrocupicupi[cada_cupituber["category"]] = visitas
                    
   return otrocupicupi



"""
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    #TODO 6: Implemente la función tal y como se describe en la documentación.

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for cada_pais in cupitube.values():
        for cada_cupituber in cada_pais:
            name = str(cada_cupituber["cupituber"]).replace(" ", "")
            if not name.isalnum():
                for cada_letra in name:
                    if not cada_letra.isalnum():
                        algo = name.replace(cada_letra,"")
                        name = algo  
            year = str(cada_cupituber["started"])
            reryear = str(year[2]) + str(year[3])
            mes = str(year[5]) + str(year[6])
            correo = str(name) + "." + str(reryear) + str(mes) + "@cupitube.com"
            cada_cupituber["correo"] = str(correo).lower()

"""
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    #TODO 7: Implemente la función tal y como se describe en la documentación.



# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    lista_listas = list(cupitube.values())
    rec = {}
    i = 0
    encontre = False
    while i < len(lista_listas) and not encontre:
        lista_pais = lista_listas[i]
        j=0
        i+=1
        while j<len(lista_pais) and not encontre:
            suscriptores = int(lista_pais[j]["subscribers"])
            fecha = str(lista_pais[j]["started"])
            videos = int(lista_pais[j]["video_count"])
            descripcion = (lista_pais[j]["description"]).lower()
            categorikis = list(obtener_categoria_con_mas_visitas(cupitube).keys())[0]
            firulais = lista_pais[j]["category"]
            if categorikis== firulais and suscriptores_min<= suscriptores <= suscriptores_max and fecha_minima <= fecha <= fecha_maxima and videos_minimos <= videos and (palabra_clave.lower()) in descripcion:
                rec = lista_pais[j]
                encontre = True
            j+=1
    return rec
  
#print(recomendar_cupituber(cargar, 0, 222000000, "2006-11-15", "2006-11-15", 0, "best"))
"""
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #TODO 8: Implemente la función tal y como se describe en la documentación.


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    otrocupicupi = {}
    i = 0
    for cada_pais in cupitube.values():
        lista_pais = list(cupitube.keys())
        lista_paises = lista_pais[i]
        for cada_cupituber in cada_pais:
            if cada_cupituber["category"] not in otrocupicupi:
                otrocupicupi[cada_cupituber["category"]] = [lista_paises]
            else:
                if lista_paises not in otrocupicupi[cada_cupituber["category"]]:
                    otrocupicupi[cada_cupituber["category"]].append(lista_paises)
        i += 1
    return otrocupicupi

#print(paises_por_categoria(cargar))

"""

    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    #TODO 9: Implemente la función tal y como se describe en la documentación.
