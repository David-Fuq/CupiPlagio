#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
   
    file =  open(archivo, "r", encoding="utf-8") 
    columnas = file.readline().strip().split(",")
    
    linea = file.readline()
    cupitubers = { }
    
    while len(linea)>0:
        datos = linea.strip().split(",")
        country = datos[7]
        
        diccionario = {
            "rank": int(datos[0]),
            "cupituber": datos[1].strip(),
            "subscribers": int(datos[2]),
            "video_views": int(datos[3]),
            "video_count": int(datos[4]),
            "category": datos[5],
            "started": datos[6],
            "monetization_type": datos[8],
            "description": datos[9],
        }
        
        if country not in cupitubers:
            cupitubers[country] = []

        cupitubers[country].append(diccionario)
        linea = file.readline()
    file.close()
    return cupitubers
        
'''IMPLEMENTACION'''      
diccionario = (cargar_cupitube("cupitube.csv"))
print(diccionario)
    



# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    busqueda_categoria = [ ]
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada and suscriptores_min <= cupituber["subscribers"] <= suscriptores_max:
                busqueda_categoria.append(cupituber)
    
    return busqueda_categoria
    
    
    
print("Implementacion 2: ")
print(buscar_por_categoria_y_rango_suscriptores(diccionario, 1000000, 111000000, "Gaming"))



# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    busqueda_categoria = [ ]
    
    for pais in cupitube.keys():
        if pais == pais_buscado:
            for cupituber in cupitube[pais]:
                if cupituber["category"] == categoria_buscada and monetizacion_buscada == cupituber["monetization_type"]:
                    busqueda_categoria.append(cupituber)
    
    return busqueda_categoria

print("Implementacion 3: ")
print(buscar_cupitubers_por_pais_categoria_monetizacion(diccionario, "UK", "Gaming", "Crowdfunding"))


    

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    fecha_max = str(4000-12-12)
    cupituber_mas_viejo = None
    
    for pais in cupitube:
            for cupituber in cupitube[pais]:
                fecha = str(cupituber["started"])
                if fecha < fecha_max:
                    fecha_max = fecha
                    cupituber_mas_viejo = cupituber
    return cupituber_mas_viejo
               
                
                
    

print("Implementacion 4: ")
print(buscar_cupituber_mas_antiguo(diccionario))



# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    vistas = 0 
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if categoria_buscada == cupituber["category"]:
                vistas += cupituber["video_views"]
                
    return vistas

print("Implementacion 5: ")
print(obtener_visitas_por_categoria(diccionario, "Music"))



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    max_visitas = 0
    categoria = None
    diccionario_mas_visitas= {}
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            visitas = obtener_visitas_por_categoria(cupitube, cupituber["category"])
            if visitas > max_visitas:
                max_visitas = visitas
                categoria = cupituber['category']
    diccionario_mas_visitas["categoria"]= categoria
    diccionario_mas_visitas["visitas"]= max_visitas
        
    return diccionario_mas_visitas
                
print("Implementacion 6: ")
print(obtener_categoria_con_mas_visitas(diccionario))
      
    

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre = cupituber['cupituber']
            
            x = ""
            y1 = str(cupituber['started'])
            y = y1[2:4]
            z = y1[5:7]
            n = 0 
            
            for caracter in nombre:
                if caracter.isalnum() and n < 15:  
                    x += caracter
                    n += 1
                
            correo = (str(x) + "." + str(y)+ str(z)+ "@cupitube.com")
            cupituber["correo"]= correo
        
            

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
   
   categoria_mas_visitas = obtener_categoria_con_mas_visitas(cupitube)
   
   categoria = categoria_mas_visitas["categoria"].lower().strip()
   cupituber_recomendado = {}
   count = 0 
   for pais in cupitube:
        for cupituber in cupitube[pais]:
           if cupituber["category"].lower().strip() == categoria and (suscriptores_min < cupituber["subscribers"] < suscriptores_max) and cupituber["video_count"] >= videos_minimos and (fecha_minima < cupituber["started"] < fecha_maxima) and (palabra_clave.lower() in cupituber["description"].lower() and count < 1):
               cupituber_recomendado = cupituber
               count += 1
   return cupituber_recomendado
    
print("Implementacion 8: ")
print(recomendar_cupituber(diccionario, 130000000, 322000000, "2005-11-25", "2008-11-25", 700, "unboxing"))
      



# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias = { }
    for pais in cupitube:
         for cupituber in cupitube[pais]:
             categoria = cupituber["category"]
             if categoria not in categorias:
                 categorias[categoria]= []
             if pais not in categorias[categoria]:
                categorias[categoria].append(pais)
                
    return categorias
             
                 
   
  
print("Implementacion 9: ")
print(paises_por_categoria(diccionario))
    
                 
 