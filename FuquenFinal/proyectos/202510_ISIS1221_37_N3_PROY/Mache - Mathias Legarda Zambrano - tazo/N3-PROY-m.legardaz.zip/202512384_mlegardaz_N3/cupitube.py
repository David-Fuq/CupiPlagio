#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    #TODO 1: Implemente la función tal y como se describe en la documentación.
    archivo = "cupitube.csv"
    archivo = open("cupitube.csv", "r", encoding="utf-8")
    linea = archivo.readline()
    cupitubers_por_pais = {}
    

    while linea:
        linea = linea.strip()
        linea = archivo.readline()
         
        if linea != "":
            campos = linea.split(',')

            rank = int(campos[0].strip())
            cupituber = campos[1].strip()
            subscribers = int(campos[2].strip())
            video_views = int(campos[3].strip())
            video_count = int(campos[4].strip())
            category = campos[5].strip()
            started = campos[6].strip()
            country = campos[7].strip()
            monetization_type = campos[8].strip()
            description = campos[9].strip()
            
        
            info = {
                "rank": rank,
                "cupituber": cupituber,
                "subscribers": subscribers,
                "video_views": video_views,
                "video_count": video_count,
                "category": category,
                "started": started,
                "monetization_type": monetization_type,
                "description": description
            }
           
            if country not in cupitubers_por_pais:
                cupitubers_por_pais[country] = []
            cupitubers_por_pais[country].append(info)
    return cupitubers_por_pais

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    #TODO 2: Implemente la función tal y como se describe en la documentación.
    lista_cupitubers = []
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for cupituber in cupitubers:
            if cupituber["category"].lower() == categoria_buscada and suscriptores_min <= cupituber["subscribers"] <= suscriptores_max:
                lista_cupitubers.append(cupituber)
    return lista_cupitubers

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    #TODO 3: Implemente la función tal y como se describe en la documentación.
    lista_buscada = []
    pais_buscado = pais_buscado.lower()
    categoria_buscada = categoria_buscada.lower()
    monetizacion_buscada = monetizacion_buscada.lower()
    for pais in cupitube:
        if pais.lower() == pais_buscado:
            cupitubers = cupitube[pais]
            for cupituber in cupitubers:
                if cupituber['category'].lower() == categoria_buscada and cupituber['monetization_type'].lower() == monetizacion_buscada:
                    lista_buscada.append(cupituber)
    return lista_buscada

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    antiguo = None
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for cupituber in cupitubers:
            if antiguo is None or cupituber["started"] < antiguo["started"]:
                antiguo = cupituber
    return antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    #TODO 5: Implemente la función tal y como se describe en la documentación.
    total_visitas = 0
    categoria_buscada = categoria_buscada.lower()
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for cupituber in cupitubers:
            if cupituber.get("category","").lower() == categoria_buscada:
                total_visitas +=cupituber.get("video_views", 0)
    return total_visitas         

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    #TODO 6: Implemente la función tal y como se describe en la documentación.
    visitas_por_categoria = {}
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for cupituber in cupitubers:
            categoria = cupituber.get("category", "").lower()
            visitas = cupituber.get("video_views", 0)
            if categoria:
                visitas_por_categoria[categoria] = visitas_por_categoria.get(categoria, 0) + visitas

    categoria_max = None
    max_visitas = -1
    for categoria, total in visitas_por_categoria.items():
        if total > max_visitas:
            categoria_max = categoria
            max_visitas = total
    return {"categoria": categoria_max, "visitas": max_visitas}

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    #TODO 7: Implemente la función tal y como se describe en la documentación.
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for cupituber in cupitubers:
            nombre = cupituber.get('cupituber', '').lower()
            nombre_limpio = ''.join(c for c in nombre if c.isalnum())[:15]
            started = cupituber.get('started', '')
            if started and '-' in started:
                partes_fecha = started.split('-')
                año = partes_fecha[0]
                mes = partes_fecha[1]
            else:
                año = "00"
                mes = "00"
            if len(mes) == 1:
                mes = '0' + mes   
            correo = f"{nombre_limpio}.{año[-2:]}{mes}@cupitube.com"
            cupituber['correo'] = correo
    
 # Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    categoria_max_info = obtener_categoria_con_mas_visitas(cupitube)
    if not categoria_max_info:
        return {}

    categoria_max = categoria_max_info.get("categoria")
    if not categoria_max:
        return {}

    cupitubers_filtrados = buscar_por_categoria_y_rango_suscriptores(
        cupitube, suscriptores_min, suscriptores_max, categoria_max
    )
    
    for cupituber in cupitubers_filtrados:
        fecha = cupituber.get('started', '')
        descripcion = cupituber.get('description', '')
        videos = cupituber.get('video_count', 0)  # Nota: es "video_count", no "videos_count"
        if (fecha_minima <= fecha <= fecha_maxima and
            videos >= videos_minimos and
            palabra_clave.lower() in descripcion.lower()):
            return cupituber
    return {}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
#TODO 9: Implemente la función tal y como se describe en la documentación.
   categorias_paises = {}
   for pais in cupitube:
       lista_cupitubers = cupitube[pais]
       for cupituber in lista_cupitubers:
            categoria = cupituber.get("category", "").strip().lower()
            if categoria != "":
                if categoria not in categorias_paises:
                    categorias_paises[categoria] = []
                if pais not in categorias_paises[categoria]:
                    categorias_paises[categoria].append(pais)
   return categorias_paises