def limpiar (lista:list)->list:
    text = "ManZ$a!na#baNA%no#mAnG!o"
    palabras =text.split("#")
    texto_corregido = ""
    for palabra in palabras:
        for letra in palabra:
            if letra.isalnum():
                palabra.append(letra)
        texto_corregido +=palabra.lower()
        
    lista.append(texto_corregido)   
    return lista
        
def sisi (lista:list)->list:
    
    for letra in lista:
        if letra.isalnum():
            lista.append(letra)
    return lista
            
