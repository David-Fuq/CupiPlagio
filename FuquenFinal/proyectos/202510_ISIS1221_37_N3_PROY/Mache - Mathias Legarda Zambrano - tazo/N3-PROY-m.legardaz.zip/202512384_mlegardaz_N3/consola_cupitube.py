#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
import cupitube as ct
###### Funciones auxiliares (NO MODIFICAR):
# Función auxiliar que muestra la información de un CupiTuber
def mostrar_cupituber(cupituber: dict) -> None:
    """
    Muestra la información de un CupiTuber.
    
    Parámetros:
        cupituber (dict): Diccionario con la información del CupiTuber.
    """
    print("\n")
    print("#" * 50)
    print((
        "\nNombre: {}\n"
        "Ranking: {}\n"
        "Suscriptores: {}\n"
        "Visitas de videos: {}\n"
        "Cantidad de videos: {}\n"
        "Categoría: {}\n"
        "Año de inicio: {}\n"
        "Tipo de monetización: {}\n"
        "Descripción: {}\n"
    ).format(
        cupituber["cupituber"], cupituber["rank"], cupituber["subscribers"],
        cupituber["video_views"], cupituber["video_count"], cupituber["category"],
        cupituber["started"], cupituber["monetization_type"], cupituber["description"]
    ))
    print("#" * 50)

# Función auxiliar que muestra la información de múltiples CupiTubers
def mostrar_cupitubers(cupitubers: list) -> None:
    """
    Muestra la información de una lista de CupiTubers.
    
    Parámetros:
        cupitubers (list): Lista de diccionarios con la información de los CupiTubers.
    """
    print("\nCupiTubers encontrados:")
    print("-" * 50)
    
    for cupituber in cupitubers:
        mostrar_cupituber(cupituber)

    print("-" * 50)
    
# Función auxiliar que muestra los países de CupiTubers en una categoría específica.
def mostrar_paises(paises: list) -> None:
    """ 
    Muestra los países que tienen CupiTubers en una categoría específica.
    
    Parámetros:
        paises (list): Lista de nombres de países.
    """
    print("-" * 50)
    
    for pais in paises:
        print(pais)
    
    print("-" * 50)
###### Fin de las funciones auxiliares



# Funciones a implementar (solo aquellas con TODOs):

def ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ").strip().lower()
    minimo = int(input("Ingrese el mínimo de suscriptores: "))
    maximo = int(input("Ingrese el máximo de suscriptores: "))
    
    cupitubers = ct.buscar_por_categoria_y_rango_suscriptores(cupitube, minimo, maximo, categoria)
    
    if cupitubers != []:
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict) -> None:
    #TODO 10: Implemente la función tal y como se describe en la documentación.
    pais = input("Ingrese el país: ").strip().lower()
    categoria = input("Ingrese la categoría: ").strip().lower()
    monetizacion = input("Ingrese el tipo de monetización: ").strip().lower()

    cupitubers = ct.buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais, categoria, monetizacion)

    if cupitubers:
        print(f"Los CupiTubers de {pais} que pertenecen a la categoría {categoria} y tienen monetización {monetizacion} son:")
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")

        
def ejecutar_buscar_cupituber_mas_antiguo(cupitube: dict) -> None:
    #TODO 11: Implemente la función tal y como se describe en la documentación.
    cupituber = ct.buscar_cupituber_mas_antiguo(cupitube)

    if cupituber:
        print(f"El CupiTuber más antiguo es {cupituber['cupituber']} y empezó en {cupituber['started']}.")
    else:
        print("No se encontró un CupiTuber más antiguo.")


def ejecutar_obtener_visitas_por_categoria(cupitube: dict) -> None:
    #TODO 12: Implemente la función tal y como se describe en la documentación.
    categoria = input("Ingrese la categoría: ").strip().lower()
    total_visitas = ct.obtener_visitas_por_categoria(cupitube, categoria)

    print(f"El total de visitas para la categoría {categoria} es: {total_visitas}.")


def ejecutar_obtener_categoria_con_mas_visitas(cupitube: dict) -> None:
    #TODO 13: Implemente la función tal y como se describe en la documentación.
    resultado = ct.obtener_categoria_con_mas_visitas(cupitube)
    
    categoria = resultado["categoria"].strip().lower()
    visitas = resultado["visitas"]

    print(f"La categoría con más visitas es {categoria} con {visitas} visitas.")
    

    
def ejecutar_crear_correo_para_cupitubers(cupitube: dict) -> None:
    """ 
    Ejecuta la función de crear correos para CupiTubers.
    Ya se provee la implementación completa de esta función y no se requiere ningún cambio.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    A modo de ejemplo, se muestra el correo creado para el primer CupiTuber del país 'USA'.
    
    El mensaje tiene el siguiente formato:
        - "El correo para el primer Cupituber de 'USA' con nombre '[X]' es: [Y]."

        Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
        
        Donde:
            - [X] es el nombre del CupiTuber.
            - [Y] es el correo creado.
    """
    if cupitube:
        for pais in cupitube:
            cupitubers = cupitube[pais]
            if cupitubers:
                ct.crear_correo_para_cupitubers(cupitube)  # Crear los correos para todos los CupiTubers
                for cupituber in cupitubers:
                    if "correo" in cupituber and cupituber["correo"]:
                       print(f"El correo para el Cupituber '{cupituber['cupituber']}' de '{pais}' es: {cupituber['correo']}.")
                    else:
                       print(f"No se ha podido crear el correo para el Cupituber '{cupituber['cupituber']}' de '{pais}'.")
            else:
               print(f"No se encontraron CupiTubers en el país '{pais}' o la lista está vacía.")
    else:
       print("No se encontraron países en el diccionario 'cupitube'.")

def ejecutar_recomendar_cupituber(cupitube: dict) -> None:
    #TODO 14: Implemente la función tal y como se describe en la documentación.
    suscriptores_min = int(input("Ingrese el número mínimo de suscriptores: "))
    suscriptores_max = int(input("Ingrese el número máximo de suscriptores: "))
    fecha_minima = input("Ingrese la fecha mínima (YYYY-MM-DD): ")
    fecha_maxima = input("Ingrese la fecha máxima (YYYY-MM-DD): ")
    videos_minimos = int(input("Ingrese la cantidad mínima de videos: "))
    palabra_clave = input("Ingrese una palabra clave que debe estar en la descripción: ").strip()

    if palabra_clave == "":
        print("No se encontró un CupiTuber que cumpla con los criterios.")
        return

    recomendado = ct.recomendar_cupituber(
        cupitube,
        suscriptores_min,
        suscriptores_max,
        fecha_minima,
        fecha_maxima,
        videos_minimos,
        palabra_clave
    )

    if recomendado:
        print("El Cupituber recomendado tiene la siguiente información:")
        mostrar_cupituber(recomendado)
    else:
        print("No se encontró un CupiTuber que cumpla con los criterios.")
    
def ejecutar_paises_por_categoria(cupitube: dict) -> None:
    """ 
    Ejecuta la función que obtiene el diccionario de los países por categoría.
    Ya se provee la implementación completa de esta función y no se requiere ningún cambio.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Se debe pedir al usuario una categoría y mostrar los países que tienen CupiTubers en esa categoría.
    
    Hay dos casos posibles:
        - Si no se encuentra la categoría, el mensaje es:
            - "La categoría ingresada no existe en los datos."
    
        - Caso contrario, el mensaje debe tener el siguiente formato:
            - "Los países con CupiTubers en la categoría [X] son:"
        
            Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
        
            Donde:
                - [X] es el nombre de la categoría ingresada por el usuario.
            
        - Luego, use la función auxiliar mostrar_paises() para mostrar la información de los países encontrados.
    """
    categorias_paises = ct.paises_por_categoria(cupitube)  # Obtención de los países por categoría

    # Pedir al usuario que ingrese una categoría
    categoria_input = input("Ingresa la categoría para obtener los países: ").strip().lower()

    # Verificar si la categoría existe en el diccionario
    if categoria_input in categorias_paises:
        print(f"Los países con CupiTubers en la categoría {categoria_input} son:")
        # Mostrar los países directamente
        for pais in categorias_paises[categoria_input]:
            print(f"- {pais}")
    else:
        print("La categoría ingresada no existe en los datos.")

###### Funciones del ménu (NO MODIFICAR):
def iniciar_aplicacion() -> None:
    """
    Función principal de la aplicación.
    """
    ejecutando = False
    archivo = input("Ingrese el nombre del archivo de datos o presione Enter si su archivo se llama cupitube.csv: ")
    
    if archivo == "":
        archivo = "cupitube.csv"
        
    estados = ct.cargar_cupitube(archivo)
    if estados != {} and estados is not None:
        ejecutando = True
        print("#" * 50)
        print("¡Bienvenido a la aplicación de CupiTube!")
        print("#" * 50)
    
        while ejecutando:
            ejecutando = mostrar_menu_aplicacion(estados)
            if ejecutando:
                input("Presione Enter para continuar...")
    else:
        print("\nError: No se ha podido cargar el archivo. \nRevise su implementación de la función: cargar_cupitube() en cupitube.py")
      
            
# Función para mostrar el menú de la aplicación:
def mostrar_menu_aplicacion(cupitube: dict) -> bool:
    """ 
    Muestra el menú de la aplicación y ejecuta la opción seleccionada por el usuario.
    """
    print("\nMenú de opciones:")
    print("1. Buscar CupiTubers por categoría y rango de suscriptores.")
    print("2. Buscar CupiTubers por país, categoría y monetización.")
    print("3. Buscar CupiTuber más antiguo.")
    print("4. Obtener visitas para una categoría.")
    print("5. Obtener categoría con más visitas.")
    print("6. Crear correo para CupiTubers.")
    print("7. Recomendar un CupiTuber.")
    print("8. Obtener países por categoría.")
    print("9. Salir.")

    opcion_elegida = input("Ingrese la opción que desea ejecutar: ").strip()

    continuar_ejecutando = True

    if opcion_elegida == "1":
        ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube)
    elif opcion_elegida == "2":
        ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube)
    elif opcion_elegida == "3":
        ejecutar_buscar_cupituber_mas_antiguo(cupitube)
    elif opcion_elegida == "4":
        ejecutar_obtener_visitas_por_categoria(cupitube)
    elif opcion_elegida == "5":
        ejecutar_obtener_categoria_con_mas_visitas(cupitube)
    elif opcion_elegida == "6":
        ejecutar_crear_correo_para_cupitubers(cupitube)
    elif opcion_elegida == "7":
        ejecutar_recomendar_cupituber(cupitube)
    elif opcion_elegida == "8":
        ejecutar_paises_por_categoria(cupitube)
    elif opcion_elegida == "9":
        print("\n¡Gracias por usar la aplicación de CupiTube!")
        continuar_ejecutando = False
    else:
        print("Opción inválida. Por favor inténtelo de nuevo.")

    return continuar_ejecutando
###### Fin de las funciones del menú


# Punto de entrada de la aplicación
if __name__ == "__main__":
    iniciar_aplicacion()