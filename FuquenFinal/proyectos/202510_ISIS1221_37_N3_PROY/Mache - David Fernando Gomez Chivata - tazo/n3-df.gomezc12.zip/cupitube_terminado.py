# -*- coding: utf-8 -*-
"""
Created on Tue Apr 29 18:05:10 2025

@author: david
"""

"""
CupiTube
"""


#funcion 1 
def cargar_cupitube(archivo: str) -> dict:
    
    cupitubers = {}
    
    archivo_csv = open(archivo,"r", encoding="utf-8")
    titulos = archivo_csv.readline().strip().split(",")
        
    linea = archivo_csv.readline()
    while len(linea)>0:
        datos = linea.split(",")
        country = datos[7]
        
        cupituber = {
        "rank" : int(datos[0]),
        "cupituber" : datos[1],
        "subscribers" : int(datos[2]),
        "video_views" : int(datos[3]),
        "video_count" : int(datos[4]),
        "category" : datos[5],
        "started" : datos[6],
        "monetization_type" : datos[8],
        "description" : datos[9].strip()
        }
        
        if country not in cupitubers:
            cupitubers[country] = []
            
        cupitubers[country].append(cupituber)
        
        linea = archivo_csv.readline()
        
    archivo.close()
    return cupitubers



#funcion 2
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:

    busqueda_cupitube_1 = []
    
    for cupitubers in cupitube.values():
        for dato in cupitubers:
            if dato["category"] == categoria_buscada:
                if suscriptores_min <= dato["subscribers"] <= suscriptores_max:
                    busqueda_cupitube_1.append(dato)
    
    return busqueda_cupitube_1



#funcion 3
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:

    busqueda_cupitube_2 = []
    
    if pais_buscado in cupitube:
        for dato in cupitube[pais_buscado]:
            if dato["category"] == categoria_buscada and dato["monetization_type"] == monetizacion_buscada:
                busqueda_cupitube_2.append(dato)
                
    return busqueda_cupitube_2

    
    
#funcion 4
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    mas_antiguo = "3999-12-31"  

    busqueda_cupitube_3 = None

    for cupituber in cupitube.values():
        for dato in cupituber:
            if busqueda_cupitube_3 is None or dato["started"] < mas_antiguo:
                busqueda_cupitube_3 = dato
                mas_antiguo = dato["started"]  

    return busqueda_cupitube_3 



#funcion 5
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    visitas = 0  
   
    for cupituber in cupitube.values():
        for dato in cupituber:  
            if dato["category"] == categoria_buscada:
                visitas += dato["video_views"]  

    return visitas  



#funcion 6
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    visitas_por_categoria = {} 
    
    for cupitubers in cupitube.values():
        for dato in cupitubers:
            categoria = dato['category']
            video_views = dato['video_views']
            if categoria in visitas_por_categoria:
                visitas_por_categoria[categoria] += video_views
            else:
                visitas_por_categoria[categoria] = video_views

    categoria_max_visitas = max(visitas_por_categoria, key=visitas_por_categoria.get)

    return {
        "categoria": categoria_max_visitas,
        "visitas": visitas_por_categoria[categoria_max_visitas]
    }



#funcion 7
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for cupitubers in cupitube.values():
        for datos in cupitubers:
            nombre = datos["cupituber"]
            
            nombre_limpio = ''.join(dato for dato in nombre if dato.isalnum())
            
            nombre_limpio = nombre_limpio[:15]
            
            fecha = cupitubers["started"]
            anio = fecha[2:4]  
            mes = fecha[5:7]   
            
            correo = nombre_limpio.lower() + "." + anio + mes + "@cupitube.com"
            cupitubers["correo"] = correo
            
            

#funcion 8
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    if palabra_clave.strip() == "":
        return {}

    categoria_top = obtener_categoria_con_mas_visitas(cupitube)
    categoria_top = categoria_top["categoria"]

    for cupitubers in cupitube.values():
        for datos in cupitubers:
            if (datos["category"] == categoria_top and 
                suscriptores_min <= datos["subscribers"] <= suscriptores_max and 
                datos["started"] >= fecha_minima and 
                datos["started"] <= fecha_maxima and 
                datos["video_count"] >= videos_minimos and 
                palabra_clave.lower() in datos["description"].lower()):
                return datos

    return {}



#funcion 9
def paises_por_categoria(cupitube):
    
    categorias = {}
    
    for pais, cupitubers in cupitube.items():
        for datos in cupitubers:
            categoria = datos["category"]
            if categoria not in categorias:
                categorias[categoria] = []
            if pais not in categorias[categoria]:
                categorias[categoria].append(pais)
    
    return categorias






































