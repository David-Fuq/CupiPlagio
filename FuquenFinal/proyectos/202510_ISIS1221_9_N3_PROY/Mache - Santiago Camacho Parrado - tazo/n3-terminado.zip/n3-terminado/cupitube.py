#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    Paises = {}
    archivo = open(archivo, "r", encoding="utf-8")
    linea = archivo.readline()
    linea = archivo.readline().split(",")
    
    while len(linea) > 1:
        
        cupituber={}
        cupituber["rank"]=int(linea[0])
        cupituber["nombre"]=linea[1]
        cupituber["subscribers"]=int(linea[2])
        cupituber["video_views"]=int(linea[3])
        cupituber["video_count"]=int(linea[4])
        cupituber["category"]=linea[5]
        cupituber["started"]=linea[6]
        cupituber["monetization_type"]=linea[8]
        cupituber["description"]=linea[9]
        
        pais=linea[7]
        if pais in Paises:       
            listota=Paises[pais]
            listota.append(cupituber)
            Paises[pais]=listota
        else:
            actualista=[cupituber]
            Paises[pais]=actualista
        
        linea = archivo.readline().split(",")
            
        
        
    archivo.close()
    return Paises
paises=cargar_cupitube("C:/Users/santi/Downloads/n3-esqueleto/cupitube.csv")

def buscar_por_categoria_y_rango_suscriptores(Paises: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    cupitubers = []

    for pais in Paises:
        cupilista=Paises[pais]
        for cupituber in cupilista:
            categoria=cupituber["category"]
            suscriptores=cupituber["subscribers"]

            if categoria == categoria_buscada and suscriptores_min <= suscriptores <= suscriptores_max:
                cupitubers.append(cupituber)

    return cupitubers
    

resp = buscar_por_categoria_y_rango_suscriptores(paises, 1000000, 111000000, "Gaming")
print(len(resp))

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(Paises: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    cupitubers = []
    
    if pais_buscado in Paises:
    
        pais=Paises[pais_buscado]
    
    
        for cupituber in pais:
            categoria=cupituber["category"]
            monetizacion=cupituber["monetization_type"]
            
            if categoria == categoria_buscada and monetizacion == monetizacion_buscada :
                cupitubers.append(cupituber)

    return cupitubers

print(buscar_cupitubers_por_pais_categoria_monetizacion(paises, "UK", "Gaming", "Crowdfunding"))    



# Función 4:
def buscar_cupituber_mas_antiguo(paises: dict) -> dict:
    antiguo={}
    
    ref = "2027-12-31"
    
    for pais in paises:
        cupilista=paises[pais]
        for cupituber in cupilista:
            fechaformato2= cupituber["started"]
            if ref > fechaformato2:
                ref = fechaformato2
                antiguo=cupituber
    return antiguo


print(buscar_cupituber_mas_antiguo(paises))

def obtener_visitas_por_categoria(paises: dict, categoria_buscada: str) -> int:
    vistas = 0
    
    for pais in paises:
        cupilista=paises[pais]
        for cupituber in cupilista:
            categoria=cupituber["category"]
            if categoria == categoria_buscada:
                vistas += cupituber["video_views"]
    
    return vistas
    
print(obtener_visitas_por_categoria(paises, "Music"))   
    

def obtener_categoria_con_mas_visitas(paises: dict) -> dict:
    Categoriamasvista={"categoria":"", "visitas": ""}
    vistas = 0
    
    categorias = ["Pets & Animals", "Music", "Gaming", "Entertainment", "Sports", "News & Politics", "People & Blogs", "Comedy", "Science & Technology", "Trailers", "Howto & Style", "Education", "Film & Animation", "Shows", "Autos & Vehicles", "Nonprofits & Activism", "Travel & Events", "Movies"]
    for cadacategoria in categorias:
        vistastodo = obtener_visitas_por_categoria(paises, cadacategoria)
        if vistastodo > vistas:
            vistas=vistastodo
            Categoriamasvista["visitas"]=vistas
            Categoriamasvista["categoria"]=cadacategoria
        
    return Categoriamasvista

print(obtener_categoria_con_mas_visitas(paises))
        
    
def crear_correo_para_cupitubers(paises: dict) -> None:

    def correo(nombre: str, fecha: str) -> str:
        nombre_limpio = ""
        for letra in nombre:
            if letra.isalnum():
                nombre_limpio += letra
        nombre_limpio = nombre_limpio.lower()[:15]

        anio = fecha[2] + fecha[3]
        mes = fecha[5] + fecha[6]

        correo_generado = nombre_limpio + "." + anio + mes + "@cupitube.com"
        return correo_generado

    for pais in paises:
        cupilista = paises[pais]
        for cupituber in cupilista:
            nombre = cupituber["nombre"]
            fecha = cupituber["started"]
            cupituber["correo"] = correo(nombre, fecha)
crear_correo_para_cupitubers(paises)
print(paises)

# Función 8:
def recomendar_cupituber(paises: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    recomendacion = {}

    categoria_mas_vistas = obtener_categoria_con_mas_visitas(paises)["categoria"]
    palabra_clave = palabra_clave.lower()

    for pais in paises:
        for cupituber in paises[pais]:
            descripcion = cupituber["description"].lower()
            if (
                cupituber["category"] == categoria_mas_vistas and
                suscriptores_min <= cupituber["subscribers"] <= suscriptores_max and
                cupituber["video_count"] >= videos_minimos and
                fecha_minima <= cupituber["started"] <= fecha_maxima and
                palabra_clave in descripcion
            ):
                recomendacion = cupituber
                return recomendacion

    return recomendacion

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}

    for pais in paises:
        for cupituber in paises[pais]:
            categoria = cupituber["category"]

            if categoria not in resultado:
                resultado[categoria] = []

            if pais not in resultado[categoria]:
                resultado[categoria].append(pais)

    return resultado
