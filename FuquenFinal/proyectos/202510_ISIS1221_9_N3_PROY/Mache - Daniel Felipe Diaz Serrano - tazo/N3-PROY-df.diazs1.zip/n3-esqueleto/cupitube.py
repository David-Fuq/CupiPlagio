#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:   
    cupitubers_por_pais = {}
    archivo_csv = open(archivo, "r", encoding="utf-8")
    titulos = archivo_csv.readline().strip().split(",")

    linea = archivo_csv.readline()
    while len(linea) > 0:
        datos = linea.strip().split(",")
        pais = datos[7].strip()  # País

        cupituber = {}
        cupituber["rank"] = int(datos[0])
        cupituber["cupituber"] = datos[1].strip()
        cupituber["subscribers"] = int(datos[2])
        cupituber["video_views"] = int(datos[3])
        cupituber["video_count"] = int(datos[4])
        cupituber["category"] = datos[5].strip()
        cupituber["started"] = datos[6].strip()
        cupituber["monetization_type"] = datos[8].strip()
        cupituber["description"] = datos[9].strip()

        if pais not in cupitubers_por_pais:
            cupitubers_por_pais[pais] = []
        
        cupitubers_por_pais[pais].append(cupituber)

        linea = archivo_csv.readline()

    archivo_csv.close()
    return cupitubers_por_pais


def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resultado = []

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (cupituber["category"] == categoria_buscada and suscriptores_min <= cupituber["subscribers"] <= suscriptores_max):
                resultado.append(cupituber)
    
    return resultado


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    for pais in cupitube:
        if pais == pais_buscado:
            for cupituber in  cupitube[pais]:
                if cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
                    resultado.append(cupituber)
    return resultado
            



# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber

    return mas_antiguo

            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    conteo = 0
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada:
                conteo += cupituber["video_views"]
    return conteo


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categorias ={}
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            vistas = cupituber["video_views"]
            if categoria not in categorias:
                categorias[categoria] = 0
            categorias[categoria] += vistas
    categoria_maxima = None
    visitas_maximas = 0
    for cat in categorias:
        if categorias[cat]> visitas_maximas:
            visitas_maximas = categorias[cat]
            categoria_maxima = cat
    resultado ={"categoria": categoria_maxima,"visitas": visitas_maximas }
            
    return resultado


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre_original = cupituber["cupituber"]
            nombre_limpio = ""

            for caracter in nombre_original:
                if caracter.isalnum():
                    nombre_limpio += caracter
            nombre = nombre_limpio[:15]
            nombre = nombre.lower()
            fecha_inicio = cupituber["started"]
            anio = fecha_inicio[2:4] 
            mes = fecha_inicio[5:7]
            correo = nombre + "." + anio + mes + "@cupitube.com"
            cupituber["correo"] = correo



# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    categoriamax = obtener_categoria_con_mas_visitas(cupitube)
    categoria_maxima = categoriamax["categoria"]
    palabra_clave = palabra_clave.lower()
    por_subs = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria_maxima)
    for cupituber in por_subs:
            if ( fecha_minima <= cupituber["started"] <= fecha_maxima and palabra_clave in cupituber["description"].lower() and cupituber["video_count"]>= videos_minimos):
                return cupituber
    return {}


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    paises_por_cat = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]

            # Si la categoría no está en el diccionario, la creamos con una lista vacía
            if categoria not in paises_por_cat:
                paises_por_cat[categoria] = []

            # Agregamos el país si no está ya en la lista
            if pais not in paises_por_cat[categoria]:
                paises_por_cat[categoria].append(pais)

    return paises_por_cat

