#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

import cupitube as ct

###### Funciones auxiliares (NO MODIFICAR):
# Función auxiliar que muestra la información de un CupiTuber
def mostrar_cupituber(cupituber: dict) -> None:
    print("\n" + "#" * 50)
    print(
        f"\nNombre: {cupituber['cupituber']}\n"
        f"Ranking: {cupituber['rank']}\n"
        f"Suscriptores: {cupituber['subscribers']}\n"
        f"Visitas de videos: {cupituber['video_views']}\n"
        f"Cantidad de videos: {cupituber['video_count']}\n"
        f"Categoría: {cupituber['category']}\n"
        f"Año de inicio: {cupituber['started']}\n"
        f"Tipo de monetización: {cupituber['monetization_type']}\n"
        f"Descripción: {cupituber['description']}\n"
    )
    print("#" * 50)

# Función auxiliar que muestra la información de múltiples CupiTubers
def mostrar_cupitubers(cupitubers: list) -> None:
    print("\nCupiTubers encontrados:")
    print("-" * 50)
    for cupi in cupitubers:
        mostrar_cupituber(cupi)
    print("-" * 50)

# Función auxiliar que muestra los países de CupiTubers en una categoría específica.
def mostrar_paises(paises: list) -> None:
    print("\nPaíses en esta categoría:")
    print("-" * 50)
    for pais in paises:
        print(pais)
    print("-" * 50)
###### Fin de las funciones auxiliares

# Funciones a implementar:

def ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ")
    minimo = int(input("Ingrese el mínimo de suscriptores: "))
    maximo = int(input("Ingrese el máximo de suscriptores: "))
    cupis = ct.buscar_por_categoria_y_rango_suscriptores(cupitube, minimo, maximo, categoria)
    if cupis:
        mostrar_cupitubers(cupis)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict) -> None:
    pais = input("Ingrese el país: ")
    categoria = input("Ingrese la categoría: ")
    monetizacion = input("Ingrese el tipo de monetización: ")
    encontrados = ct.buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais, categoria, monetizacion)
    if encontrados:
        print(f"Los CupiTubers de {pais} que pertenecen a la categoría {categoria} y tienen monetización {monetizacion} son:")
        mostrar_cupitubers(encontrados)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupituber_mas_antiguo(cupitube: dict) -> None:
    antiguo = ct.buscar_cupituber_mas_antiguo(cupitube)
    if antiguo:
        nombre = antiguo.get("cupituber", "")
        fecha = antiguo.get("started", "")
        print(f"El CupiTuber más antiguo es {nombre} y empezó en {fecha}.")
    else:
        print("No hay datos de CupiTubers.")


def ejecutar_obtener_visitas_por_categoria(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ")
    total = ct.obtener_visitas_por_categoria(cupitube, categoria)
    print(f"El total de visitas para la categoría {categoria} es: {total}.")


def ejecutar_obtener_categoria_con_mas_visitas(cupitube: dict) -> None:
    info = ct.obtener_categoria_con_mas_visitas(cupitube)
    cat = info.get("categoria", "")
    vis = info.get("visitas", 0)
    print(f"La categoría con más visitas es {cat} con {vis} visitas.")


def ejecutar_crear_correo_para_cupitubers(cupitube: dict) -> None:
    if "USA" in cupitube and cupitube["USA"]:
        ct.crear_correo_para_cupitubers(cupitube)
        c = cupitube["USA"][0]
        print(f"El correo para el primer Cupituber de 'USA' con nombre '{c['cupituber']}' es: {c['correo']}." )


def ejecutar_recomendar_cupituber(cupitube: dict) -> None:
    min_subs = int(input("Ingrese el mínimo de suscriptores: "))
    max_subs = int(input("Ingrese el máximo de suscriptores: "))
    fecha_min = input("Ingrese la fecha mínima (YYYY-MM-DD): ")
    fecha_max = input("Ingrese la fecha máxima (YYYY-MM-DD): ")
    min_videos = int(input("Ingrese la cantidad mínima de videos: "))
    palabra = input("Ingrese la palabra clave: ")
    recomendado = ct.recomendar_cupituber(cupitube, min_subs, max_subs, fecha_min, fecha_max, min_videos, palabra)
    if recomendado and palabra.strip():
        print("El Cupituber recomendado tiene la siguiente información:")
        mostrar_cupituber(recomendado)
    else:
        print("No se encontró un CupiTuber que cumpla con los criterios.")


def ejecutar_paises_por_categoria(cupitube: dict) -> None:
    estructura = ct.paises_por_categoria(cupitube)
    categoria = input("Ingrese la categoría: ")
    if categoria in estructura:
        print(f"Los países con CupiTubers en la categoría {categoria} son:")
        mostrar_paises(estructura[categoria])
    else:
        print("La categoría ingresada no existe en los datos.")

###### Funciones del menú (NO MODIFICAR):
def mostrar_menu_aplicacion(cupitube: dict) -> bool:
    print("\nMenú de opciones:")
    opciones = [
        "1. Buscar CupiTubers por categoría y rango de suscriptores.",
        "2. Buscar CupiTubers por país, categoría y monetización.",
        "3. Buscar CupiTuber más antiguo.",
        "4. Obtener visitas para una categoría.",
        "5. Obtener categoría con más visitas.",
        "6. Crear correo para CupiTubers.",
        "7. Recomendar un CupiTuber.",
        "8. Obtener países por categoría.",
        "9. Salir."
    ]
    for op in opciones:
        print(op)
    elec = input("Ingrese la opción que desea ejecutar: ").strip()
    acciones = {
        "1": ejecutar_buscar_por_categoria_y_rango_suscriptores,
        "2": ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion,
        "3": ejecutar_buscar_cupituber_mas_antiguo,
        "4": ejecutar_obtener_visitas_por_categoria,
        "5": ejecutar_obtener_categoria_con_mas_visitas,
        "6": ejecutar_crear_correo_para_cupitubers,
        "7": ejecutar_recomendar_cupituber,
        "8": ejecutar_paises_por_categoria
    }
    if elec == "9":
        print("\n¡Gracias por usar la aplicación de CupiTube!")
        return False
    if elec in acciones:
        acciones[elec](cupitube)
    else:
        print("Opción inválida. Intente de nuevo.")
    return True


def iniciar_aplicacion() -> None:
    archivo = input("Ingrese el nombre del archivo de datos o presione Enter si es cupitube.csv: ").strip()
    if not archivo:
        archivo = "cupitube.csv"
    datos = ct.cargar_cupitube(archivo)
    if datos:
        print("#" * 50)
        print("¡Bienvenido a la aplicación de CupiTube!")
        print("#" * 50)
        ejecutar = True
        while ejecutar:
            ejecutar = mostrar_menu_aplicacion(datos)
            if ejecutar:
                input("Presione Enter para continuar...")
    else:
        print("\nError: No se ha podido cargar el archivo. Revise cargar_cupitube() en cupitube.py")

if __name__ == "__main__":
    iniciar_aplicacion()



