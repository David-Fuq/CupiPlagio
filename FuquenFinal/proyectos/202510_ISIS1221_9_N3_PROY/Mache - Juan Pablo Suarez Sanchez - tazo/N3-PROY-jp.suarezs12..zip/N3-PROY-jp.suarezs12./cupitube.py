def cargar_cupitube(archivo: str) -> dict:
    leer = {}
    cupitube = open(archivo, "r", encoding="utf-8")
    cupitube.readline()
    linea = cupitube.readline()
    while linea != "":
        partes = linea.strip().split(",")
        if len(partes) >= 10:
            rank = int(partes[0])
            nombre = partes[1].strip()
            subs = int(partes[2])
            vistas = int(partes[3])
            videos = int(partes[4])
            categoria = partes[5].strip()
            inicio = partes[6].strip()
            pais = partes[7].strip()
            monet = partes[8].strip()
            descripcion = partes[9].strip()

            info = {
                "rank": rank,
                "cupituber": nombre,
                "subscribers": subs,
                "video_views": vistas,
                "video_count": videos,
                "category": categoria,
                "started": inicio,
                "monetization_type": monet,
                "description": descripcion }

            if pais not in leer:
                leer[pais] = []
            leer[pais].append(info)
        linea = cupitube.readline()
    cupitube.close()
    return leer

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    result = []
    for pais in cupitube:
        for recorrer in cupitube[pais]:
            if recorrer["category"] == categoria_buscada and suscriptores_min <= recorrer["subscribers"] <= suscriptores_max:
                result.append(recorrer)
    return result

def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    for pais in cupitube:
        if pais == pais_buscado:
            i = 0
            while i < len(cupitube[pais]):
                cupituber = cupitube[pais][i]
                if cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
                    resultado.append(cupituber)
                i += 1
    return resultado

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None
    for pais in cupitube:
        for c in cupitube[pais]:
            if mas_antiguo is None or c["started"] < mas_antiguo["started"]:
                mas_antiguo = c
    return mas_antiguo

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0
    for pais in cupitube:
        for c in cupitube[pais]:
            if c["category"] == categoria_buscada:
                total += c["video_views"]
    return total

def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_categoria = {}
    for pais in cupitube:
        for c in cupitube[pais]:
            b = c["category"]
            if b not in visitas_categoria:
                visitas_categoria[b] = 0
            visitas_categoria[b] += c["video_views"]
    mayor_categoria = ""
    mayor_visitas = -1
    for b in visitas_categoria:
        if visitas_categoria[b] > mayor_visitas:
            mayor_categoria = b
            mayor_visitas = visitas_categoria[b]
    return {"categoria": mayor_categoria, "visitas": mayor_visitas}

def crear_correo_para_cupitubers(cupitube: dict) -> None:
    letras_numeros = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    for pais in cupitube:
        for c in cupitube[pais]:
            nombre = ""
            for ch in c["cupituber"]:
                if ch in letras_numeros:
                    nombre += ch
            nombre = nombre[:15].lower()
            anio = c["started"][2:4]
            mes = c["started"][5:7]
            correo = nombre + "." + anio + mes + "@cupitube.com"
            c["correo"] = correo

def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    if palabra_clave.strip() == "":
        return {}
    categoria_info = obtener_categoria_con_mas_visitas(cupitube)
    mejor_categoria = categoria_info["categoria"]
    palabra = palabra_clave.lower()

    for pais in cupitube:
        for c in cupitube[pais]:
            if (c["category"] == mejor_categoria and
                suscriptores_min <= c["subscribers"] <= suscriptores_max and
                fecha_minima <= c["started"] <= fecha_maxima and
                c["video_count"] >= videos_minimos and
                palabra in c["description"].lower()):
                return c
    return {}

def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}
    for pais in cupitube:
        for c in cupitube[pais]:
            cat = c["category"]
            if cat not in resultado:
                resultado[cat] = []
            if pais not in resultado[cat]:
                resultado[cat].append(pais)
    return resultado
