#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    datos = {}
    archivo = open(archivo, "r", encoding="utf-8")
    
    archivo.readline()  
    
    linea = archivo.readline()
    while len(linea) > 0:
        linea = linea.strip()
        posicion = linea.split(",")

        cupituber = {
            "rank": int(posicion[0]),
            "cupituber": posicion[1],
            "subscribers": int(posicion[2]),
            "video_views": int(posicion[3]),
            "video_count": int(posicion[4]),
            "category": posicion[5],
            "started": posicion[6],
            "country": posicion[7],
            "monetization_type": posicion[8],
            "description": posicion[9]
        }
        
        pais = posicion[7]
        if pais not in datos:
            datos[pais]= [cupituber]
        else:
       
            datos[pais].append(cupituber)
        
        linea = archivo.readline()
    
    archivo.close()
    return (datos)



# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    lista = [] 
    paises = cupitube.keys()
    for pais in paises:
        lista_cupitubers = cupitube[pais]

        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]

            if categoria == categoria_buscada:
                if suscriptores >= suscriptores_min and suscriptores <= suscriptores_max:
                    lista.append(cupituber)
    return lista
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    lista = []

    if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]

       
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            monetizacion = cupituber["monetization_type"]

            
            if categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                lista.append(cupituber)
    
   
    return lista


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    lista_paises = list(cupitube.keys())[0]
    antiguo = cupitube[lista_paises][0]

    
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            if cupituber["started"] < antiguo["started"]:
                antiguo = cupituber

    return antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    vistas = 0  

    for lista_cupitubers in cupitube.values(): 
        for cupituber in lista_cupitubers: 
            if cupituber["category"] == categoria_buscada:
                vistas += cupituber["video_views"]  

    return vistas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    vistas_categoria = {}

    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            vistas = cupituber["video_views"]

            if categoria not in vistas_categoria:
                vistas_categoria[categoria] = 0
            
            vistas_categoria[categoria] += vistas

    categorias = list(vistas_categoria.keys())
    categoria_max = categorias[0]
    vistas_max = vistas_categoria[categoria_max]

    for categoria in categorias:
        if vistas_categoria[categoria] > vistas_max:
            categoria_max = categoria
            vistas_max = vistas_categoria[categoria]

    return {"categoria": categoria_max, "vistas": vistas_max}

   


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
   
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            nombre = cupituber["cupituber"]
            fecha = cupituber["started"]

            fecha_separada = fecha.split("-")
            anio = fecha_separada[0]
            anio_mod = anio[2:4]
            mes = fecha_separada[1]
            nombre_mod = ""
            for i in nombre:
                if str.isalnum(i) == True:
                    nombre_mod +=i
            i=0
            while i < len(nombre) and i < 15:
                    correo = "{}.{}{}@cupitube.com".format(nombre_mod,anio_mod,mes)
                    cupituber["correo"] = correo.lower()
                    i+=1


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    visitas_categoria= obtener_categoria_con_mas_visitas(cupitube)
    categoria_max = visitas_categoria["categoria"]
    visitas_max = visitas_categoria["vistas"]

   
    palabra_clave = palabra_clave.lower()

    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            suscriptores = cupituber["subscribers"]
            fecha = cupituber["started"]
            videos = cupituber["video_count"]
            descripcion = cupituber["description"].lower()

            if (cupituber["category"] == categoria_max and
                suscriptores_min <= suscriptores <= suscriptores_max and
                fecha_minima <= fecha <= fecha_maxima and
                videos >= videos_minimos and
                palabra_clave in descripcion):
                return cupituber

    return {} 
# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    paises_categorias= {}

    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            pais = cupituber["country"]

            if categoria not in paises_categorias:
                paises_categorias[categoria] = []

            if pais not in paises_categorias[categoria]:
                paises_categorias[categoria].append(pais)

    return paises_categorias