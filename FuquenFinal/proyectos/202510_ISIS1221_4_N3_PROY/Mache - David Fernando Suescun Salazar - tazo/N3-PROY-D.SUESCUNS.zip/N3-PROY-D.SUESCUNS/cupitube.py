
def cargar_cupitube(archivo: str) -> dict:
    paises = {} 
    archivo1 = open(archivo, "r", encoding="utf-8")

    archivo1.readline()

    for columna in archivo1:
        lista_columna = columna.strip().split(",", 9)  
          
        
        country = lista_columna[7].strip()
        
        tuber = {}
        tuber["rank"] = int(lista_columna[0])
        tuber["cupituber"] = lista_columna[1]
        tuber["subscribers"] = int(lista_columna[2])
        tuber["video_views"] = int(lista_columna[3])
        tuber["video_count"] = int(lista_columna[4])
        tuber["category"] = lista_columna[5]
        tuber["started"] = lista_columna[6]
        tuber["country"] = lista_columna[7]
        tuber["monetization_type"] = lista_columna[8]
        tuber["description"] = lista_columna[9].strip()

        ar = paises.get(country, [])
        ar.append(tuber)
        paises[country] = ar 

    archivo1.close()
    return paises



    
    
        

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    cupitubers= []
    for pais in cupitube:   
     for tuber in cupitube[pais]:
           if tuber["category"].strip().lower()==categoria_buscada.strip().lower():
            if int(tuber["subscribers"])>=suscriptores_min and int(tuber["subscribers"])<=suscriptores_max:
                cupitubers.append(tuber)
    return cupitubers
                


def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cupituber= []
    for pais in cupitube: 
      for tuber in cupitube[pais]:
            if tuber["category"].strip().lower()== categoria_buscada.strip().lower():
                if tuber["monetization_type"].strip().lower()== monetizacion_buscada.strip().lower():
                    if tuber["country"].strip().lower()== pais_buscado.strip().lower():
                        cupituber.append(tuber)
    return cupituber 

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    tuber_antiguo= None
    for pais in cupitube: 
     for tuber in cupitube[pais]:
         if tuber_antiguo is None:
             tuber_antiguo=tuber
         elif tuber["started"].strip().lower() < tuber_antiguo["started"].strip().lower():
            tuber_antiguo= tuber 
    
    return tuber_antiguo

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    vistas_portuber= 0 
    for pais  in cupitube: 
     for tuber in cupitube[pais]:
        if categoria_buscada.strip().lower() == tuber["category"].strip().lower() and tuber["video_views"]> 0:
             vistas_portuber += tuber["video_views"]
    
    return vistas_portuber

def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
        visitas_categoria={}
        for pais in cupitube: 
         for tuber in cupitube[pais]: 
           
            categoria=tuber["category"].strip().lower()
            visitas= tuber["video_views"]
           
        if visitas <0:
          if tuber["category"].strip().lower() in visitas_categoria:
                   visitas_categoria[categoria]+= visitas
      
        else:
                   visitas_categoria= visitas 
                   
        categoria_masvista= ""
        max_visitas= -1
        
        for total_devistas, categoria in visitas_categoria.items(): 
            if total_devistas < max_visitas:
                max_visitas= total_devistas
                categoria_masvista = categoria
            
        return {"categoria": categoria_masvista, "visitas": max_visitas}
    
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube: 
        for tuber in cupitube[pais]: 
            nombre = tuber["cupituber"]
            nombre_sinnada = ""
        
            for letra in nombre: 
                if letra.isalnum():
                    nombre_sinnada += letra 
            nombre_sinnada = nombre_sinnada[:15]
            
            ano = tuber["started"][2:4]
            mes = tuber["started"][5:7]
            fecha = f"{ano}{mes}"
            
            correo = f"{nombre_sinnada}.{fecha}@cupitube.com"
            tuber["correo"] = correo.lower()

    
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    cupituber_recomendado = {}
    palabra_clave = palabra_clave.strip().lower()
    for pais in cupitube:
        for tuber in cupitube[pais]: 
            if palabra_clave in tuber["description"].strip().lower() and videos_minimos <= tuber["video_count"]:
                if tuber["started"] <= fecha_maxima and tuber["started"] >= fecha_minima: 
                    if tuber["subscribers"] <= suscriptores_max and tuber["subscribers"] >= suscriptores_min:
                        return tuber 
    return cupituber_recomendado 

    

def paises_por_categoria(cupitube: dict) -> dict:
    paises_categoria = {}

    for pais in cupitube:
        for tuber in cupitube[pais]:
            pais_tuber = tuber["country"].strip()
            categoria = tuber["category"].strip().lower()

            if categoria not in paises_categoria:
                paises_categoria[categoria] = []

            if pais_tuber not in paises_categoria[categoria]:
                paises_categoria[categoria].append(pais_tuber)

    return paises_categoria



    
    
    
                
                    
        
            
    
    
    
        
    
    
    
    
               
                


                    
                  
                    
                  



                
            
    
    
  
  
        
        
        
    
    
    
        
    
    
    
  
  
    