#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
   
    
    cupitube={}
     
    vinculo = open(archivo, "r", encoding="utf-8")
    encabezados= vinculo.readline().strip()
 
    lineas= vinculo.readline().strip()
    
    while lineas!="":
            columnas=lineas.split(",")
            pais = columnas[7].strip()
            cupituber = {
             "rank": int(columnas[0]),
             "cupituber": columnas[1],
             "subscribers": int(columnas[2]),
             "video_views": int(columnas[3]),
             "video_count": int(columnas[4]),
             "category": columnas[5].strip(),
             "started": columnas[6].strip(),
             "monetization_type": columnas[8],
             "description": columnas[9]
             }
            
    
           
            if pais not in cupitube:
                cupitube[pais]=[]
            cupitube[pais].append(cupituber)
            
            lineas=vinculo.readline().strip()

    vinculo.close()
    
    return cupitube


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
   
    cupitubers_encontrados=[]
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada:
                if cupituber["subscribers"]>= suscriptores_min and cupituber["subscribers"]<= suscriptores_max:
                   cupitubers_encontrados.append(cupituber)
    return cupitubers_encontrados


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
   
    

    cupitubers_encontrados=[]
    for pais in cupitube:
        
        if pais==pais_buscado:
            for cupituber in cupitube[pais]:
               
                if cupituber["category"] == categoria_buscada and cupituber["monetization_type"]== monetizacion_buscada :
                    cupitubers_encontrados.append(cupituber)
                
    
    return cupitubers_encontrados


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
   

    mas_antiguo="2025-05-30"
    cupituber_mas_antiguo={}
    for pais in cupitube:
         for cupituber in cupitube[pais]:
             if cupituber.get("started")<mas_antiguo:
                 mas_antiguo=cupituber.get("started")
                 cupituber_mas_antiguo=cupituber
             
    return cupituber_mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
   
    vistas_totales=0
    for pais in cupitube:
         for cupituber in cupitube[pais]:
             if cupituber["category"]== categoria_buscada:
                 vistas_totales+= cupituber.get("video_views")
    return vistas_totales
    

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    vistas_categoria={}
    categoria_mas_vistas={}
    mas_vista=0
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria=cupituber["category"]
            vistas=cupituber["video_views"]
            if categoria  in vistas_categoria:
                vistas_categoria[categoria]+=vistas
            else:
                vistas_categoria[categoria]=vistas
  
   
    for categoria in vistas_categoria:
        visitas_totales= vistas_categoria[categoria]
        if visitas_totales > mas_vista:
            mas_vista= visitas_totales
            categoria_mas_vistas["categoria"] = categoria
            categoria_mas_vistas["visitas"] = mas_vista
   
            
           
    return categoria_mas_vistas
  

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    correo=""
   
   
  
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            x=""
            y=""
            z=""
            
            nombre_og=cupituber["cupituber"]
            for letra in nombre_og:
                if letra.isalnum():
                    x+=letra
            x=x[:15]
            
            y=cupituber["started"][2:4]
            z=cupituber["started"][5:7]
            correo= x+"."+y+z+"@cupitube.com"
            cupituber["correo"]=correo.lower()
   


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
   
   
    
    cupituber_recomendado={}
    posibles_recomendados=[]
    categoria_buscada= obtener_categoria_con_mas_visitas(cupitube)
    mas_vista=categoria_buscada.get("categoria")
    palabra_clave = palabra_clave.lower()
   
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"]== mas_vista :
              if cupituber["subscribers"]>= suscriptores_min and cupituber["subscribers"]<= suscriptores_max:
                  if cupituber["started"]>= fecha_minima and cupituber["started"]<= fecha_maxima:
                      if cupituber["video_count"]>= videos_minimos:
                          if palabra_clave in cupituber["description"].lower():
                              
                              posibles_recomendados.append(cupituber)

    if len(posibles_recomendados)>0:
        cupituber_recomendado=posibles_recomendados[0]
    
    return cupituber_recomendado

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
   
    categorias_paises={}
   
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria=cupituber.get("category")
            
            if categoria not in categorias_paises :
                categorias_paises[categoria] = []
            if pais not in categorias_paises[categoria]:
                categorias_paises[categoria].append(pais)

    return categorias_paises
        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
             
