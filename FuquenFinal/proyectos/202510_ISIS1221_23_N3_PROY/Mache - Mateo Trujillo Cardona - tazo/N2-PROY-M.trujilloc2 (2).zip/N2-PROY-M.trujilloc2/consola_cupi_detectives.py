#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiDetectives
"""

import cupi_detectives as cd

####
# Funciones auxiliares (NO se deben modificar):

# Función auxiliar que muestra la información de un sospechoso.
# La función es usada por: ejecutar_buscar_por_codigo(), ejecutar_encontrar_sospechoso_con_mayor_probabilidad() e iniciar_aplicacion()
def mostrar_sospechoso(sospechoso: dict) -> None:
    """
    Muestra los datos de un sospechoso en la consola.

    Parámetros:
        sospechoso (dict): Los datos del sospechoso.
    """
    if sospechoso is not None and sospechoso != {}:
        codigo = sospechoso["codigo"]
        nombre = sospechoso["nombre"]
        edad = sospechoso["edad"]
        altura = sospechoso["altura"]
        pantalon = sospechoso["pantalon"]
        camisa = sospechoso["camisa"]
        usaba_gafas = sospechoso["usaba_gafas"]
        salon = sospechoso["salon"]
        coartada_confirmada = sospechoso["coartada_confirmada"]
        huellas_confirmadas = sospechoso["huellas_confirmadas"]
        
        print(
            "\nCódigo: {}\nNombre: {}\nEdad: {}\nAltura (en metros): {}\n"
            "Pantalón: {}\nCamisa: {}\nUsaba gafas: {}\n"
            "Salón: {}\nCoartada confirmada: {}\nHuellas confirmadas: {}".format(
                codigo, 
                nombre, 
                edad, 
                altura,
                pantalon, 
                camisa, 
                usaba_gafas,
                salon, 
                coartada_confirmada, 
                huellas_confirmadas
            )
        )
        
    else:
        print("\nError: No se ha proporcionado un diccionario válido con la información de un sospechoso.")
        
# Función auxiliar que muestra el perfil del presunto culpable.
# La función es usada únicamente por: iniciar_aplicacion()
def mostrar_perfil_culpable(culpable: dict) -> None:
    """
    Muestra el perfil del presunto culpable en la consola.
    
    Parámetros:
        culpable (dict): Los datos del culpable.
    """
    if culpable is not None and culpable != {}:
        edad_estimada = culpable["edad_estimada"]
        altura_estimada = culpable["altura_estimada"]
        color_pantalon = culpable["color_pantalon"]
        color_camisa = culpable["color_camisa"]
        usaba_gafas = culpable["usaba_gafas"]
        salon_incidente = culpable["salon_incidente"]
        
        print(
            "\nEdad estimada: {}\nAltura estimada (en metros): {}\n"
            "Color de pantalón: {}\nColor de camisa: {}\n"
            "Usaba gafas: {}\nSalón en donde estaba: {}".format(
                edad_estimada, 
                altura_estimada,
                color_pantalon, 
                color_camisa,
                usaba_gafas, 
                salon_incidente
            )
        )

    else:
        print("\nError: No se ha proporcionado un diccionario válido con la información del culpable.")
####




def ejecutar_buscar_por_codigo(s1: dict, s2: dict, s3: dict, s4: dict) -> None:
    """
    Función que ejecuta la opción de buscar a un sospechoso por su código. 
    
    Parámetros:
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
    
    El código debe ser solicitado al usuario. 
    
    Si existe un sospechoso con el código ingresado por el usuario, se debe mostrar los datos del mismo.
        Para ello, use la función auxiliar: mostrar_sospechoso().
    
    Si el sospechoso no existe, se debe mostrar el siguiente mensaje:
        "No se encontró un sospechoso con el código ingresado."
    """
    #TODO 9: Implemente la función tal y como se describe en la documentación.    
    codigo = int (input("ingrese el codigo") )
    respuesta = cd.buscar_por_codigo(codigo, s1, s2, s3, s4)
    if respuesta == {} :
        print ("No se encontró un sospechoso con el código ingresado.")
    else : 
        print (respuesta)
    
def ejecutar_filtrar_sospechosos_por_ubicacion(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> None:
    """
    Función que ejecuta la opción de filtrar los códigos de los sospechosos que estaban en el salón donde fue visto el presunto culpable.
    
    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable.
            De este diccionario, la lógica debe extraer el salón donde fue visto el presunto culpable al momento del incidente.
            
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
    
    Si se encontraron sospechosos que estaban en el salón, se debe mostrar el siguiente mensaje: 
        "Sospechosos en la ubicación del incidente (identificados por su código): [código_1, ..., código_n]"
    
        Donde:
            [código_1, ..., código_n] representa el o los códigos de los sospechosos que estaban en el salón dado, separados por coma, ejemplo: 2, 4
        
    Caso contrario, se debe mostrar el siguiente mensaje:
        "No se encontraron sospechosos en la ubicación del incidente."
    """
    #TODO 10: Implemente la función tal y como se describe en la documentación.    
    respuesta = cd.filtrar_sospechosos_por_ubicacion(perfil_culpable, s1, s2, s3, s4)
    if respuesta == "Ninguno":
        print("No se encontraron sospechosos en la ubicación del incidente.")
    else:
        print("Sospechosos en la ubicación del incidente (identificados por su código): "+ respuesta)
        
        

def ejecutar_filtrar_sospechosos_por_vestimenta(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> None:
    """
    Función que ejecuta la opción de filtra los códigos de los sospechosos que coincidan con el perfil del presunto culpable, 
    teniendo en cuenta el color de sus pantalones, el color de su camisa y el uso de gafas.
    
    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable.
            De este diccionario, la lógica debe extraer el color de pantalón, color de camisa y si usaba gafas el presunto culpable.
            
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
        
    Si se encontraron sospechosos se debe mostrar el siguiente mensaje: 
        "Sospechosos por vestimenta (identificados por su código): [código_1, ..., código_n]"
    
        Donde:
            [código_1, ..., código_n] representa el o los códigos de los sospechosos por vestimenta, separados por coma, ejemplo: 1, 2
            
    Caso contrario, se debe mostrar el siguiente mensaje:
        "No se encontraron sospechosos con vestimenta similar a la del presunto culpable."
    """
    #TODO 11: Implemente la función tal y como se describe en la documentación.
    respuesta= cd.filtrar_sospechosos_por_vestimenta(perfil_culpable, s1, s2, s3, s4)
    if respuesta == "Ninguno":
        print("No se encontraron sospechosos en la ubicación del incidente.")
    else:
        print("Sospechosos en la ubicación del incidente (identificados por su código): "+ respuesta)
        
    
def ejecutar_filtrar_sospechosos_por_edad_altura(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> None:
    """ 
    Función que ejecuta la opción de filtrar los códigos de los sospechosos por edad y altura estimada.
    
    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable.
            De este diccionario, la lógica debe extraer la edad y altura estimadas del presunto culpable.        
            
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.

    Si se encontraron sospechosos con características similares de edad y altura se debe mostrar el siguiente mensaje: 
        "Sospechosos por edad y altura (identificados por su código): [código_1, ..., código_n]"
    
        Donde:
            [código_1, ..., código_n] representa el o los códigos de los sospechosos por vestimenta, separados por coma, ejemplo: 1, 2
            
    Caso contrario, se debe mostrar el siguiente mensaje:
        "No se encontraron sospechosos con una edad y altura similares a las del presunto culpable."
    """
    #TODO 12: Implemente la función tal y como se describe en la documentación.
    respuesta = cd.filtrar_sospechosos_por_edad_altura(perfil_culpable, s1, s2, s3, s4)
    if respuesta == "" :
        print("No se encontraron sospechosos con una edad y altura similares a las del presunto culpable.")
    else :
        print ( "Sospechosos por edad y altura (identificados por su código): " + respuesta )
        

def ejecutar_calcular_probabilidad_de_culpabilidad(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> None:
    """ 
    Función que ejecuta la opción de calcular la probabilidad de que un sospechoso sea el culpable según su ubicación, vestimenta y características físicas.
    
    Parámetros:    
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable.
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
    
    El código debe ser solicitado al usuario. 
    
    Si se encontró al sospechoso se debe mostrar un mensaje como el siguiente:
        "La probabilidad de que el sospechoso con código: [X] sea el culpable es del: [Y]%"
        
        Donde:
            [X] es el código del sospechoso, ejemplo: 1
            [Y] es la probabilidad de que sea culpable como un porcentaje sin decimales, ejemplo: 100
               Debe usar la función `int()` de Python para quitar los decimales.
            
    Caso contrario, se debe mostrar el siguiente mensaje:
        "No se encontró ningún sospechoso con el código ingresado." 
    """
    #TODO 13: Implemente la función tal y como se describe en la documentación.
    codigo = int (input ( " ingrese el codigo "))
    respuesta = cd.calcular_probabilidad_de_culpabilidad(codigo, perfil_culpable, s1, s2, s3, s4)
    if respuesta == 0.0 :
        print ("No se encontró ningún sospechoso con el código ingresado." )
    else :
        print ("La probabilidad de que el sospechoso con código:" + codigo + "sea el culpable es del:" + respuesta )
        

def ejecutar_encontrar_sospechoso_con_mayor_probabilidad(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> None:
    """ 
    Función que ejecuta la opción de buscar al sospechoso con la mayor probabilidad de ser culpable.
    
    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable.
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
    
    Se debe mostrar la información del sospechoso con la mayor probabilidad de ser culpable.
        Para ello, use la función auxiliar: mostrar_sospechoso().
    """   
    #TODO 14: Implemente la función tal y como se describe en la documentación.
    


    
def iniciar_aplicacion() -> None:
    """
    Inicia la aplicación CupiDetectives creando los perfiles de los sospechosos y el del culpable, 
    muestra la información inicial y ejecuta el menú.
    """
    sospechoso1 = cd.crear_sospechoso(1, "Santiago", 25, 1.86, "Azul; Jeans; Largo", "Blanca; Cuello Redondo; Regular Fit", False, "ML-648", True, False)
    perfil_culpable = cd.crear_perfil_culpable(22, 1.75, "Negro", "Morada", True, "ML-610")
    
    if sospechoso1 is not None and perfil_culpable is not None:
        sospechoso2 = cd.crear_sospechoso(2, "Eric", 21, 1.75, "Negro; Bermuda; Largo", "Blanca; Cuello Polo; Slim Fit", True, "ML-610", False, False)
        sospechoso3 = cd.crear_sospechoso(3, "Gabriel", 34, 1.99, "Negro; Bermuda; Largo", "Morada; Cuello Tortuga; Tailored Fit", True, "ML-410", True, False)
        sospechoso4 = cd.crear_sospechoso(4, "Chu", 18, 1.65, "Negro; Bermuda; Corto", "Morada; Cuello Camisero; Oversize", True, "ML-610", False, True)
        
        BANDA = "*" * 60
        print("\n", BANDA, "\nPerfil del presunto sospechoso según Séneca:", sep='')
        print(BANDA)
        mostrar_perfil_culpable(perfil_culpable)
        print(BANDA, "\n")
        
        print(BANDA, "\nInformación de los 4 sospechosos:")
        print(BANDA)

        print("\nSospechoso 1 -> s1:\n")
        mostrar_sospechoso(sospechoso1)
        
        RAYA = "-" * 50
        print(RAYA, "\n\nSospechoso 2 -> s2:\n")
        mostrar_sospechoso(sospechoso2)
        
        print(RAYA, "\n\nSospechoso 3 -> s3:\n")
        mostrar_sospechoso(sospechoso3)
        
        print(RAYA, "\n\nSospechoso 4 -> s4:\n")
        mostrar_sospechoso(sospechoso4)
        
        print("\n", BANDA, "\n", sep='')
        
        ejecutando = True   
        
    else:
        print("\nError: Primero debe implementar las funciones crear_sospechoso() y crear_perfil_culpable() en: cupi_detectives.py")
        ejecutando = False
    
    while ejecutando:
        ejecutando = mostrar_menu_aplicacion(perfil_culpable, sospechoso1, sospechoso2, sospechoso3, sospechoso4)        
        
        if ejecutando:
            input("\nPresione cualquier tecla para continuar...")


def mostrar_menu_aplicacion(perfil_culpable: dict, sospechoso1: dict, sospechoso2: dict, sospechoso3: dict, sospechoso4: dict) -> bool:
    """
    Muestra el menú de la aplicación CupiDetectives y ejecuta la acción correspondiente según la opción seleccionada por el usuario.
    """
    print("\nMenú:")
    print(" 1 - Buscar sospechoso por código")
    print(" 2 - Filtrar sospechosos por ubicación")
    print(" 3 - Filtrar sospechosos por vestimenta")
    print(" 4 - Filtrar sospechosos por edad y altura")
    print(" 5 - Calcular probabilidad de culpa de un sospechoso")
    print(" 6 - Buscar sospechoso más probable")
    print(" 7 - Salir\n")
    
    opcion_elegida = input("Ingrese la opción que desea ejecutar: ").strip()
    
    BANDA = "*" * 80
    print("\n", BANDA, "\n", sep='')

    continuar_ejecutando = True
    
    if opcion_elegida == "1":
        ejecutar_buscar_por_codigo(sospechoso1, sospechoso2, sospechoso3, sospechoso4)
    elif opcion_elegida == "2":
        ejecutar_filtrar_sospechosos_por_ubicacion(perfil_culpable, sospechoso1, sospechoso2, sospechoso3, sospechoso4)
    elif opcion_elegida == "3":
        ejecutar_filtrar_sospechosos_por_vestimenta(perfil_culpable, sospechoso1, sospechoso2, sospechoso3, sospechoso4)
    elif opcion_elegida == "4":
        ejecutar_filtrar_sospechosos_por_edad_altura(perfil_culpable, sospechoso1, sospechoso2, sospechoso3, sospechoso4)
    elif opcion_elegida == "5":
        ejecutar_calcular_probabilidad_de_culpabilidad(perfil_culpable, sospechoso1, sospechoso2, sospechoso3, sospechoso4)
    elif opcion_elegida == "6":
        print("Información del sospechoso más probable:")
        ejecutar_encontrar_sospechoso_con_mayor_probabilidad(perfil_culpable, sospechoso1, sospechoso2, sospechoso3, sospechoso4)
        print("\nFINAL FELIZ: \nLos CupiDetectives corroboraron que el principal sospechoso, únicamente llevó a Edouardinho a un SPA,\ny nunca tuvo una mala intención :) :) :)")
    elif opcion_elegida == "7":
        continuar_ejecutando = False
    else:
        print("Opción inválida. Por favor intente de nuevo.")
    
    return continuar_ejecutando

if __name__ == "__main__":
    iniciar_aplicacion()    