#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiDetectives
"""

def crear_sospechoso(codigo: int, nombre: str, edad: int, altura: float, pantalon: str, camisa: str, usaba_gafas: bool, salon: str, coartada_confirmada: bool, huellas_confirmadas: bool) -> dict:
    """
    Crea un diccionario con la información de un sospechoso en el caso de la desaparición de Edouardinho.
    
    Las llaves del diccionario a crear y retornar deben llevar como nombre exactamente el mismo nombre de su parámetro respectivo.
    Por ejemplo: "codigo": codigo, "nombre": nombre, etc.
        
    Parámetros:
        codigo (int): Código único del sospechoso.
        nombre (str): Nombre del sospechoso.
        edad (int): Edad en años.
        altura (float): Altura en metros.
        pantalon (str): Descripción del pantalón, en el formato "Color; Tipo; Largo del Pantalón" (ejemplo: "Azul; Jeans; Largo").
        camisa (str): Descripción de la camisa, en el formato "Color; Tipo de Cuello; Estilo" (ejemplo: "Blanco; Cuello Tortuga; Regular Fit").
        usaba_gafas (bool): True si el sospechoso llevaba gafas, False en caso contrario.
        salon (str): Salón donde fue visto el sospechoso al momento del incidente (ejemplo: ML-515).
        coartada_confirmada (bool): True si el sospechoso tiene una coartada que fue confirmada por CupiDetectives, False en caso contrario.
        huellas_confirmadas (bool): True si las huellas digitales del sospechoso coinciden con las encontradas en el salón donde ocurrió el incidente, False en caso contrario.

    Retorna:
        dict: Diccionario con la información del sospechoso.
    """
    d={'codigo':codigo,'nombre':nombre,'edad':edad,'altura':altura,'pantalon':pantalon,'camisa':camisa,'usaba_gafas':usaba_gafas,'salon':salon,'coartada_confirmada':coartada_confirmada,'huellas_confirmadas':huellas_confirmadas}
   
    return d
def crear_perfil_culpable(edad_estimada: int, altura_estimada: float, color_pantalon: str, color_camisa: str, usaba_gafas: bool, salon_incidente: str) -> dict:
    """
    Crea un diccionario con el perfil del presunto culpable.
    Esta información fue recolectada en entrevista con Séneca, principal testigo del incidente.
    Para el pantalón y la camisa, únicamente se considera su color, porque este fue el único detalle que Séneca afirmó recordar con certeza.
    
    Las llaves del diccionario a crear deben llevar como nombre exactamente el mismo nombre de su parámetro respectivo.
    Por ejemplo: "edad_estimada": edad_estimada, "altura_estimada": altura_estimada, etc.

    Parámetros:
        edad_estimada (int): Edad máxima estimada del culpable.
        altura_estimada (float): Altura estimada en metros del culpable.
        color_pantalon (str): Color del pantalón del culpable. 
        color_camisa (str): Color de la camisa del culpable.
        usaba_gafas (bool): True si el culpable llevaba gafas, False en caso contrario.
        salon_incidente (str): Salón en donde Séneca vio al culpable y en donde desapareció Edouardinho (ejemplo: ML-610).

    Retorna:
        dict: Diccionario con el perfil del presunto culpable.
    """
    d2= {'edad_estimada':edad_estimada,'altura_estimada':altura_estimada,'color_pantalon':color_pantalon,'color_camisa':color_camisa,'usaba_gafas':usaba_gafas,'salon_incidente':salon_incidente}
    return d2


def buscar_por_codigo(codigo: int, s1: dict, s2: dict, s3: dict, s4: dict) -> dict:
    """
    Busca a un sospechoso por su código. El código de un sospechoso es único.

    Parámetros:
        codigo (int): Código del sospechoso a buscar.
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
        
    Retorno:            
        dict: Diccionario con la información del sospechoso cuyo código coincida con el código dado.
              Retorna un diccionario vacío si ningún sospechoso tiene el código dado. 
    """
    
    if s1 ['codigo'] == codigo :
        respuesta = s1
    elif s2 ['codigo'] == codigo :
        respuesta = s2
        
    elif s3 ['codigo'] == codigo :
        respuesta = s3
        
    elif s4 ['codigo'] == codigo :
        respuesta = s4
        
    else : 
       respuesta = {}
    return respuesta 
    
def filtrar_sospechosos_por_ubicacion(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> str:
    """
    Filtrar los códigos de los sospechosos que estaban en el salón donde fue visto el presunto culpable.
    
    Nota: Recuerde que un código es del tipo `int`. Para concatenarlo, debe convertirlo primero a string, usando la función de Python `str()`.

    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable. 
            De este diccionario se debe extraer el salón donde fue visto el presunto culpable al momento del incidente.
            
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
        
    Retorno:
        str: Códigos de los sospechosos que se encontraban en el salón donde fue visto el presunto culpable, separados por coma.   
               Por ejemplo, si únicamente el sospechoso con el código 1 estuvo en salón, se retornaría: "1"
                 Si los sospechosos idenficados con los códigos 1 y 2, estaban en el salón, se retornaría: "1, 2"
             Retorna "Ninguno" si ningún sospechoso estaba en ese salón.
    """
    respuesta = ""
    if s1 ['salon'] == perfil_culpable ['salon_incidente'] :
        respuesta= respuesta + str(s1 ['codigo']) + ", "
    if s2 ['salon'] == perfil_culpable ['salon_incidente'] :
        respuesta = respuesta + str(s2 ['codigo']) + ", "
    if s3 ['salon'] == perfil_culpable ['salon_incidente'] :
        respuesta = respuesta + str(s3 ['codigo']) + ", "
    if s4 ['salon'] == perfil_culpable ['salon_incidente'] :
        respuesta = respuesta + str(s4 ['codigo'])
    if respuesta == "":
        respuesta = "Ninguno"
    return respuesta
        

def filtrar_sospechosos_por_vestimenta(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> str:
    """
    Filtra los códigos de los sospechosos que coincidan con el perfil del presunto culpable, teniendo en cuenta el color de sus pantalones, el color de su camisa y el uso de gafas.
    
    Nota: Recuerde que un código es del tipo `int`. Para concatenarlo, debe convertirlo primero a string, usando la función de Python `str()`.

    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable. 
            De este diccionario se debe extraer el color de pantalón, color de camisa y si usaba gafas el presunto culpable.
            
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
        
    Retorno:
        str: Códigos de los sospechosos que cumplen con las tres condiciones de vestimenta, separados por coma, por ejemplo: "1, 3"
             Retorna "Ninguno" si ningún sospechoso cumple con las condiciones.
    """
    # TODO 5: Implemente la función tal y como se describe en la documentación.
    respuesta = ""
    
    if (perfil_culpable["color_pantalon"] in s1["pantalon"]) and (perfil_culpable["color_camisa"] in s1 ["camisa"]) and (perfil_culpable["usaba_gafas"] == s1["usaba_gafas"]):
        respuesta = respuesta + str(s1["codigo"]) + ", "
    if (perfil_culpable["color_pantalon"] in s2["pantalon"]) and (perfil_culpable["color_camisa"] in s2 ["camisa"]) and (perfil_culpable["usaba_gafas"] == s2["usaba_gafas"]):
        respuesta = respuesta + str(s2["codigo"]) + ", "
    if (perfil_culpable["color_pantalon"] in s3["pantalon"]) and (perfil_culpable["color_camisa"] in s3 ["camisa"]) and (perfil_culpable["usaba_gafas"] == s3["usaba_gafas"]):
        respuesta = respuesta + str(s3["codigo"]) + ", "
    if (perfil_culpable["color_pantalon"] in s4["pantalon"]) and (perfil_culpable["color_camisa"] in s4 ["camisa"]) and (perfil_culpable["usaba_gafas"] == s4["usaba_gafas"]):
        respuesta = respuesta + str(s4["codigo"]) 
    if respuesta =="":
        respuesta= "ninguno"
    return respuesta

def filtrar_sospechosos_por_edad_altura(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> str:
    """
    Filtra los códigos de los sospechosos cuya edad es menor o igual a la edad estimada del culpable y 
    cuya altura en metros está en el rango de la altura estimada ± 10cm. 
    
    Por ejemplo, si la altura estimada es 1.80m, se permite un margen de ±10 cm. 
    Esto significaría que el rango válido de altura es de 1.70m a 1.90m (incluyendo a 1.70 y a 1.90).
    
    Nota: Recuerde que un código es del tipo `int`. Para concatenarlo, debe convertirlo primero a string, usando la función de Python `str()`.

    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable.
            De este diccionario se debe extraer la edad y altura estimadas del presunto culpable.
            
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
    
    Retorno:
        str: Códigos de los sospechosos que cumplen con las dos condiciones sobre edad y altura, separados por coma, por ejemplo: "2, 4"
             Retorna "Ninguno" si ningún sospechoso cumple con ambas condiciones.
    """
    # TODO 6: Implemente la función tal y como se describe en la documentación.
    altura_minima = perfil_culpable["altura_estimada"] - 0.1
    altura_maxima = perfil_culpable["altura_estimada"] + 0.1
    respuesta=""
    if (s1["altura"] >= altura_minima) and (s1["altura"] <= altura_maxima) and (perfil_culpable["altura_estimada"] >= s1["altura"]):
        respuesta = respuesta + str(s1["codigo"]) + ", "
    if (s2["altura"] >= altura_minima) and (s2["altura"] <= altura_maxima) and (perfil_culpable["altura_estimada"] >= s2["altura"]):
        respuesta = respuesta + str(s2["codigo"]) + ", "
    if (s3["altura"] >= altura_minima) and (s3["altura"] <= altura_maxima) and (perfil_culpable["altura_estimada"] >= s3["altura"]):
        respuesta = respuesta + str(s3["codigo"]) + ", "
    if (s4["altura"] >= altura_minima) and (s4["altura"] <= altura_maxima) and (perfil_culpable["altura_estimada"] >= s4["altura"]):
        respuesta = respuesta + str(s4["codigo"]) 
    if respuesta =="":
        respuesta= "ninguno"
    return respuesta
        
def calcular_probabilidad_de_culpabilidad(codigo: int, perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> float:
    """
    Calcula la probabilidad de que el sospechoso cuyo código se pasa como primer parámetro sea el culpable según su ubicación, vestimenta y características físicas.

    Se usa la fórmula F1:
    
    probabilidad = (a * 0.45) + (b * 0.35) + (c * 0.20)
    
        Donde:
            a = 1 si el sospechoso estuvo en el salón reportado por Séneca, 0 en caso contrario.
            b = 1 si el sospechoso llevaba la vestimenta descrita por Séneca, 0 en caso contrario.
            c = 1 si la edad y altura del sospechoso son similares a las estimadas por Séneca, 0 en caso contrario.
            Los valores 0.45, 0.35 y 0.20 representan pesos fijos que reflejan la importancia relativa de cada factor para determinar
            la probabilidad de culpabilidad.
            
    MUY IMPORTANTE:
        Es obligatorio usar las funciones de filtro al calcular la probabilidad de culpabilidad del sospechoso cuyo código se pasa como primer parámetro.
            - filtrar_sospechosos_por_ubicacion()
            - filtrar_sospechosos_por_vestimenta()
            - filtrar_sospechosos_por_edad_altura()
        
        Cada una de estas funciones retorna un conjunto de códigos de sospechosos que cumplen con el criterio correspondiente (Ej.: "2, 4"). 
        Se debe verificar la presencia del código del sospechoso a evaluar en los strings retornados por estas funciones, para asignar los valores de a, b y c en la fórmula.

    Nota: Recuerde que un código es del tipo `int`. Si desea convertirlo a string, debe usar la función de Python `str()`.

    Parámetros:
        codigo (int): Código del sospechoso.
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable.
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.

    Retorna:
        float: Probabilidad de que el sospechoso sea el culpable, redondeada a 2 decimales.
               Retorna 0.0 si el código no le pertenece a ningún sospechoso o si el sospechoso no cumple con ningún criterio considerado en la fórmula.
    """
    # TODO 7: Implemente la función tal y como se describe en la documentación.
    codigos_ubicacion = filtrar_sospechosos_por_ubicacion(perfil_culpable, s1, s2, s3, s4)
    codigo_vestimenta = filtrar_sospechosos_por_vestimenta(perfil_culpable, s1, s2, s3, s4)
    codigo_edad = filtrar_sospechosos_por_edad_altura(perfil_culpable, s1, s2, s3, s4)
    a=0
    b=0
    c=0
    if codigo in codigos_ubicacion :
        a = 1 
    if codigo in codigo_vestimenta :
        b=1
    if codigo in codigo_edad :
        c=1
    probabilidad = ( a * 0.45) + (b * 0.35) + (c * 0.20)
    return  float (probabilidad,2)
def encontrar_sospechoso_con_mayor_probabilidad(perfil_culpable: dict, s1: dict, s2: dict, s3: dict, s4: dict) -> dict:
    """
    Busca al sospechoso con la mayor probabilidad de ser culpable.
    
    Finalmente, la brigada CupiDetectives ha terminado el proceso de revisión de coartadas de los sospechosos.
    Más importante aún, se ha terminado el proceso de confirmación de huellas dactilares. 
    Dada esta nueva información:

    - Si hay empate en la probabilidad, se elige al sospechoso sin coartada confirmada.
      - Si aún hay empate, se elige al sospechoso cuyas huellas digitales hayan sido confirmadas.
        - Si el empate persiste, por simplicidad se elige al primer sospechoso evaluado en orden de ingreso a la función (s1 a s4).

    Parámetros:
        perfil_culpable (dict): Diccionario con el perfil del presunto culpable. 
        s1 (dict): Diccionario que contiene la información del primer sospechoso.
        s2 (dict): Diccionario que contiene la información del segundo sospechoso.
        s3 (dict): Diccionario que contiene la información del tercer sospechoso.
        s4 (dict): Diccionario que contiene la información del cuarto sospechoso.
            De cada diccionario se debe extraer si el sospechoso tiene su coartada y huellas confirmadas.

    Retorna:
        dict: Diccionario del sospechoso con la mayor probabilidad de culpabilidad, según todo lo anteriormente descrito.
    """
    # TODO 8: Implemente la función tal y como se describe en la documentación.
    pmaxima=0
    p1= calcular_probabilidad_de_culpabilidad(s1 ['codigo'], perfil_culpable, s1, s2, s3, s4)
    p2= calcular_probabilidad_de_culpabilidad(s2 ['codigo'], perfil_culpable, s1, s2, s3, s4)
    p3= calcular_probabilidad_de_culpabilidad(s3 ['codigo'], perfil_culpable, s1, s2, s3, s4)
    p4= calcular_probabilidad_de_culpabilidad(s4 ['codigo'], perfil_culpable, s1, s2, s3, s4)
    if p1 >= pmaxima :
        pmaxima= p1
    if p2 >= pmaxima :
        pmaxima= p2
    if p3 >= pmaxima :
        pmaxima=p3
    if p4 >= pmaxima :
        pmaxima=p4
    respuesta= pmaxima
    if pmaxima == p1 and pmaxima == (p2 or p3 or p4 ):
        if p2 == pmaxima :
            if s2 ['coartada_confirmada'] == False and s1 ['coartada_confirmada'] == True :
                respuesta = s2 
            if s2 ['coartada_confirmada'] == True and s1 ['coartada_confirmada'] == False :
                respuesta = s1 
            if s1 ['coartada_confirmada'] == s2 ['coartada_confirmada']:
                if s1 ['huellas_confirmadas']== False and s2 ['huellas_confirmadas'] == True :
                    respuesta = s2 
                if s1 ['huellas_confirmadas'] == True and s2 ['huellas_confirmadas'] == False :
                    respuesta = s1 
                if s1 ['huellas_confirmadas'] == s2 ['huellas_confirmadas'] :
                    respuesta = s1 
        if p3 == pmaxima :
            if s3 ['coartada_confirmada'] == False and s1['coartada_confirmada'] == True :
                respuesta = s3 
            if s3 ['coartada_confirmada'] == True and s1 ['coartada_confirmada'] == False :
                respuesta = s1 
            if s1 ['coartada_confirmada'] == s3 ['coartada_confirmada']:
                if s1 ['huellas_confirmadas']== False and s3 ['huellas_confirmadas'] == True :
                    respuesta = s3 
                if s1 ['huellas_confirmadas'] == True and s3 ['huellas_confirmadas'] == False :
                    respuesta = s1 
                if s1 ['huellas_confirmadas'] == s3 ['huellas_confirmadas'] :
                    respuesta = s1 
        if p4 == pmaxima :
            if s4 ['coartada_confirmada'] == False and s1 ['coartada_confirmada'] == True :
                 respuesta = s4 
            if s4 ['coartada_confirmada'] == True and s1 ['coartada_confirmada'] == False :
                 respuesta = s1 
            if s1 ['coartada_confirmada'] == s4 ['coartada_confirmada']:
                 if s1 ['huellas_confirmadas']== False and s4 ['huellas_confirmadas'] == True :
                     respuesta = s4 
                 if s1 ['huellas_confirmadas'] == True and s4 ['huellas_confirmadas'] == False :
                     respuesta = s1 
                 if s1 ['huellas_confirmadas'] == s4 ['huellas_confirmadas'] :
                     respuesta = s1     
        return respuesta
                
                

    
    
    
    
    
    
    
    
    
    
    