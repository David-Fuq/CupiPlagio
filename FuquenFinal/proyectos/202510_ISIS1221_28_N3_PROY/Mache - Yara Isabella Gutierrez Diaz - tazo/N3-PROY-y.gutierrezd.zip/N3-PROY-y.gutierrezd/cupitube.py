#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
              - El país de origen de un CupiTuber se encuentra en la columna "country" del archivo CSV.
              - El país es un string no vacío, sin espacios al inicio o al final.
                Ejemplo: "India"
            
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber. 
              - Cada diccionario contiene los siguientes campos basados en las columnas del archivo CSV:
    
                "rank" (int): Ranking del CupiTuber en el mundo. Es un valor entero mayor a cero.
                              Ejemplo: 1
    
                "cupituber" (str): Nombre del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                   Ejemplo: "T-Series"
    
                "subscribers" (int): Cantidad de suscriptores del CupiTuber. Es un valor entero mayor a cero.
                                     Ejemplo: 222000000
    
                "video_views" (int): Cantidad de visitas de todos los videos del CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 198459090822
    
                "video_count" (int): Cantidad de videos publicados por el CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 17317
    
                "category" (str): Categoría principal de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                  Ejemplo: "Music"
    
                "started" (str): Fecha en la que el CupiTuber empezó a publicar videos en formato YYYY-MM-DD.
                                Es un string no vacío, sin espacios al inicio o al final.
                                Ejemplo: "2006-11-15"
    
                "monetization_type" (str): Tipo de monetización de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                           Ejemplo: "AdSense"
    
                "description" (str): Descripción del tipo de videos que publica el CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                     Ejemplo: "Amazing travel vlogs worldwide!"
    
    Notas importantes:
        1. Al usar readline(), agregue strip() de esta forma: readline().strip() para garantizar que se eliminen los saltos de línea.
            Documentación de str.strip(): https://docs.python.org/es/3/library/stdtypes.html#str.strip
            Documentación de readline(): https://docs.python.org/es/3/tutorial/inputoutput.html#methods-of-file-objects
            
        2. Al usar open(), agregue la codificación "utf-8" de esta forma: open(archivo, "r", encoding="utf-8") para garantizar la lectura de caracteres especiales del archivo CSV.
    """
    #Se realiza la función que carga la información del archivo Cupitube
    #Se inicializa el diccionario principal  en la variable cupitube
    cupitube={}
    #Se abre el archivo en modo lectura tambien aceptando caracteres especiales
    archivo = open(archivo, "r", encoding="utf-8")
    #Con la instruccion readline se lee la informacion de la primera linea que solo contiene los nombres de cada columna
    titulos = archivo.readline().strip().split(",")
    #Se lee linea por linea aignandolo a una variable
    linea = archivo.readline().strip()
    #Mientras que la linea no este vacia, es decir que todavia se encuentre información en el archivo va a continuar ejecutando las instrucciones que se le indiquen
    while len(linea) > 0:
        #Cada lina se divide en teniendo como separador la coma y dejandolo en una lista con nombre "datos".
        datos =linea.split(",")
        #Se extrae el nombre del pais dado en la posición 7 que va a ser la llave principal del diccionario
        pais = datos[7].strip()
        #Se crea el diccionario que almacenara la informacion de cada cupituber. Y se llena con toda la informacion del archivo relacionando cada llave con el valor que le corresponde a su posicion
        info_cupituber = {"rank": int(datos[0]),
                          "cupituber": datos[1].strip(),
                          "subscribers": int(datos[2]),
                          "video_views": int(datos[3]),
                          "video_count": int(datos[4]),
                          "category": datos[5].strip(),
                          "started": datos[6].strip(),
                          "monetization_type": datos[8].strip(),
                          "description": datos[9].strip()
                          }
        #Si el pais no se encuentra todavia en el diccionario, se crea le asoscia una lista que almacenara a los cupitubers pertenecientes a este pais y esta lista va a corresponder al valor de la llave. 
        if pais not in cupitube:
            cupitube[pais] = []
        cupitube[pais].append(info_cupituber)
        #Se lee la siguiente linea del archivo 
        linea = archivo.readline()
    #Se cierra el archivo
    archivo.close()
    return cupitube
    


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    #Se incializa la lista de que se retorna en esta función
    lista_f2=[]
    
    #Para la lista de cada pais en el diccionario
    for cada_pais in cupitube.values():
        #Para cada cupituber en la lista del pais 
        for cada_cupituber in cada_pais:
            # Si la categoria y los suscriptores coinciden con lo que el usuario solicita, se agrega el diccionario del cupituber a la lista
            if (cada_cupituber["category"].lower() == categoria_buscada.lower()) and (suscriptores_min <= cada_cupituber["subscribers"] <= suscriptores_max):
                lista_f2.append(cada_cupituber)
    return lista_f2


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    #Se incializa la lista de que se retorna en esta función
    lista_f3 = []
    # Si el pais que busca el usuario se encuentra en el diccionario de cupitube
    if pais_buscado in cupitube:
        #Para cada cupituber en la lista del pais que se busca
        for cada_cupituber in cupitube[pais_buscado]:
            #Si la categoria y la monetización coinciden con las que el usuario busca se agrega la información del cupituber en la lista que se retorna
            if (cada_cupituber["category"].lower() == categoria_buscada.lower()) and (cada_cupituber["monetization_type"].lower() == monetizacion_buscada.lower()):
                lista_f3.append(cada_cupituber)
    return lista_f3


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    #Se convierte el diccionario decupitube en una lista para facilitar la busqueda con indexacion
    en_lista = list(cupitube)
    #Se toma el pais de la posicion 0 como primer pais
    pais_inicial = en_lista[0]
    #Se incializa que el cupituber mas antiguo es el primero dentro de la lista del primer pais para empezar a comparar
    antiguo = cupitube[pais_inicial][0]
    #Para la lista de cada pais en el diccionario
    for cada_pais in cupitube.values():
        #Para cada cupituber en la lista del pais 
        for cada_cupituber in cada_pais:
            # Se empieza a comparar cada cupituber con el mas antiguo hasta el momento y si la fecha en la que empezo es menor la asignacion de la variable "antiguo" va cambiando.
            if cada_cupituber["started"] < antiguo["started"]:
                antiguo = cada_cupituber
    return antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    #Se inciaiza una suma total en 0
    suma = 0
    #Para la lista de cada pais en el diccionario
    for cada_pais in cupitube.values():
        #Para cada cupituber en la lista del pais que se busca
        for cada_cupituber in cada_pais:
            #Si la categoria del cupituber coincide con la categoria buscada por el usuario, se suman todas las vistas de los videos que tengan los cupitubers que cumplen la condición 
            if cada_cupituber["category"].lower() == categoria_buscada.lower():
                suma += cada_cupituber["video_views"]
    return suma


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    #Se convierte el diccionario decupitube en una lista para facilitar la busqueda con indexacion
    en_lista= list(cupitube)
    #Se toma el pais de la posicion 0 como primer pais
    pais_inicial= en_lista[0]
    #Se toma el cupituber que este en la posicion 0 como primer cupituber
    cupituber_inicial= cupitube[pais_inicial][0]
    #Se inicializa que la categoria con mas vistas es la del primer cupituber para empezar a comparar
    cat_max= cupituber_inicial["category"]
    #Se llama a la funcion que obtiene las vistas de la categoria para no repetir codigo y se incializa en que corresponde a la categoria maxima incial para hacer la comparación
    visitas_max = obtener_visitas_por_categoria(cupitube, cat_max)
    
    # Se inicializa una lista de categorias para evitar calcular las vistas de una categoria que ya se halla analizado 
    categorias = []
    #Para la lista de cada pais en el diccionario
    for cada_pais in cupitube.values():
        #Para cada cupituber en la lista del pais que se busca
        for cada_cupituber in cada_pais:
            #Se asigna una variable a la categoria de cada cupituber para facilitar la escritura
            categoria= cada_cupituber["category"]
            # Si la categoria no se encuentra en la lista de categorias, se agrega y se asigna a la variable "visitas" la suma correspondiente
            if categoria not in categorias:
                categorias.append(categoria)
                visitas= obtener_visitas_por_categoria(cupitube, categoria)
                
                #Si las visitas de la categoria es mayor a las de la cateogria mayor actual se actualizan las variables
                if visitas > visitas_max:
                    visitas_max = visitas
                    cat_max = categoria
    #Se retorna un diccionario con las llaves "categoria" y "visitas" cuyos valores corresponde a la categoria con mas visitas y la suma correspondiente
    return {"categoria": cat_max, "visitas": visitas_max}
                    
    
    

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    ##Para la lista de cada pais en el diccionario
    for cada_pais in cupitube.values():
        #Para cada cupituber en la lista del pais que se busca
        for cada_cupituber in cada_pais:
            #Se asignan las variables "nombre" y "fecha" que extrae la informacion correspondiente dle cupituber para facilirar la escritura del codigo
            nombre= cada_cupituber["cupituber"]
            fecha= cada_cupituber["started"]
            #Se asigna una variable vacia para el nombre que va a ir en el correo
            nom = ""
            #Para cada caracter en el nombre del cupituber, se agrega a "nom" si es un caracter alfanumerico
            for cada_caracter in nombre:
                if cada_caracter.isalnum():
                    nom += cada_caracter
            #Con la subcadena permite tomar solo los primeros 15 caracteres del nombre
            nom= nom[:15]
            #Se convierte la fecha en una lista para poder acceder mejor a sus informacion mediante indexacion
            fech= fecha.split("-")
            #Se toman los dos ultimos caracteres de la fecha ubicada en la posicion 0
            anio= fech[0][-2:]
            #Se toman los digitos del mes ubicado en la posicion 1
            mes= fech[1]    
            
            #Se escribe el formato del correo
            correo= "{}.{}{}@cupitube.com".format(nom.lower(), anio, mes)
            #Se modifica el diccionario del cupituber de manera permanente adicionando una llave denominada "correo" cuyo valor es el correo que se realizo segun las indicaciones.
            cada_cupituber["correo"]= correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #Se llama a la funcion de la categoria con mas visitas
    categoria = obtener_categoria_con_mas_visitas(cupitube)
    #Se extrae el nombre de la categoria
    nombre_categoria = categoria["categoria"]
    
    #Se asigna el diccionario que va a retornar esta función
    dicc_f8 ={}
    #Se inicializa un centinela en False
    encontro= False
    #Se convierte el diccionario decupitube en una lista para facilitar la busqueda con indexacion
    en_lista= list(cupitube)
    #Se inicializa la variable de cada pais
    pais =0
    
    #Mientras cada pais sea menor a la longitud de toda la lista y encontro siga siendo false se van a seguir ejecuntando las instrucciones.
    while pais < len(en_lista) and not encontro:
        #
        cada_pais = cupitube[en_lista[pais]]
        cada_cupituber= 0
        
        #Mientras cada cupituber sea menor a la longitud de la lista de cada pais y encontro siga siendo false se va a seguir ejecutando las instrucciones.
        while cada_cupituber < len(cada_pais) and not encontro:
            #Se asigna una variable para facilitar la escritura del codigo
            cupituber= cada_pais[cada_cupituber]
            
            #Se asignan variables que guardan los filtros por los cuales se va a recomendar el cupituber
            si_cat = cupituber["category"] == nombre_categoria
            si_sus = suscriptores_min <= cupituber["subscribers"] <= suscriptores_max
            si_fech = fecha_minima <= cupituber["started"] <= fecha_maxima
            si_vid = cupituber["video_count"] >= videos_minimos
            si_pal = palabra_clave.lower() in cupituber["description"].lower()
            
            #Si todo se cumple se retorna la informacion del cupituber en el diccionario de la funcion y el valor de encontro cambia a True para que pare la ejecucion
            if si_cat and si_sus and si_fech and si_vid and si_pal:
                dicc_f8 = cupituber
                encontro = True
            #Si no la variable de cada_cupituber va cambiando para evitar un loop
            cada_cupituber += 1
        #Si no la variable de pais va cambiando para evitar un loop
        pais+= 1
        
    return dicc_f8
    

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    #Se crea el diccionario que va retornar la funcion
    paises = {}
    #Para cada pais en cupitube
    for cada_pais in cupitube:
        #Para cada cupituber de la lista de cada pais
        for cada_cupituber in cupitube[cada_pais]:
            #Se asigna la variable categoria para facilitar la escritura del codigo
            categoria= cada_cupituber["category"]
            #Si la categoria no esta en el diccionario se crea la llave cuyo valor va a ser una lista
            if categoria not in paises:
                paises[categoria] = []
            #Si cada pais no se encuentra en la lista de la categoria se agrega
            if cada_pais not in paises[categoria]:
                paises[categoria].append(cada_pais)
    return paises
