# -*- coding: utf-8 -*-


import libreria as lib

def ejecutar_frecuente_doble()->None:
    print("Buscando el dígito más frecuente de un número, haciendo un doble recorrido sobre el número y construyendo un histograma de frecuencias (diccionario) con los dígitos que aparecen en el número")
    numero = int(input("Por favor digite el número: "))
    digito = lib.digito_mas_frecuente_doble(numero)
    print("El dígito más frecuente en el número", numero, "es el", digito)


def ejecutar_frecuente_histograma()->None:
    print("Buscando el dígito más frecuente de un número, calculando un histograma de frecuencias (diccionario) de los dígitos entre 0 y 9")
    numero = int(input("Por favor digite el número: "))
    digito = lib.digito_mas_frecuente_diccionario(numero)
    print("El dígito más frecuente en el número", numero, "es el", digito)


def ejecutar_frecuente_digitos()->None:
    print("Buscando el dígito más frecuente de un número, haciendo un recorrido sobre los dígitos del 0 al 9")
    numero = int(input("Por favor digite el número: "))
    digito = lib.digito_mas_frecuente_digitos(numero)
    print("El dígito más frecuente en el número", numero, "es el", digito)


def mostrar_menu()->None:
    print("\n\nOPCIONES")
    print("1. Dígito más frecuente - Doble recorrido sobre el número")
    print("2. Dígito más frecuente - Histograma de frecuencias completo")
    print("3. Dígito más frecuente - Recorrido sobre los dígitos")
    print("4. Salir")


def iniciar_aplicacion()->None:
    """
    Esta función mantiene el programa funcionando hasta que el usuario seleccione la opción para salir.
    La función primero debe mostrar el menú de opciones usando la función mostrar_menu().
    A continuación, debe solicitarle al usuario una opción.
    Según lo que haya seleccionado el usuario, debe llamar a una de las funciones cuyo nombre inicia con ejecutar_
    Si el usuario seleccionó la opción de Salir, la función debe terminar su ejecución para que el programa pueda terminar.
    Si el usuario seleccionó cualquier otra opción, después de ejecutar la opción seleccionada se debe volver
    a mostrar el menú de opciones y se debe repetir el proceso.
    """

    #TODO: implementar la función

def iniciar_aplicacion ()->None:

    seguir = True

    while seguir:

        mostrar_menu()

        option = input("Seleccióne una de las siguiente opciones \n1): frecuente doble\n2) frecuente histograma\n3) frecuentedigitos\n4)Salir de la aplicación ")
        
        if option == '1':
           
            ejecutar_frecuente_doble()
        
        elif option == '2':
        
            ejecutar_frecuente_histograma()
        
        elif option == '3':
        
        
            ejecutar_frecuente_digitos()
        
        elif option == '4':
        
            print("Saliendo de la aplicación. ¡Hasta luego!")
        
            seguir = False  
        
        else:
            print("Opción no es valida. Por favor, seleccione una opción entre las opciones dadas 1, 2, 3 o 4")



iniciar_aplicacion()
