#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
 
def cargar_cupitube(archivo: str) -> dict:
    cupitube = {}
    archivo = open("cupitube.csv", "r", encoding="utf-8")
    linea = archivo.readline().strip()  

    linea = archivo.readline().strip()
    while linea != "":
        datos = linea.split(",")
        cupituber = {
            "rank": datos[0],
            "cupituber": datos[1],
            "suscribers": int(datos[2]),
            "video_views": int(datos[3]),
            "video_count": int(datos[4]),
            "category": datos[5],
            "started": datos[6],
            "pais": datos[7],
            "monetization_type": datos[8],
            "description" : str(datos[9]),
        }

        pais = cupituber["pais"]
        if pais not in cupitube:
            cupitube[pais] = []
        cupitube[pais].append(cupituber)

        linea = archivo.readline().strip()

    archivo.close()
    return cupitube

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resultado = []
    for cupitubers_por_pais in cupitube.values():
        for cupituber in cupitubers_por_pais:
            if (cupituber["category"].lower() == categoria_buscada.lower() and
                suscriptores_min <= cupituber["suscribers"] <= suscriptores_max):
                resultado.append(cupituber)
    return resultado


def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    pais = pais_buscado
    if pais in cupitube:
        for cupi in cupitube[pais]:
            if (cupi["category"].lower() == categoria_buscada.lower() and
                cupi["monetization_type"].lower() == monetizacion_buscada.lower()):
                resultado.append(cupi)
    return resultado

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None
    for lista in cupitube.values():
        for cupi in lista:
            if mas_antiguo is None or cupi["started"] < mas_antiguo["started"]:
                mas_antiguo = cupi
    return mas_antiguo
            

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0
    for lista in cupitube.values():
        for cupi in lista:
            if cupi["category"].lower() == categoria_buscada.lower():
                total += cupi["video_views"]
    return total



def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {}
    for lista in cupitube.values():
        for cupi in lista:
            cat = cupi["category"]
            visitas_por_categoria[cat] = visitas_por_categoria.get(cat, 0) + cupi["video_views"]
    categoria_mas_visitada = max(visitas_por_categoria, key=visitas_por_categoria.get)
    return {"category": categoria_mas_visitada, "video_views": visitas_por_categoria[categoria_mas_visitada]}


def crear_correo_para_cupitubers(cupitube: dict) -> list:
    correos = {}
    for pais, lista in cupitube.items():
        correos[pais] = []
        for cupi in lista:
            nombre = cupi["cupituber"].replace(" ", "").lower()
            fecha = cupi["started"].replace("-", "")
            correo = f"{nombre}.{fecha[:4]}{fecha[4:6]}@cupitube.com"
            correos[pais].append(correo)
    return correos

def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    mejor = None
    for lista in cupitube.values():
        for cupi in lista:
            descripcion = cupi.get("description", "")
            if palabra_clave.lower() in descripcion.lower():
                if (suscriptores_min <= cupi["suscribers"] <= suscriptores_max and
                    fecha_minima <= cupi["started"] <= fecha_maxima and
                    cupi["video_count"] >= videos_minimos):
                    
                    if mejor is None or cupi["suscribers"] > mejor["suscribers"]:
                        mejor = cupi
    
    return mejor


def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}
    for pais, lista in cupitube.items():
        for cupi in lista:
            cat = cupi["category"]
            if cat not in resultado:
                resultado[cat] = []
            if pais not in resultado[cat]:
                resultado[cat].append(pais)
    return resultado
