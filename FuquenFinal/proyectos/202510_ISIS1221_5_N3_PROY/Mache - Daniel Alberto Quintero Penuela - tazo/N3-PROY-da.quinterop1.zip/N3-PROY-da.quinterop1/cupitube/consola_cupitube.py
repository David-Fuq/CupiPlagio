import cupitube as ct

def mostrar_cupituber(cupituber: dict) -> None:
    print(f"Rank: {cupituber['rank']}")
    print(f"Nombre: {cupituber['cupituber']}")
    print(f"Suscriptores: {cupituber['subscribers']:,}")
    print(f"Vistas totales: {cupituber['video_views']:,}")
    print(f"Videos publicados: {cupituber['video_count']:,}")
    print(f"Categoría: {cupituber['category']}")
    print(f"Inicio: {cupituber['started']}")
    print(f"País: {cupituber['country']}")
    print(f"Monetización: {cupituber['monetization_type']}")
    print(f"Descripción: {cupituber['description']}")
    if "email" in cupituber:
        print(f"Email: {cupituber['email']}")
    print("-" * 40)

def mostrar_cupitubers(cupitubers: list) -> None:
    for cupituber in cupitubers:
        mostrar_cupituber(cupituber)

def mostrar_paises(datos_cupitube: dict) -> None:
    print("Países disponibles:")
    for i, pais in enumerate(sorted(datos_cupitube.keys()), 1):
        print(f"{i}. {pais} ({len(datos_cupitube[pais])} CupiTubers)")

def ejecutar_cargar_datos() -> dict:
    ruta_archivo = input("Ingrese la ruta del archivo CSV de CupiTubers: ")
    datos = ct.cargar_datos_cupitube(ruta_archivo)
    print(f"Se cargaron datos de {sum(len(cupitubers) for cupitubers in datos.values())} CupiTubers de {len(datos)} países.")
    return datos

def ejecutar_buscar_cupituber(datos_cupitube: dict) -> None:
    nombre = input("Ingrese el nombre del CupiTuber a buscar: ")
    cupituber = ct.buscar_cupituber_por_nombre(datos_cupitube, nombre)
    
    if cupituber:
        print(f"CupiTuber encontrado!")
        mostrar_cupituber(cupituber)
    else:
        print(f"No se encontró ningún CupiTuber con el nombre '{nombre}'.")

def ejecutar_cupitubers_por_categoria(datos_cupitube: dict) -> None:
    categoria = input("Ingrese la categoría de interés: ")
    cupitubers = ct.cupitubers_por_categoria(datos_cupitube, categoria)
    
    if cupitubers:
        print(f"Se encontraron {len(cupitubers)} CupiTubers en la categoría '{categoria}':")
        mostrar_cupitubers(cupitubers)
    else:
        print(f"No se encontraron CupiTubers en la categoría '{categoria}'.")

def ejecutar_pais_con_mas_monetizacion(datos_cupitube: dict) -> None:
    tipo_monetizacion = input("Ingrese el tipo de monetización de interés: ")
    pais = ct.pais_con_mas_monetizacion(datos_cupitube, tipo_monetizacion)
    
    if pais:
        monetizaciones = ct.contar_monetizaciones_por_pais(datos_cupitube)
        cantidad = monetizaciones[pais].get(tipo_monetizacion, 0)
        print(f"El país con más CupiTubers usando monetización '{tipo_monetizacion}' es {pais} con {cantidad} CupiTubers.")
    else:
        print(f"No se encontraron países con CupiTubers usando monetización '{tipo_monetizacion}'.")

def ejecutar_crear_correo_para_cupitubers(datos_cupitube: dict) -> None:
    ct.crear_correo_para_cupitubers(datos_cupitube)
    print("Se han creado correos electrónicos para todos los CupiTubers.")
    
    print("Ejemplos de correos creados:")
    contador = 0
    for pais, cupitubers in datos_cupitube.items():
        for cupituber in cupitubers:
            print(f"{cupituber['cupituber']}: {cupituber['email']}")
            contador += 1
            if contador >= 5:
                break
        if contador >= 5:
            break

def ejecutar_cupitubers_suscritos_entre(datos_cupitube: dict) -> None:
    try:
        min_suscriptores = int(input("Ingrese el mínimo de suscriptores: "))
        max_suscriptores = int(input("Ingrese el máximo de suscriptores: "))
        
        if min_suscriptores > max_suscriptores:
            print("El mínimo no puede ser mayor que el máximo.")
            return
        
        cupitubers = ct.cupitubers_suscritos_entre(datos_cupitube, min_suscriptores, max_suscriptores)
        
        if cupitubers:
            print(f"Se encontraron {len(cupitubers)} CupiTubers con entre {min_suscriptores:,} y {max_suscriptores:,} suscriptores:")
            mostrar_cupitubers(cupitubers)
        else:
            print(f"No se encontraron CupiTubers con entre {min_suscriptores:,} y {max_suscriptores:,} suscriptores.")
    except ValueError:
        print("Por favor, ingrese valores numéricos válidos para los suscriptores.")

def ejecutar_promedio_suscriptores_por_categoria(datos_cupitube: dict) -> None:
    promedios = ct.promedio_suscriptores_por_categoria(datos_cupitube)
    
    print("Promedio de suscriptores por categoría:")
    for categoria, promedio in sorted(promedios.items()):
        print(f"{categoria}: {promedio:,.2f} suscriptores")

def ejecutar_cupitubers_por_pais(datos_cupitube: dict) -> None:
    mostrar_paises(datos_cupitube)
    pais = input("Ingrese el nombre del país de interés: ")
    
    cupitubers = ct.cupitubers_por_pais(datos_cupitube, pais)
    
    if cupitubers:
        print(f"CupiTubers de {pais} ({len(cupitubers)}):")
        mostrar_cupitubers(cupitubers)
    else:
        print(f"No se encontraron CupiTubers del país '{pais}' o el país no existe en los datos.")

def mostrar_menu() -> None:
    print("\n=== MENU CUPITUBE ===")
    print("1. Cargar datos de CupiTubers")
    print("2. Buscar CupiTuber por nombre")
    print("3. Mostrar CupiTubers por categoría")
    print("4. Encontrar país con más CupiTubers usando un tipo de monetización")
    print("5. Mostrar CupiTubers de un país")
    print("6. Crear correos electrónicos para CupiTubers")
    print("7. Mostrar CupiTubers con suscriptores en un rango")
    print("8. Ver promedio de suscriptores por categoría")
    print("0. Salir")

def iniciar_aplicacion() -> None:
    datos_cupitube = {}
    
    while True:
        mostrar_menu()
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            datos_cupitube = ejecutar_cargar_datos()
        elif opcion == "2":
            if not datos_cupitube:
                print("Primero debe cargar los datos (opción 1).")
                continue
            ejecutar_buscar_cupituber(datos_cupitube)
        elif opcion == "3":
            if not datos_cupitube:
                print("Primero debe cargar los datos (opción 1).")
                continue
            ejecutar_cupitubers_por_categoria(datos_cupitube)
        elif opcion == "4":
            if not datos_cupitube:
                print("Primero debe cargar los datos (opción 1).")
                continue
            ejecutar_pais_con_mas_monetizacion(datos_cupitube)
        elif opcion == "5":
            if not datos_cupitube:
                print("Primero debe cargar los datos (opción 1).")
                continue
            ejecutar_cupitubers_por_pais(datos_cupitube)
        elif opcion == "6":
            if not datos_cupitube:
                print("Primero debe cargar los datos (opción 1).")
                continue
            ejecutar_crear_correo_para_cupitubers(datos_cupitube)
        elif opcion == "7":
            if not datos_cupitube:
                print("Primero debe cargar los datos (opción 1).")
                continue
            ejecutar_cupitubers_suscritos_entre(datos_cupitube)
        elif opcion == "8":
            if not datos_cupitube:
                print("Primero debe cargar los datos (opción 1).")
                continue
            ejecutar_promedio_suscriptores_por_categoria(datos_cupitube)
        elif opcion == "0":
            print("¡Gracias por usar CupiTube!")
            break
        else:
            print("Opción no válida. Por favor, intente de nuevo.")

if __name__ == "__main__":
    iniciar_aplicacion()