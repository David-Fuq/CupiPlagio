def cargar_datos_cupitube(ruta_archivo: str) -> dict:
    datos = {}
    with open(ruta_archivo, "r", encoding="utf-8") as archivo:
        archivo.readline().strip()
        
        for linea in archivo:
            linea = linea.strip()
            if linea:
                campos = linea.split(",")
                
                rank = int(campos[0])
                cupituber = campos[1]
                subscribers = int(campos[2])
                video_views = int(campos[3])
                video_count = int(campos[4])
                category = campos[5]
                started = campos[6]
                country = campos[7]
                monetization_type = campos[8]
                description = campos[9] if len(campos) > 9 else ""
                
                info_cupituber = {
                    "rank": rank,
                    "cupituber": cupituber,
                    "subscribers": subscribers,
                    "video_views": video_views,
                    "video_count": video_count,
                    "category": category,
                    "started": started,
                    "country": country,
                    "monetization_type": monetization_type,
                    "description": description
                }
                
                if country in datos:
                    datos[country].append(info_cupituber)
                else:
                    datos[country] = [info_cupituber]
    
    return datos

def contar_monetizaciones_por_pais(datos_cupitube: dict) -> dict:
    monetizaciones_por_pais = {}
    
    for pais, cupitubers in datos_cupitube.items():
        monetizaciones = {}
        
        for cupituber in cupitubers:
            tipo_monetizacion = cupituber["monetization_type"]
            
            if tipo_monetizacion in monetizaciones:
                monetizaciones[tipo_monetizacion] += 1
            else:
                monetizaciones[tipo_monetizacion] = 1
        
        monetizaciones_por_pais[pais] = monetizaciones
    
    return monetizaciones_por_pais

def buscar_cupituber_por_nombre(datos_cupitube: dict, nombre: str) -> dict:
    for pais, cupitubers in datos_cupitube.items():
        for cupituber in cupitubers:
            if cupituber["cupituber"].lower() == nombre.lower():
                return cupituber
    
    return None

def cupitubers_por_categoria(datos_cupitube: dict, categoria: str) -> list:
    cupitubers_categoria = []
    
    for pais, cupitubers in datos_cupitube.items():
        for cupituber in cupitubers:
            if cupituber["category"].lower() == categoria.lower():
                cupitubers_categoria.append(cupituber)
    
    return cupitubers_categoria

def pais_con_mas_monetizacion(datos_cupitube: dict, tipo_monetizacion: str) -> str:
    monetizaciones_por_pais = contar_monetizaciones_por_pais(datos_cupitube)
    
    pais_maximo = ""
    cantidad_maxima = 0
    
    for pais, monetizaciones in monetizaciones_por_pais.items():
        if tipo_monetizacion in monetizaciones and monetizaciones[tipo_monetizacion] > cantidad_maxima:
            cantidad_maxima = monetizaciones[tipo_monetizacion]
            pais_maximo = pais
    
    return pais_maximo

def cupitubers_por_pais(datos_cupitube: dict, pais: str) -> list:
    if pais in datos_cupitube:
        return datos_cupitube[pais]
    else:
        return []

def crear_correo_para_cupitubers(datos_cupitube: dict) -> None:
    for pais, cupitubers in datos_cupitube.items():
        for cupituber in cupitubers:
            nombre = cupituber["cupituber"]
            nombre_simplificado = nombre.lower().replace(" ", "")
            
            pais_simplificado = pais.lower().replace(" ", "")
            correo = f"{nombre_simplificado}@{pais_simplificado}.cupitube.com"
            
            cupituber["email"] = correo

def cupitubers_suscritos_entre(datos_cupitube: dict, min_suscriptores: int, max_suscriptores: int) -> list:
    cupitubers_rango = []
    
    for pais, cupitubers in datos_cupitube.items():
        for cupituber in cupitubers:
            suscriptores = cupituber["subscribers"]
            if min_suscriptores <= suscriptores <= max_suscriptores:
                cupitubers_rango.append(cupituber)
    
    return cupitubers_rango

def promedio_suscriptores_por_categoria(datos_cupitube: dict) -> dict:
    categorias = {}
    
    for pais, cupitubers in datos_cupitube.items():
        for cupituber in cupitubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            
            if categoria in categorias:
                categorias[categoria]["total"] += suscriptores
                categorias[categoria]["cantidad"] += 1
            else:
                categorias[categoria] = {"total": suscriptores, "cantidad": 1}
    
    promedios = {}
    for categoria, datos in categorias.items():
        promedios[categoria] = datos["total"] / datos["cantidad"]
    
    return promedios