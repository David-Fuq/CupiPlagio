# Solución: Verifica la ubicación exacta del archivo
import os
print("Archivo existe:", os.path.exists("cupitube.csv"))
print("Ruta absoluta:", os.path.abspath("cupitube.csv"))

# Solución: Inspecciona las primeras líneas del archivo
with open("cupitube.csv", "r", encoding="utf-8") as f:
    print("Primeras 3 líneas:")
    for _ in range(3):
        print(f.readline().strip())
        
def main():
    # 1. Carga de datos con verificación exhaustiva
    print("\n=== CARGANDO DATOS ===")
    datos = cargar_cupitube("cupitube.csv")
    
    if not datos:
        print("\n¡Error crítico! No se pudieron cargar los datos.")
        print("Posibles causas:")
        print("1. El archivo 'cupitube.csv' no está en la misma carpeta")
        print("2. El archivo tiene formato incorrecto")
        print("3. Problemas de permisos")
        return
    
    print(f"\n✓ Datos cargados correctamente ({len(datos)} países)")
    primer_pais = next(iter(datos))
    print(f"  Ejemplo: País '{primer_pais}' con {len(datos[primer_pais])} cupitubers")

    # 2. Pruebas interactivas
    print("\n=== INICIANDO PRUEBAS INTERACTIVAS ===")
    
    # Prueba 1 - Función más antigua
    print("\n1. Probando función más antigua...")
    ejecutar_buscar_cupituber_mas_antiguo(datos)
    
    # Prueba 2 - Visitas por categoría
    print("\n2. Probando visitas por categoría (ingrese 'Music' cuando se le pida)...")
    ejecutar_obtener_visitas_por_categoria(datos)
    
    # Prueba 3 - Categoría con más visitas
    print("\n3. Probando categoría con más visitas...")
    ejecutar_obtener_categoria_con_mas_visitas(datos)
    
    # Prueba 4 - Recomendación completa
    print("\n4. Probando recomendación (use estos valores):")
    print("   - Suscriptores: 1000000 y 10000000")
    print("   - Fechas: 2010-01-01 y 2023-12-31")
    print("   - Videos mínimos: 100")
    print("   - Palabra clave: 'game'")
    ejecutar_recomendar_cupituber(datos)

    # 3. Pruebas automatizadas
    print("\n=== INICIANDO PRUEBAS AUTOMATIZADAS ===")
    ejecutar_pruebas_automatizadas(datos)

def ejecutar_pruebas_automatizadas(datos):
    casos_prueba = [
        {
            "nombre": "Caso normal",
            "params": {
                "subs_min": 1000000,
                "subs_max": 10000000,
                "fecha_min": "2010-01-01",
                "fecha_max": "2023-12-31",
                "videos_min": 100,
                "palabra": "game"
            },
            "esperado": "Encontrar recomendación"
        },
        {
            "nombre": "Palabra vacía",
            "params": {
                "subs_min": 1000000,
                "subs_max": 10000000,
                "fecha_min": "2010-01-01",
                "fecha_max": "2023-12-31",
                "videos_min": 100,
                "palabra": ""
            },
            "esperado": "Rechazar palabra vacía"
        }
    ]

    for caso in casos_prueba:
        print(f"\n** Prueba: {caso['nombre']} **")
        print(f"Configuración: {caso['params']}")
        print(f"Resultado esperado: {caso['esperado']}")
        
        # Simulamos inputs de usuario
        class InputSimulado:
            def __init__(self, values):
                self.values = list(values)
                self.index = 0
            
            def __call__(self, prompt=""):
                value = self.values[self.index]
                self.index += 1
                return value
        
        # Guardamos el input original
        input_original = __builtins__.input
        
        try:
            # Reemplazamos input temporalmente
            __builtins__.input = InputSimulado([
                str(caso['params']['subs_min']),
                str(caso['params']['subs_max']),
                caso['params']['fecha_min'],
                caso['params']['fecha_max'],
                str(caso['params']['videos_min']),
                caso['params']['palabra']
            ])
            
            ejecutar_recomendar_cupituber(datos)
        except Exception as e:
            print(f"Error durante la prueba: {str(e)}")
        finally:
            # Restauramos input original
            __builtins__.input = input_original

if __name__ == "__main__":
    main()