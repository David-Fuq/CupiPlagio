#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May  7 17:52:13 2025

@author: nicolas
"""

# consola_cupitube.py
import cupitube

def mostrar_cupituber(c):
    print("\nCupiTuber:")
    for llave, valor in c.items():
        print(f"{llave}: {valor}")

def cargar_datos_csv() -> dict:
    ruta = input("Ingrese la ruta del archivo CSV: ")
    return cupitube.cargar_datos(ruta)

def mostrar_top_cupituber_por_pais(datos: dict):
    pais = input("Ingrese el país: ")
    if pais in datos:
        top = cupitube.cupituber_mas_suscriptores(datos, pais)
        mostrar_cupituber(top)
    else:
        print("País no encontrado.")

def generar_correos(datos: dict):
    cupitube.crear_correo_para_cupitubers(datos)
    print("Correos generados exitosamente.")

def ejecutar_programa():
    datos = {}
    while True:
        print("\nMenú CupiTube")
        print("1. Cargar archivo")
        print("2. CupiTuber con más suscriptores en un país")
        print("3. Generar correos")
        print("0. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            datos = cargar_datos_csv()
        elif opcion == "2":
            mostrar_top_cupituber_por_pais(datos)
        elif opcion == "3":
            generar_correos(datos)
        elif opcion == "0":
            print("Saliendo...")
            break
        else:
            print("Opción no válida")

# Descomente esta línea para ejecutar desde consola
# ejecutar_programa()
