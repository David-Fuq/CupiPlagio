#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May  7 17:50:33 2025

@author: nicolas
"""

def cargar_datos(ruta_archivo: str) -> dict:
    archivo = open(ruta_archivo, "r", encoding="utf-8")
    archivo.readline()  # saltar encabezado

    datos = {}

    for linea in archivo:
        partes = linea.strip().split(",")
        pais = partes[7]

        cupituber = {
            "rank": int(partes[0]),
            "cupituber": partes[1],
            "subscribers": int(partes[2]),
            "video_views": int(partes[3]),
            "video_count": int(partes[4]),
            "category": partes[5],
            "started": partes[6],
            "country": pais,
            "monetization_type": partes[8],
            "description": partes[9]
        }

        if pais in datos:
            datos[pais].append(cupituber)
        else:
            datos[pais] = [cupituber]

    archivo.close()
    return datos

def cupituber_mas_suscriptores(datos: dict, pais: str) -> dict:
    max_suscriptores = -1
    mejor = None
    for cupituber in datos[pais]:
        if cupituber["subscribers"] > max_suscriptores:
            max_suscriptores = cupituber["subscribers"]
            mejor = cupituber
    return mejor

def crear_correo_para_cupitubers(datos: dict) -> None:
    for lista in datos.values():
        for cupituber in lista:
            correo = cupituber["cupituber"].lower().replace(" ", "_") + "@cupitube.com"
            cupituber["correo"] = correo
