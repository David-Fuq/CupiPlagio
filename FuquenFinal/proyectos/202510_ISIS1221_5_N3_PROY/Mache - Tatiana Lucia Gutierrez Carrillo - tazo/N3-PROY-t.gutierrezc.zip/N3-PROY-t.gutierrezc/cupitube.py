#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
              - El país de origen de un CupiTuber se encuentra en la columna "country" del archivo CSV.
              - El país es un string no vacío, sin espacios al inicio o al final.
                Ejemplo: "India"
            
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber. 
              - Cada diccionario contiene los siguientes campos basados en las columnas del archivo CSV:
    
                "rank" (int): Ranking del CupiTuber en el mundo. Es un valor entero mayor a cero.
                              Ejemplo: 1
    
                "cupituber" (str): Nombre del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                   Ejemplo: "T-Series"
    
                "subscribers" (int): Cantidad de suscriptores del CupiTuber. Es un valor entero mayor a cero.
                                     Ejemplo: 222000000
    
                "video_views" (int): Cantidad de visitas de todos los videos del CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 198459090822
    
                "video_count" (int): Cantidad de videos publicados por el CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 17317
    
                "category" (str): Categoría principal de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                  Ejemplo: "Music"
    
                "started" (str): Fecha en la que el CupiTuber empezó a publicar videos en formato YYYY-MM-DD.
                                Es un string no vacío, sin espacios al inicio o al final.
                                Ejemplo: "2006-11-15"
    
                "monetization_type" (str): Tipo de monetización de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                           Ejemplo: "AdSense"
    
                "description" (str): Descripción del tipo de videos que publica el CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                     Ejemplo: "Amazing travel vlogs worldwide!"
    
    Notas importantes:
        1. Al usar readline(), agregue strip() de esta forma: readline().strip() para garantizar que se eliminen los saltos de línea.
            Documentación de str.strip(): https://docs.python.org/es/3/library/stdtypes.html#str.strip
            Documentación de readline(): https://docs.python.org/es/3/tutorial/inputoutput.html#methods-of-file-objects
            
        2. Al usar open(), agregue la codificación "utf-8" de esta forma: open(archivo, "r", encoding="utf-8") para garantizar la lectura de caracteres especiales del archivo CSV.
    """
    #TODO 1: Implemente la función tal y como se describe en la documentación.
    a_cupitubers = open(archivo,"r", encoding = "utf-8")  #Abre el archivo en modo lectura
    encabezados = a_cupitubers.readline().strip() #Lee la primera línea sin hacer nada más
    dict_cupitubers = {}
    
    for linea in a_cupitubers:   #Recorro cada linea del archivo
        pais_cupituber = linea.strip().split(",")[7] #Para cada línea va a leerla, a limpiarla de los saltos, a cortar en las comas y luego extrae la información de la posición 7 de la lista que cree con el split
        if pais_cupituber not in dict_cupitubers:
            dict_cupitubers[pais_cupituber] = [] #Crea una lista vacía si el país que se revisa todavía no es una llave
         
        rank_c = linea.strip().split(",")[0] #Extrae por separado cada pedazo de información de la lista (la limpia con el strip y separa en las comas con el split)
        nombre_c = linea.strip().split(",")[1]
        subs_c = linea.strip().split(",")[2]
        views_c = linea.strip().split(",")[3]
        videos_c = linea.strip().split(",")[4]
        categoria_c = linea.strip().split(",")[5]
        fecha_c = linea.strip().split(",")[6]
        money_c = linea.strip().split(",")[8]
        descripcion_c = linea.strip().split(",")[9]
        dict_cupitubers[pais_cupituber].append({"rank": rank_c, "cupituber": nombre_c, "subscribers": subs_c, "video_views": views_c, "video_count": videos_c, "category": categoria_c, "started": fecha_c, "monetization_type": money_c, "description": descripcion_c })
            #Añade a la lista un diccionario con la información de un cupituber usando los encabezados como las llaves y la info extraída como los valores
    a_cupitubers.close()
    return dict_cupitubers
     
    
    
#añadir a una llave la lista con los diccionarios 

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    #TODO 2: Implemente la función tal y como se describe en la documentación.
    cupitubers_cumplen = []
    for pais in cupitube: #Pasa por cada pais dentro del diccionario grande de clasificación
        i = 0
        cupitubers_pais = cupitube[pais] #Entra al pais en el que está el ciclo y extrae la lista de los diccionarios de cada país
        longitud = len(cupitubers_pais)
        while i<longitud: #Quiero que pase por cada posición de la lista para revisar cada cupituber
            informacion = cupitubers_pais[i] #Extrae el diccionario de cada cupituber
            suscriptores = informacion["subscribers"] # Extrae la información necesaria del cupituber en el que está el ciclo
            categoria = informacion["category"]
            if suscriptores_min <= int(suscriptores) and suscriptores_max >= int(suscriptores) and categoria == categoria_buscada:
                cupitubers_cumplen.append(informacion) #En caso de que cumpla con las condiciones, añade a la lista en la última posición el diccionario de ese cupituber que ya había extraído antes
            i += 1
    
    return cupitubers_cumplen


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    #TODO 3: Implemente la función tal y como se describe en la documentación.
    cupitubers_cumplen = []
    for pais in cupitube: #Pasa por cada pais dentro del diccionario grande de clasificación
        i = 0
        cupitubers_pais = cupitube[pais] #Entra al pais en el que está el ciclo y extrae la lista de los diccionarios de cada país
        longitud = len(cupitubers_pais)
        while i<longitud: #Quiero que pase por cada posición de la lista para revisar cada cupituber
            informacion = cupitubers_pais[i] #Extrae el diccionario de cada cupituber
            monetizacion = informacion["monetization_type"] # Extrae la información necesaria del cupituber en el que está el ciclo
            categoria = informacion["category"]
            if pais == pais_buscado and categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                cupitubers_cumplen.append(informacion) #En caso de que cumpla con las condiciones, añade a la lista en la última posición el diccionario de ese cupituber que ya había extraído antes
            i += 1
    
    return cupitubers_cumplen


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    
    #Usar como referencia el ejercicio donde se reemplazaba el valor de la variable cuando uno era mayor que otro 
    lista_paises = list(cupitube.keys())    #Saco una lista de las llaves del cupitube
    primer_pais = lista_paises[0]     #Extraigo el primer pais
    lista_cupitubers1 = cupitube[primer_pais]   #Extraigo la lista asociada al primer pais
    cupituber_original = lista_cupitubers1[0]   #Saco el diccionario del primer cupituber de la lista
    fecha_original = cupituber_original["started"]   #Guardo la fecha 
    
    for pais in cupitube:
        lista_x_pais = cupitube[pais]
        for cupituber in lista_x_pais:
            fecha_2 = cupituber ["started"]
            if fecha_2 < fecha_original:
                fecha_original = fecha_2
                cupituber_original = cupituber
                
    
    return cupituber_original
                                    

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    #TODO 5: Implemente la función tal y como se describe en la documentación.
    existe = False
    total_vistas = 0
    
    for pais in cupitube:   #Va a reccorer cada país del diccionario grande (cada llave)
        cupitubers_x_pais = cupitube[pais]   #Como el país son llaves, extraigo la lista del valor asociada al país
        for cupituber in cupitubers_x_pais: #Recorre cada cupituber (cada posición de la lista extraida del país)
            categoria = cupituber["category"]  #Extraigo la información de su categoria
            if categoria == categoria_buscada: #Solo entra a esta condición si la categoria coincide osea si existe 
                existe = True
                vistas_cupituber = cupituber["video_views"]   #Extraigo la información de sus vistas
                total_vistas += int(vistas_cupituber)
    
    return total_vistas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    #TODO 6: Implemente la función tal y como se describe en la documentación.
    lista_paises = list(cupitube.keys())   #Saco una lista de solo los paises (llaves)
    pais1 = lista_paises[0]    #Extraigo el primer país
    cupitubers_1 = cupitube[pais1]    #Extraigo la lista de los cupitubers del primer país
    categoria_1 = cupitubers_1[0]["category"]    #De la primera lista, extraigo el primer cupituber y extraigo su categoria 
    visitas_1 = obtener_visitas_por_categoria(cupitube, categoria_1)    #Llamo a la función anterior para saber cuales son las visitas totales de esa primera categoria 
    
    i = 0
    lista_valores = list(cupitube.values())   #Saco una lista de los valores (listas de cupitubers) asociadas a cada país
    while i < len(lista_valores): #Recorro la lista de listas en cada posición
        cupitubers = lista_valores[i]   #Extraigo la lista de los cupitubers en la posición i de la lista de valores 
        x = 1
        while x < len(cupitubers):   #Recorro cada posición de la lista de cupitubers de un país
            categoria_nueva = lista_valores[i][x]["category"] #De la lista de valores en la posición i, dentro de la lista de cupitubers de un país en la posición x extraigo la categoría de ese cupituber x
            if categoria_nueva != categoria_1:
                visitas_nuevas = obtener_visitas_por_categoria(cupitube, categoria_nueva)     #De esa siguiente categoría analizada, llamo a la función anterior para guardar las visitas totales de esa categoría nueva
                if visitas_nuevas > visitas_1:     #En caso de que los valores de las nuevas sean mayores que las primeras, reemplazo los valores 
                    visitas_1 = visitas_nuevas
                    categoria_1 = categoria_nueva
            x += 1
        i += 1

    categoria_mas_visitas = {"categoria": categoria_1, "visitas": visitas_1}

    return categoria_mas_visitas

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    #TODO 7: Implemente la función tal y como se describe en la documentación.
    lista_cupitubers_por_pais = list(cupitube.values())  #Sacar una lista con las listas de los cupitubers de cada país, es decir, los valores de cada llave del diccionario grande
    x = 0
    for pais in cupitube:  
        
        for cupituber in lista_cupitubers_por_pais[x]:   #Para cada valor dentro de la lista de cupitubers en la posición del indice de la lista de valores del diccionario grande 
            nombre = cupituber["cupituber"].strip().lower().replace(" ", "")  #Extraer el nombre del diccionario, quitarle los espacios del principio y final con strip, quitarle los espacios de adentro con replace y pasarlo a minúsculas
            fecha = cupituber["started"]
            año = fecha[2:4]
            mes = fecha [5:7]
            nombre_limpio = ""
            
            for letra in nombre:  #Recorro cada letra del nombre que saque antes 
                solo_caracteres_validos = letra.isalnum()   #Uso la función para validar si es un caracter válido
                if solo_caracteres_validos == True:
                    nombre_limpio += letra     #Añadir la letra si es válida a una variable con el nombre ya limpio
            
            nombre_usuario = nombre_limpio[:16]   #Recortar el nombre para que no tenga más de los 15 caracteres
                    
            correo = nombre_usuario + "." + año + mes + "@cupitube.com"     #crear el correo con las especificaciones del formato
            
            cupituber ["correo"] = correo    #añadir el correo como una nueva llave del diccionario 
            
        x += 1   #Para pasar por la lista completa de cada país
            
            #Preguntar si el caracter es alfanumerico y si si entonces ese caracter se añade a una nueva variable con el nombre limpio. Usar la función que nos dan para preguntar si es válido o no el caracter
            #También se puede hacer una lista con los caracteres válidos y preguntar si cada caracter está en esa lista y añadirlo 


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    
    categoria_mas_visitas = obtener_categoria_con_mas_visitas(cupitube) # Guarda el diccionario con la información de la categoria con más vistas
    categoria_top = categoria_mas_visitas["categoria"] #Extrae la categoria del diccionario que retorna la función
    
    for pais in cupitube:
        lista_paises = cupitube[pais]  #Extraer de la llave del país su respectivo valor que es la lista de cupitubers
        for cupituber in lista_paises:   #Recorrer cada cupituber de la lista
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            videos = cupituber["video_count"]
            fecha = cupituber["started"]
            descripcion = cupituber["description"].lower()
            palabra = palabra_clave.lower()
            
            if palabra in descripcion:
                if (categoria == categoria_top) and (int(suscriptores)>=suscriptores_min) and (int(suscriptores)<=suscriptores_max) and (int(videos) >= videos_minimos) and (fecha >= fecha_minima and fecha<= fecha_maxima):
                    return cupituber
    
    return {}
            
#Pasar primero todo a mayúsculas y minúsculas y luego si compararlo con el in


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    #TODO 9: Implemente la función tal y como se describe en la documentación.
    paises_x_categoria = {}
    lista_categorias = []
    
    #Sacar lista de las categorias presentes
    for pais in cupitube: #Recorrer cada pais del diccionario
        lista_paises = cupitube[pais]  #Extraer de la llave del país su respectivo valor que es la lista de cupitubers
        for cupituber in lista_paises: #Para cada posición, es decir, un cupituber 
            categoria_extraida = cupituber["category"]  #Extraer su respectiva categoria
            if categoria_extraida not in lista_categorias:   #Si la categoria no esta todavía en la lista
                lista_categorias.append(categoria_extraida)  #Añadir la categoria a la lista
                
    for categoria in lista_categorias:  #Recorrer cada categoria 
        for pais in cupitube:    #Recorrer cada pais del diccionario
            lista_paises = cupitube[pais]  #Extraer de la llave del país su respectivo valor que es la lista de cupitubers
            for cupituber in lista_paises:  #Para cada posición, es decir, un cupituber
                if cupituber["category"] == categoria:    #Comparar si la categoria del cupituber que estoy recorriendo coincide con la categoria que estoy recorriendo. Si es igual significa que ese país tiene por lo menos un cupituber con esa categoria y se debe añadir 
                    if categoria not in paises_x_categoria:  #si la categoria todavía no es una llave del diccionario que voy a retornar 
                        paises_x_categoria[categoria] = [pais]  #Añadir todo el par
                    else:      #Si la categoría ya es una llave
                        valores_llave_categoria = paises_x_categoria[categoria]     #Guardar la lista de paises asociada a la llave de la categoria analizada
                        if pais not in valores_llave_categoria:      #Si el país todavía no está en la lista
                            paises_x_categoria[categoria].append(pais)  #Añadir el país a la lista
    
    return paises_x_categoria
    