#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
# Funcion que ordena la  informacion del archivo csv a un diccionario
def cargar_cupitube(archivo: str) -> dict:
   # Creamos un diccionario donde guardaremlos  la  informacion de todos los cupituber
    cupitube={}
    arc= open(archivo, "r", encoding="utf-8")
    # Leemos la primera linea del archivo para asi sacar las llaves donde  posteriormente se guardara  la informacion de  los youtubers

    titulos= arc.readline().strip().split(",")
    print(titulos)
    
    linea=arc.readline()
    # Leemos la primera  linea e  inicializamos el while mientras en el cual mientras haya informacion en esa lina este no se detendra
    # Aqui añadimos la  informacion de  todos  los cupitubers al diccionario info esto separando toda la  informacion que tenemos con .split 
    while len(linea)>0:
        data= linea.split(",")
        country= data[7]
        info={}
        info["rank"]= int(data[0])
        info["cupituber"]=data[1]
        info["subscribers"]= int(data[2])
        info["video_views"]= int(data[3])
        info["video_count"]=int(data[4])
        info["category"]= data[5]
        info["started"]=data[6]
        info["monetization_type"]=data[8]
        info["description"]= data[9]
    # Luego de realizar el proceso  verificamos si la varible country que definimos con anterioridad se encuentra en el diccionario cupitube
    # Si no es el caso la  añadimos  y creamos  una  lista vacia donde  posteriormente añadiremos el diccionario info con toda  la  informacion de  los cupituber
        if  country not in cupitube:
            cupitube[country]=[]
        cupitube[country].append(info)
        linea= arc.readline()
     # Ahora seguimos a  la siguiente linea hasta que se  incumpla la  condicion del while              
    arc.close()
    # Por ultimo cerramos el archivo para evitar que se corrompa y retornamos el diccionario cupituber
    return cupitube
    
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
              - El país de origen de un CupiTuber se encuentra en la columna "country" del archivo CSV.
              - El país es un string no vacío, sin espacios al inicio o al final.
                Ejemplo: "India"
            
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber. 
              - Cada diccionario contiene los siguientes campos basados en las columnas del archivo CSV:
    
                "rank" (int): Ranking del CupiTuber en el mundo. Es un valor entero mayor a cero.
                              Ejemplo: 1
    
                "cupituber" (str): Nombre del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                   Ejemplo: "T-Series"
    
                "subscribers" (int): Cantidad de suscriptores del CupiTuber. Es un valor entero mayor a cero.
                                     Ejemplo: 222000000
    
                "video_views" (int): Cantidad de visitas de todos los videos del CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 198459090822
    
                "video_count" (int): Cantidad de videos publicados por el CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 17317
    
                "category" (str): Categoría principal de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                  Ejemplo: "Music"
    
                "started" (str): Fecha en la que el CupiTuber empezó a publicar videos en formato YYYY-MM-DD.
                                Es un string no vacío, sin espacios al inicio o al final.
                                Ejemplo: "2006-11-15"
    
                "monetization_type" (str): Tipo de monetización de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                           Ejemplo: "AdSense"
    
                "description" (str): Descripción del tipo de videos que publica el CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                     Ejemplo: "Amazing travel vlogs worldwide!"
    
    Notas importantes:
        1. Al usar readline(), agregue strip() de esta forma: readline().strip() para garantizar que se eliminen los saltos de línea.
            Documentación de str.strip(): https://docs.python.org/es/3/library/stdtypes.html#str.strip
            Documentación de readline(): https://docs.python.org/es/3/tutorial/inputoutput.html#methods-of-file-objects
            
        2. Al usar open(), agregue la codificación "utf-8" de esta forma: open(archivo, "r", encoding="utf-8") para garantizar la lectura de caracteres especiales del archivo CSV.
    """
    #TODO 1: Implemente la función tal y como se describe en la documentación.



# Función 2:
# Funcion que  busca todos los cupituber que pertenezcan a cierta categoria y  esten en el rango de suscripciones 
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    # Aqui   creamos  una lista donde retornaremos los cupitibers perteneciente al a la categoria seleccionada y al rango de suscriptores deseados 
    cupi_in=[]
    #Aqui  hacemos  un recorrido por  las  llaves de  los paises del diccionario cupitube y luego accedemos  a la informacion contendia en cada una de esas llaves por  medio de la variable youtuber 
    # Despues de acceder a el diccionario youtuber que seria igual a cupituber revisamos  por medio del if  las condiciones que  nos  pide la funcion y si estas se cumple  lo asignamos  a la lista cupi_in
    for pais in cupitube:
        for youtuber in cupitube[pais]:
            if youtuber["category"].lower()== categoria_buscada.lower() and suscriptores_min<= youtuber["subscribers"]<= suscriptores_max:
                cupi_in.append(youtuber)
    return cupi_in
# Aqui retornamos  la lista cumplido el ciclo for 
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    #TODO 2: Implemente la función tal y como se describe en la documentación.
    pass


# Función 3:
# Funcion para buscar el cupituber por  pais, categoria y monetizacion.
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    # Aqui creamos una  lista donde iran los cupitubers que cumpla con las condiciones de  categoria y  monetizacion asignadas por el usuario
    youtuber_int=[]
    # Hacemos un doble recorrido para encontrar  la  informacion de los cupitubers
    if pais_buscado in cupitube:
        for youtuber in cupitube[pais_buscado]:
            # Hacemos  un if en el cual filtramos  los datos de  los cupitubersn y los comparamos con los datos que  nos dio el usuario si todas estas condiciones se cumplen  añadimos la  informacion a la lista youtuber_int 
            if  youtuber["category"].lower()== categoria_buscada.lower() and youtuber["monetization_type"].lower()== monetizacion_buscada.lower():
                youtuber_int.append(youtuber)
    return youtuber_int
# Retortamos la  lista  con los cupitubers que cumplen con los criterios
        
            
    
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    #TODO 3: Implemente la función tal y como se describe en la documentación.
    pass


# Función 4:
#Funcion para buscar el cupituber mas antiguo
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    # Iniciamos  la  variable  inicio como un None para cumplir  en el caso inicial la condicion del if
    inicio= None
    # Hacemos un doble recorrido  para acceder a la  informacion de  los cupitubers pasando por la llave de  paises
    for  pais  in cupitube:
        for  youtuber in cupitube[pais]:
            # Se inicia la condicion en ella hacemos  una comparacion por  medion del  orden lexicografico al escribir la letraen el formato YYYY-MM-DD
            #Se  ininicializa con none para asi cumplir con el  if y luego se dispone para que el primer youtuber entrante sea el menor y luego si se encuentra otro menor se actualice y asi hasta terminar el for 
            if inicio is  None or  youtuber["started"]< inicio:
                inicio= youtuber["started"]
                antiguo= youtuber
                # Aqui se toma la variable antiguo para conocer el  nombre del cupituber a medida que  pasa el ciclo retornando el nombre de este 
    return antiguo
    
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    pass
            

# Función 5:
# Funcion que sirve para determinar  las visitas de  una categoria segun la  preferencia del usuario
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    # Para  la  obtencion de  la funcion  com mas  visitas colocamos  una variable igual a cero  en donde asignaremos el numero de visitas 
    visitas=0
    # Hacemos un doble recorrido para asi obtener la informacion de  los cupitubers
    for pais  in cupitube:
        for  youtuber in cupitube[pais]:
            # Aqui filtramos la categoria que estamos buscando con la que  nos da el usuario
            # En caso de que la categoria del cupitber sea igual a  la  buscada sumamos estas visitas del youtuber a la variable visitas
            if youtuber["category"].lower()== categoria_buscada.lower():
                visitas+= youtuber["video_views"]
            # Por ultimo retornamos la viriable visitas con el total de visitas que encontramos  por categoria 
    return visitas
        
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    #TODO 5: Implemente la función tal y como se describe en la documentación.
    pass


# Función 6:
# Funcion para  obtener la categoria con mas  visitas 
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    # Aqui iniciamos  un diccionario vacio donde  guardaremos  la categoria con mas  visitas 
    catego={}
    # Hacemos  un doble recorrido para acceder a  las categorias de  los  youtuber y sus visitas
    for pais  in cupitube:
        for  youtuber in cupitube[pais]:
            categoria=  youtuber["category"]
            visitas=  youtuber["video_views"]
            # Aqui establecemos que si la categoria del cupituber no se encuentra en el diccionario que creamos lo agregue
            # Asignando la variavle definida como categoria como llave y la de visitas como valor 
            if not categoria in catego:
                catego[categoria]= visitas
            # En caso de que  ya exista solo sumamos el numero de visitas
            else:
                catego[categoria]+= visitas
    # Aqui colocamos  una cadena vacia a  la cual luego asignaremos el nombre de  la categoria con mayor numero de visitas
    # Igualmente con el numero de visitas lo inicializamos con un numero negativo ya que no existe ningun cupituber con visitas negativas
    mejor_categoria=" "
    mayores_views= -1
    # Hacemos un recorrido por el diccionario de las categorias y sus visitas evaluamos por cada categoria y al ser todas mayor a menos 1 la primera queda como mejor categoria y ahi empieza a compararse con las demas 
    # En caso de que  halla alguna que  lo supere lo actualizamos con la categoria ademas de que  le asignamos a mejor categoria el  nombre de aquella categoria con mayor numero de visitas 
    for views  in catego:
            if  catego[views]> mayores_views:
                mayores_views= catego[views]
                mejor_categoria= views
    # Completado el ciclo creamos un diccionario donde guardaremos  con dos llaves el nombre de  la categoria con el nombre "categoria" y el otro "visitas" para la categoria con mayor numero de vistias 
    mejor={}
    mejor["categoria"]=mejor_categoria
    mejor ["visitas"]=mayores_views
    #Retornamos el diccionario mejor con los valores asignados
    return mejor
    
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    #TODO 6: Implemente la función tal y como se describe en la documentación.
    pass


# Funcion 7:
# Funcion que asigna correos  para todos  los cupituber 
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
   #Hacemos  un doble recorrido  para acceder a la  informacion de  los cupituber
    for pais in cupitube :
        for  youtuber in cupitube[pais]:
    # Creamos  una variable  llamada correo que es  una cadena vacia en ella se almacenara el correo para cada cupituber por cada recorrido 
    # y tambien creamos una variable x que contenga el  nombre del  cupituber 
            correo=""
            x= youtuber["cupituber"]
    # Hacemps otro ciclo en el cual se recorre cada caracter de  la variable x y lo evaluamos con la funcion .isalnum la cual verifica si el caracter es alfanumerico 
    # En caso de ser True se añade el caracter  a la  variable correo al evaluar  la cadena y salir del ciclo se recorta hasta 15 valores por  medio de slides y coloco estos en minusculas y le añado un .
            for  i in range(len(x)):  
                if x[i].isalnum()== True:
                    correo+=x[i]
            correo= correo[:15].lower() + "."
    # Luego accedemos a la fecha de inicio del youtuber sacamos el año  y mes de inicio por slides y añado "@cupitube.com"
    # Luego añadimos el correo cupituber  modificando con esto el diccionario al añadir una  nueva llave llamada correo
            correo+= youtuber["started"][2:4]+youtuber["started"][5:7]+"@cupitube.com"
            youtuber["correo"]= correo
    # No retornamos  nada ya que estamos añadiendo es solo informacion al diccionario  
                
                
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    #TODO 7: Implemente la función tal y como se describe en la documentación.
    pass


# Función 8:
# Funcion que recomienda un cupituber en base a  las  preferencias dadas por el usuario
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    # Llamamos la funcion 6 para saber el nombre de  la categoria con mayor  numero de visitas 
    mejor= obtener_categoria_con_mas_visitas(cupitube)
    # Creamos  un diccionario donde almacenaremos  la  informacion del cupituber recomendado 
    youtuber_recomendado={}
    encontrado= False 
    # Se usa un centinela  para poder evaluar  la condicion del if 
    # Hacemos  un doble recorrido para  poder acceder  a la  informacion de  los cupitubers
    for paises in cupitube:
        for youtuber in cupitube[paises]:
            # En este apartado hacemos las condiciones del if accediento a  la  informacion de los cupitubers y mirando si estos estan entre los valores establecidos por el usuario en suscriptores y fecha
            # Ademas verificamos si la  palabra clave dada por el usuario se encuentra en la descripcion del cupituber
            suscripciones=  suscriptores_min<= youtuber["subscribers"]<= suscriptores_max
            creacion= fecha_minima<= youtuber["started"]<= fecha_maxima
            videos= videos_minimos <= youtuber["video_count"]
            palabra=   palabra_clave.lower() in youtuber["description"].lower()
            categorias=  youtuber["category"]== mejor["categoria"]
            # Aqui tomamos  la condicion del if y en caso de que halla un  cupituber que cumpla con estas condiciones  asignamos su diccionario al  de  youtuber recomendado 
            if   categorias and suscripciones and creacion and videos and palabra and encontrado== False :
                youtuber_recomendado= youtuber
                encontrado= True
    # Por ultimo cambiamos el centinela a true cuando ya se encontro el primer cupituber
    # Retornamos el diccionario de youtuber_recomendado
    return youtuber_recomendado

    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    pass


# Función 9:
# Funcion para determinar los  paises que  participan en cierta categoria 

def paises_por_categoria(cupitube: dict) -> dict:
    # Creamos  un diccionario donde  guardaremos las categorias como llaves y  los paises como valores 
    categoria={}
    # Realizamos un doble recorrido para asi acceder a  la  informacion de  los cupituber 
    for paises in cupitube:
        for  youtuber  in cupitube[paises]:
    # Luego de acceder a esta  informacion verificamos si la categoria del cupituber se encuentra en el diccionario categoria 
    # En caso de que no se añade una  llave con la  categoria y luego se le asigna como valor una  lista donde se asignara  el  pais  en el cual se esta  haciendo el recorrido 
            if not  youtuber["category"] in categoria:
                categoria[youtuber["category"]]= [paises]
    # En caso de que  la categoria ya exista en el diccionario se verifica que el pais exista en caso de que no se añade el pais a  la  lista 
            else:
                if paises not  in categoria[youtuber["category"]]:
                    categoria[youtuber["category"]].append(paises)
    # Por ultimo se retorna el diccionario donde estan las categorias y paises 
    return categoria
    """
   Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

   Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.

   Retorno:
       dict: Diccionario en el que las llaves son los nombres de las categorías y 
             los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

   Nota:
       - No se permiten países repetidos en la misma categoría.
       - Un país puede aparecer en varias categorías.
       - Cada categoría debe tener al menos un país asociado.
       - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
   
   Ejemplo:    
      Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
          ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
      ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
      Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
   """
   #TODO 9: Implemente la función tal y como se describe en la documentación.
   
                
                
    

