#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May  5 18:51:59 2025

@author: santinieto
"""
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    paises = {}    
    archivo_paises = open(archivo, "r", encoding="utf-8")
    archivo_paises.readline()
    linea = archivo_paises.readline() 
    while len(linea) > 0:
        datos = linea.strip("\n").split(",")
        if len(datos) >= 10:
            cupitube = {"rank": int(datos[0]), "cupituber": datos[1],"subscribers": int(datos[2]), "video_views": int(datos[3]), "video_count": int(datos[4]), "category": datos[5], "started": datos[6], "monetization_type": datos[8], "description": datos[9]}
            pais = datos[7].strip()
            if pais not in paises:
                paises[pais] = []
            paises[pais].append(cupitube)
            linea = archivo_paises.readline()
    archivo_paises.close()
    return paises

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resultado = []
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            suscriptores = cupituber["subscribers"]
            categoria = cupituber["category"]
            if suscriptores >= suscriptores_min and suscriptores <= suscriptores_max and categoria == categoria_buscada:
                resultado.append(cupituber)
    return resultado



# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    lista_filtrada = []
    if pais_buscado in cupitube.keys():
        cupitubers_del_pais = cupitube[pais_buscado]
        for c in cupitubers_del_pais:
            categoria = c["category"]
            monetizacion = c["monetization_type"]
            if categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                lista_filtrada.append(c)
    return lista_filtrada

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for c in cupitubers:
            if mas_antiguo is None:
                mas_antiguo = c
            elif c["started"] < mas_antiguo["started"]:
                mas_antiguo = c
    return mas_antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    visitas_acumuladas = 0
    for nombre_pais in cupitube:
        for creador in cupitube[nombre_pais]:
            if creador["category"].strip().lower() == categoria_buscada.strip().lower():
                visitas_acumuladas += creador["video_views"]
    return visitas_acumuladas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_categorias = {}
    for clave_pais in cupitube:
        for creador in cupitube[clave_pais]:
            cat = creador["category"]
            vistas = creador["video_views"]
            if cat in visitas_categorias:
                visitas_categorias[cat] += vistas
            else:
                visitas_categorias[cat] = vistas
    mayor_categoria = None
    mayor_vistas = -1
    for cat in visitas_categorias:
        if visitas_categorias[cat] > mayor_vistas:
            mayor_vistas = visitas_categorias[cat]
            mayor_categoria = cat
    return {mayor_categoria: mayor_vistas}


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    todos_los_creadores = []
    for pais in cupitube:
        for creador in cupitube[pais]:
            todos_los_creadores.append(creador)
    for persona in todos_los_creadores:
        nombre = persona["cupituber"].lower()
        limpio = ""
        indice = 0
        while indice < len(nombre):
            letra = nombre[indice]
            if letra.isalnum():
                limpio = limpio + letra
            indice = indice + 1
        if len(limpio) > 15:
            limpio = limpio[:15]
        fecha = persona["started"]
        partes = fecha.split("-")
        año = partes[0]
        mes = partes[1]
        correo = limpio + "." + año[-2:] + mes + "@cupitube.com"
        persona["correo"] = correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    visitas_categorias = {}
    for clave_pais in cupitube:
        for creador in cupitube[clave_pais]:
            cat = creador["category"]
            vistas = creador["video_views"]
            if cat in visitas_categorias:
                visitas_categorias[cat] += vistas
            else:
                visitas_categorias[cat] = vistas
    mayor_categoria = None
    mayor_vistas = -1
    for cat in visitas_categorias:
        if visitas_categorias[cat] > mayor_vistas:
            mayor_vistas = visitas_categorias[cat]
            mayor_categoria = cat
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (cupituber["category"] == mayor_categoria and suscriptores_min <= cupituber["subscribers"] <= suscriptores_max and cupituber["video_count"] >= videos_minimos and fecha_minima <= cupituber["started"] <= fecha_maxima and palabra_clave.lower() in cupituber["description"].lower()):
                return cupituber

    return {"categoria": mayor_categoria, "visitas": mayor_vistas}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias_por_pais = {}
    lista_paises = list(cupitube.keys())
    for i in range(len(lista_paises)):
        pais = lista_paises[i]
        lista_creadores = cupitube[pais]
        for creador in lista_creadores:
            categoria = creador["category"]
            if categoria not in categorias_por_pais:
                categorias_por_pais[categoria] = []
            if pais not in categorias_por_pais[categoria]:
                categorias_por_pais[categoria].append(pais)
    return categorias_por_pais