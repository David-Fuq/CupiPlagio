import cupitube as ct

###### Funciones auxiliares (NO MODIFICAR):

def mostrar_cupituber(cupituber: dict) -> None:
    """
    Muestra la información de un CupiTuber.
    """
    print(
        f"Nombre: {cupituber['cupituber']}\n"
        f"Posición en ranking: {cupituber['rank']}\n"
        f"Suscriptores: {cupituber['subscribers']}\n"
        f"Visitas de video: {cupituber['video_views']}\n"
        f"Número de videos: {cupituber['video_count']}\n"
        f"Categoría: {cupituber['category']}\n"
        f"Año de inicio: {cupituber['started']}\n"
        f"Tipo de monetización: {cupituber['monetization_type']}\n"
        f"Descripción: {cupituber['description']}\n"
    )
    print("#" * 50)


def mostrar_cupitubers(cupitubers: list) -> None:
    """
    Muestra la información de múltiples CupiTubers.
    """
    print("\nCupiTubers encontrados:")
    print("-" * 50)
    for c in cupitubers:
        mostrar_cupituber(c)
    print("-" * 50)


def mostrar_paises(paises: list) -> None:
    """
    Muestra los países que tienen CupiTubers en una categoría específica.
    """
    print("-" * 50)
    for pais in paises:
        print(pais)
    print("-" * 50)

# Importar las funciones del módulo cupitube
from cupitube import (
    buscar_por_categoria_y_rango_suscriptores,
    buscar_cupitubers_por_pais_categoria_monetizacion,
    buscar_cupituber_mas_antiguo,
    obtener_visitas_por_categoria,
    obtener_categoria_con_mas_visitas,
    crear_correo_para_cupitubers,
    recomendar_cupituber,
    paises_por_categoria
)

# Ejecutores de menú

def ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ")
    minimo = int(input("Ingrese el mínimo de suscriptores: "))
    maximo = int(input("Ingrese el máximo de suscriptores: "))
    resultados = buscar_por_categoria_y_rango_suscriptores(cupitube, minimo, maximo, categoria)
    if resultados:
        mostrar_cupitubers(resultados)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict) -> None:
    pais = input("Ingrese el país: ")
    categoria = input("Ingrese la categoría: ")
    monetizacion = input("Ingrese el tipo de monetización: ")
    resultados = buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais, categoria, monetizacion)
    if resultados:
        print(f"\nLos CupiTubers de {pais} que pertenecen a la categoría {categoria} y tienen monetización {monetizacion} son:")
        mostrar_cupitubers(resultados)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupituber_mas_antiguo(cupitube: dict) -> None:
    cupituber = buscar_cupituber_mas_antiguo(cupitube)
    if cupituber:
        print(f"El CupiTuber más antiguo es {cupituber['cupituber']} y empezó en {cupituber['started']}.")
    else:
        print("No hay CupiTubers en los datos.")


def ejecutar_obtener_visitas_por_categoria(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ")
    total = obtener_visitas_por_categoria(cupitube, categoria)
    print(f"El total de visitas para la categoría {categoria} es: {total}.")


def ejecutar_obtener_categoria_con_mas_visitas(cupitube: dict) -> None:
    info = obtener_categoria_con_mas_visitas(cupitube)
    print(f"La categoría con más visitas es {info['categoria']} con {info['visitas']} visitas.")


def ejecutar_crear_correo_para_cupitubers(cupitube: dict) -> None:
    crear_correo_para_cupitubers(cupitube)
    if 'USA' in cupitube and cupitube['USA']:
        primero = cupitube['USA'][0]
        print(f"El correo para el primer Cupituber de 'USA' con nombre '{primero['cupituber']}' es: {primero['correo']}." )
    else:
        print("No hay datos para 'USA'.")


def ejecutar_recomendar_cupituber(cupitube: dict) -> None:
    sus_min = int(input("Ingrese el mínimo de suscriptores: "))
    sus_max = int(input("Ingrese el máximo de suscriptores: "))
    fecha_min = input("Ingrese la fecha mínima (YYYY-MM-DD): ")
    fecha_max = input("Ingrese la fecha máxima (YYYY-MM-DD): ")
    videos_min = int(input("Ingrese el número mínimo de videos: "))
    palabra = input("Ingrese la palabra clave: ")
    recomendado = recomendar_cupituber(cupitube, sus_min, sus_max, fecha_min, fecha_max, videos_min, palabra)
    if recomendado:
        print("El Cupituber recomendado tiene la siguiente información:")
        mostrar_cupituber(recomendado)
    else:
        print("No se encontró un CupiTuber que cumpla con los criterios.")


def ejecutar_paises_por_categoria(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ")
    datos = paises_por_categoria(cupitube)
    if categoria in datos:
        print(f"Los países con CupiTubers en la categoría {categoria} son:")
        mostrar_paises(datos[categoria])
    else:
        print("La categoría ingresada no existe en los datos.")


def iniciar_aplicacion() -> None:
    archivo = input("Ingrese el nombre del archivo CSV (ej. cupitube.csv): ")
    datos = ct.cargar_cupitube(archivo)
    if not datos:
        print("Error al cargar datos. Verifique el nombre y la ruta del archivo.")
        return

    while True:
        print("""
Menú de CupiTube:
1. Buscar por categoría y rango de suscriptores
2. Buscar por país, categoría y monetización
3. Buscar CupiTuber más antiguo
4. Obtener visitas por categoría
5. Obtener categoría con más visitas
6. Crear correo para CupiTubers (USA)
7. Recomendar CupiTuber
8. Países por categoría
0. Salir
""")
        opcion = input("Seleccione una opción: ")
        if opcion == "1":
            ejecutar_buscar_por_categoria_y_rango_suscriptores(datos)
        elif opcion == "2":
            ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(datos)
        elif opcion == "3":
            ejecutar_buscar_cupituber_mas_antiguo(datos)
        elif opcion == "4":
            ejecutar_obtener_visitas_por_categoria(datos)
        elif opcion == "5":
            ejecutar_obtener_categoria_con_mas_visitas(datos)
        elif opcion == "6":
            ejecutar_crear_correo_para_cupitubers(datos)
        elif opcion == "7":
            ejecutar_recomendar_cupituber(datos)
        elif opcion == "8":
            ejecutar_paises_por_categoria(datos)
        elif opcion == "0":
            print("¡Hasta pronto!")
            break
        else:
            print("Opción inválida. Intente de nuevo.")

if __name__ == "__main__":
    iniciar_aplicacion()
