#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
              - El país de origen de un CupiTuber se encuentra en la columna "country" del archivo CSV.
              - El país es un string no vacío, sin espacios al inicio o al final.
                Ejemplo: "India"
            
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber. 
              - Cada diccionario contiene los siguientes campos basados en las columnas del archivo CSV:
    
                "rank" (int): Ranking del CupiTuber en el mundo. Es un valor entero mayor a cero.
                              Ejemplo: 1
    
                "cupituber" (str): Nombre del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                   Ejemplo: "T-Series"
    
                "subscribers" (int): Cantidad de suscriptores del CupiTuber. Es un valor entero mayor a cero.
                                     Ejemplo: 222000000
    
                "video_views" (int): Cantidad de visitas de todos los videos del CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 198459090822
    
                "video_count" (int): Cantidad de videos publicados por el CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 17317
    
                "category" (str): Categoría principal de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                  Ejemplo: "Music"
    
                "started" (str): Fecha en la que el CupiTuber empezó a publicar videos en formato YYYY-MM-DD.
                                Es un string no vacío, sin espacios al inicio o al final.
                                Ejemplo: "2006-11-15"
    
                "monetization_type" (str): Tipo de monetización de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                           Ejemplo: "AdSense"
    
                "description" (str): Descripción del tipo de videos que publica el CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                     Ejemplo: "Amazing travel vlogs worldwide!"
    
    Notas importantes:
        1. Al usar readline(), agregue strip() de esta forma: readline().strip() para garantizar que se eliminen los saltos de línea.
            Documentación de str.strip(): https://docs.python.org/es/3/library/stdtypes.html#str.strip
            Documentación de readline(): https://docs.python.org/es/3/tutorial/inputoutput.html#methods-of-file-objects
            
        2. Al usar open(), agregue la codificación "utf-8" de esta forma: open(archivo, "r", encoding="utf-8") para garantizar la lectura de caracteres especiales del archivo CSV.
    """
    datos = {}
    try:
        with open(archivo, "r", encoding="utf-8") as f:
            # Leer y descartar línea de encabezados
            header = f.readline().strip()
            for linea in f:
                linea = linea.strip()
                if not linea:
                    continue
                partes = linea.split(",")
                # Asignar campos
                rank = int(partes[0].strip())
                cupituber = partes[1].strip()
                subscribers = int(partes[2].strip())
                video_views = int(partes[3].strip())
                video_count = int(partes[4].strip())
                category = partes[5].strip()
                started = partes[6].strip()
                country = partes[7].strip()
                monetization_type = partes[8].strip()
                description = partes[9].strip()
                # Construir registro
                registro = {
                    "rank": rank,
                    "cupituber": cupituber,
                    "subscribers": subscribers,
                    "video_views": video_views,
                    "video_count": video_count,
                    "category": category,
                    "started": started,
                    "monetization_type": monetization_type,
                    "description": description
                }
               
                datos.setdefault(country, []).append(registro)
    except FileNotFoundError:
        return {}
    return datos


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    """
    return [c for lista in cupitube.values() for c in lista
            if c["category"] == categoria_buscada
            and suscriptores_min <= c["subscribers"] <= suscriptores_max]

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    """
    if pais_buscado not in cupitube:
        return []
    return [c for c in cupitube[pais_buscado]
            if c["category"] == categoria_buscada
            and c["monetization_type"] == monetizacion_buscada]

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio.
    """
    mas_antiguo, fecha_min = None, None
    for lista in cupitube.values():
        for c in lista:
            if fecha_min is None or c["started"] < fecha_min:
                mas_antiguo, fecha_min = c, c["started"]
    return mas_antiguo or {}

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas acumuladas para una categoría dada.
    """
    return sum(c["video_views"] for lista in cupitube.values() for c in lista
               if c["category"] == categoria_buscada)

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas acumuladas.
    """
    visitas_por_cat = {}
    for lista in cupitube.values():
        for c in lista:
            visitas_por_cat[c["category"]] = visitas_por_cat.get(c["category"], 0) + c["video_views"]
    if not visitas_por_cat:
        return {"categoria": "", "visitas": 0}
    cat_max = max(visitas_por_cat, key=visitas_por_cat.get)
    return {"categoria": cat_max, "visitas": visitas_por_cat[cat_max]}

# Función 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber.
    """
    for lista in cupitube.values():
        for c in lista:
            limpio = ''.join(ch for ch in c["cupituber"] if ch.isalnum())[:15].lower()
            fecha = c["started"]
            year, month = fecha[2:4], fecha[5:7]
            c["correo"] = f"{limpio}.{year}{month}@cupitube.com"

# Función 8:
def recomendar_cupituber(cupitube: dict, sus_min: int, sus_max: int, fecha_min: str, fecha_max: str, videos_min: int, palabra_clave: str) -> dict:
    """
    Recomienda al primer CupiTuber que cumpla con todos los criterios.
    """
    if not palabra_clave:
        return {}
    cat_mayor = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    for lista in cupitube.values():
        for c in lista:
            if (c["category"] == cat_mayor
                and sus_min <= c["subscribers"] <= sus_max
                and c["video_count"] >= videos_min
                and fecha_min <= c["started"] <= fecha_max
                and palabra_clave.lower() in c["description"].lower()):
                return c
    return {}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría con países únicos.
    """
    resultado = {}
    for pais, lista in cupitube.items():
        for c in lista:
            resultado.setdefault(c["category"], set()).add(pais)
    return {cat: list(paises) for cat, paises in resultado.items()}


if __name__ == "__main__":
    # Carga y prueba con la base de datos enviada
    archivo = "cupitube.csv"
    datos = cargar_cupitube(archivo)
    if not datos:
        print(f"No se pudo cargar el archivo: {archivo}")
    else:
        print("Carga exitosa de CupiTube")
        print(f"Países disponibles: {list(datos.keys())}")
        total = sum(len(v) for v in datos.values())
        print(f"Total de CupiTubers cargados: {total}")