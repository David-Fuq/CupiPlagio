#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
              - El país de origen de un CupiTuber se encuentra en la columna "country" del archivo CSV.
              - El país es un string no vacío, sin espacios al inicio o al final.
                Ejemplo: "India"
            
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber. 
              - Cada diccionario contiene los siguientes campos basados en las columnas del archivo CSV:
    
                "rank" (int): Ranking del CupiTuber en el mundo. Es un valor entero mayor a cero.
                              Ejemplo: 1
    
                "cupituber" (str): Nombre del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                   Ejemplo: "T-Series"
    
                "subscribers" (int): Cantidad de suscriptores del CupiTuber. Es un valor entero mayor a cero.
                                     Ejemplo: 222000000
    
                "video_views" (int): Cantidad de visitas de todos los videos del CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 198459090822
    
                "video_count" (int): Cantidad de videos publicados por el CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 17317
    
                "category" (str): Categoría principal de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                  Ejemplo: "Music"
    
                "started" (str): Fecha en la que el CupiTuber empezó a publicar videos en formato YYYY-MM-DD.
                                Es un string no vacío, sin espacios al inicio o al final.
                                Ejemplo: "2006-11-15"
    
                "monetization_type" (str): Tipo de monetización de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                           Ejemplo: "AdSense"
    
                "description" (str): Descripción del tipo de videos que publica el CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                     Ejemplo: "Amazing travel vlogs worldwide!"
    
    Notas importantes:
        1. Al usar readline(), agregue strip() de esta forma: readline().strip() para garantizar que se eliminen los saltos de línea.
            Documentación de str.strip(): https://docs.python.org/es/3/library/stdtypes.html#str.strip
            Documentación de readline(): https://docs.python.org/es/3/tutorial/inputoutput.html#methods-of-file-objects
            
        2. Al usar open(), agregue la codificación "utf-8" de esta forma: open(archivo, "r", encoding="utf-8") para garantizar la lectura de caracteres especiales del archivo CSV.
    """
    #se crea el diccionario que devolvera la informacion

    retorno = {}
    
    #se abre el archivo que contiene los cupitubers
    archi = open(archivo, "r", encoding="utf-8")
    
     #se lee la lina del arhivo y se separa su información en columnas, para cada iteración
    for line in archi:
            line = line.strip()
            columnas = line.split(",")

    #se almacena en distintas varias los valores de cada columna dependiendo de su contenido
            rank = columnas[0]
            cupituber = columnas[1]
            subscribers = columnas[2]
            video_views = columnas[3]
            video_count = columnas[4]
            category = columnas[5]
            started = columnas[6]
            pais = columnas[7].strip()
            monetization_type = columnas[8]
            description = columnas[9]

    #se almacena en un diccionario todos los atributos del cupituber

            datos = {
                "rank": rank,
                "cupituber": cupituber,
                "subscribers": subscribers,
                "video_views": video_views,
                "video_count": video_count,
                "category": category,
                "started": started,
                "monetization_type": monetization_type,
                "description": description
            }
    #se salta la primera linea, ya que son todos strings
            if pais != "country":
                
    #se mira que el pais no se encuentre en el diccionario para añadirlo
                   if pais not in retorno:
                       retorno[pais] = []
                       
    #se agrega al diccionario a la llave del pais los valores del cupituber
                   retorno[pais].append(datos)

    return retorno
        
    #TODO 1: Implemente la función tal y como se describe en la documentación.
    


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    retorno = []
    
    #se crea una lista de todos los paises dentro del diccionario cupitube
    paises = list(cupitube.keys())
    i = 0
    
    #se recorren todos los paises
    while(i < len(paises)):
        
        #se crea una lista de todos los cupitubers de cada pais 
        lista = cupitube[paises[i]]
        j = 0
        
        #se recorren todos los cupitubers
        while j < len(lista):
            #se evaluan los suscriptores y cateogrias de cada cupituber por separado
            cupi = lista[j]
            subs = int(cupi["subscribers"])
            cat = cupi["category"].title()
            
            #se comparan los parametros de suscriptores y categorias especificados por el usuario
            if (suscriptores_min <= subs <= suscriptores_max) and (cat == categoria_buscada):
                
                #si los parametros concuerdan se añade el cupituber a una lista de cupitubers que cumplan los requisitos de busqueda del usuario
                retorno.append(cupi)
            j+= 1
        i+= 1
    return retorno
           
            
    #TODO 2: Implemente la función tal y como se describe en la documentación.
    


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    retorno = []
    # revisa si el pais se encuentra en la base de datos de cupitube
    if pais_buscado in cupitube:
        
        #se crea una lista de todos los cupitubers del pais buscado
        lista = cupitube[pais_buscado]
        i = 0
        
        #se recorren todos los cupitubers del pais buscado
        while i < len(lista):
            
            #se evaluan el tipo de monetizacion y cateogria de cada cupituber por separado
            cupi = lista[i]
            mon = cupi["monetization_type"].lower()
            cat = cupi["category"].lower()

            
            # se compara la monetizacion y categoria del cupituber con los buscados
            if (mon == monetizacion_buscada) and (cat == categoria_buscada):
                
                #si concuerda se añade una lista de los posibles cupitubers
                retorno.append(cupi)
            i += 1

  
    return retorno
    #TODO 3: Implemente la función tal y como se describe en la documentación.
   


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    #se le asigna un valor temporal al cupituber mas antiguo
    antiguo = ""
    
    #se crea una lista de todos los paises dentro del diccionario cupitube
    paises = list(cupitube.keys())
    i = 0
    
    #se recorren todos los paises
    while(i < len(paises)):
        
        #se crea una lista de todos los cupitubers de cada pais 
        lista = cupitube[paises[i]]
        j = 0
        
        #se recorren todos los cupitubers
        while j < len(lista):
            
            #se ve si el cupituber es mas antiguo del que en este momento es el mas antiguo
            cupi = lista[j]
            if( antiguo == "") or (cupi["started"] < antiguo["started"]):
                antiguo = cupi
            j+= 1
        i+= 1
    return antiguo
    
    
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    #se inicializan las visitas de la categoria como 0
    visitas = 0
    
    #se crea una lista de todos los paises dentro del diccionario cupitube
    paises = list(cupitube.keys())
    i = 0
    
    #se recorren todos los paises
    while(i < len(paises)):
        
        #se crea una lista de todos los cupitubers de cada pais 
        lista = cupitube[paises[i]]
        j = 0
        
        #se recorren todos los cupitubers
        while j < len(lista):
            
            #se ve si el cupituber hace contenido de la cateogoria buscada
            cupi = lista[j]
            if(cupi["category"].title() == categoria_buscada):
                
                #si es asi, se suman las visitas del cupituber a las visitas totales
                visitas += int(cupi["video_views"])
            j+= 1
        i+= 1
    return visitas
    
    #TODO 5: Implemente la función tal y como se describe en la documentación.
    


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    #se crea una lista vacia para todas las categorias
    categorias = []
    
    #se crea una lista de todos los paises dentro del diccionario cupitube
    paises = list(cupitube.keys())
    i = 0
    
    #se recorren todos los paises
    while(i < len(paises)):
        #se crea una lista de todos los cupitubers de cada pais 
        lista = cupitube[paises[i]]
        j = 0
        
        #se recorren todos los cupitubers
        while j < len(lista):
            
            #se mira si la categoria del cupituber se encuentra en la lista de categorias
            categoria = lista[j]["category"]
            if categoria not in categorias:
                
               #si no es el caso se añade la categoria a la lista
               categorias.append(categoria)
            j+= 1
        i+= 1
        
        #se crea una cateogria maxima con un valor de visitas ficticio para poder comparar
        categoria_maxima = ""
        visita_maxima = -1
        k = 0   
        
    #se recorre la lista de categorias
    while k < len(categorias):
        
        #se ve si las visitas de la categoria actual son mayores a la categoria maxima, si es asi esta categoria se vuelve la maxima
        cat = categorias[k]
        vis = obtener_visitas_por_categoria(cupitube, cat)
        if vis > visita_maxima:
            visita_maxima = vis
            categoria_maxima = cat
        k+=1
    return {"categoria" : categoria_maxima, "visitas": visita_maxima}
        
    #TODO 6: Implemente la función tal y como se describe en la documentación.
    


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    
    #se crea una lista de todos los paises dentro del diccionario cupitube
    paises = list(cupitube.keys())
    i = 0
    
    #se recorren todos los paises
    while(i < len(paises)):
        
        #se crea una lista de todos los cupitubers de cada pais 
        lista = cupitube[paises[i]]
        j = 0
        
        #se recorren todos los cupitubers
        while j < len(lista):
            cupi = lista[j]
            
            #se consigue el nombre del cupituber
            nombre = cupi["cupituber"]
            n_limpio = ""
            
            k = 0
            
            #se recorre el nombre del cupituber en minuscula
            while k < len(nombre):
                caracter = nombre[k].lower()
                
                #atraves de assci se ve si el caracter del nombre e suna letra minuscula o un numero
                valor_ascii = ord(caracter)
                if(48 <= valor_ascii <= 57) or (97 <= valor_ascii <= 122):
                    
                    #si este es el caso se añade el caracter al nombre limpio del cupituber
                    n_limpio +=caracter
                k+= 1
                
            #se hace que el nombre no sea mayor a 15 caracteres
            n_limpio = n_limpio[:15]
            
            #se consigue la fecha de inicio del cupituber
            fecha = cupi["started"]
            year = fecha[2:4]
            month = fecha[5:7]
             
            #se genera un correo con el nombre limpio y su fecha de inicio
            correo = f"{n_limpio}.{year}{month}@cupitube.com"
            
            #se almacena ese correo en el diccionario del cupituber
            cupi["correo"] = correo
            j+=1
        i+=1
                
            
    #TODO 7: Implemente la función tal y como se describe en la documentación.
    


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #se crea una lista para los posibles cupitubers
    retorno = []
    
    #se crea un centinela que nos dice si se encontro a un cupituber
    encontrar = False 
    
    #se crea una lista de paises
    paises = list(cupitube.keys())
    i = 0
    
    #se recorre la lista de paises hasta encontrar un cupituber o que se acabe la lista
    while(i < len(paises) and encontrar == False):
        
        #se hace una lista de los cupitubers en un pais
        lista = cupitube[paises[i]]
        j = 0
        
        #se recorre la lista de cupitubers
        while j < len(lista):
            
            #se guardan los suscriptores, la descripicion, el numero de videos y la fecha de inicio del cupituber
            cupi = lista[j]
            subs = int(cupi["subscribers"])
            des = cupi["description"]
            date = cupi["started"]
            vid = int(cupi["video_count"])
            
            #se comparan todos los parametros registrados anteriormente con los que busca el usuario
            if (palabra_clave in des.title()) and (suscriptores_min <= subs <= suscriptores_max) and(fecha_minima <= date <= fecha_maxima) and (videos_minimos <= vid):
                
                #si se haya un cupituber, este se vuelve la lista de retorno y se le avisa al centinela que pare el recorrido
                retorno = cupi
                encontrar = True
            
            
            j+= 1
        i+= 1
    return retorno
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    retorno = {}
    
    # se crea un lista de paises
    paises = list(cupitube.keys())
    i = 0
    
    #se recorren los paies
    while i < len(paises):
        pais = paises[i]
        
        #se crea una lista de los cupitubers en el pais
        lista = cupitube[pais]
        j = 0
        
        #se recorre todos los cupituvbers
        while j < len(lista):
            cupituber = lista[j]
            categoria = cupituber["category"]
            
            #se mira que la categoria no este en el pais y se añade en caso de que no este
            if categoria not in retorno:
                retorno [categoria] = []
                
            #se mira si el pais hace parte de la lista de categorias
            if pais not in retorno[categoria]:
                retorno[categoria].append(pais)
            j += 1
        i+=1
    return retorno
    #TODO 9: Implemente la función tal y como se describe en la documentación.
    
