#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
 
def cargar_cupitube(archivo: str) -> dict:
    cupitube_data = {}  # Diccionario donde almacenaremos la información de los CupiTubers

    with open(archivo, "r", encoding="utf-8") as file:  
        file.readline().strip()  # Leer la primera línea (encabezados) y descartarla
        
        for linea in file:  # Recorrer cada línea del archivo
            datos = linea.strip().split(",")  # Limpiar espacios y dividir por comas

            # Extraer los datos y convertir los tipos adecuados
            country = datos[7].strip()
            cupituber_info = {
                "rank": int(datos[0]),
                "cupituber": datos[1].strip(),
                "subscribers": int(datos[2]),
                "video_views": int(datos[3]),
                "video_count": int(datos[4]),
                "category": datos[5].strip(),
                "started": datos[6].strip(),
                "monetization_type": datos[8].strip(),
                "description": datos[9].strip()
            }

            if country not in cupitube_data:
                cupitube_data[country] = []  

            cupitube_data[country].append(cupituber_info)  

    return cupitube_data  # Retornar el diccionario construido


# Función 2:

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers de una categoría dada y cuyo número de suscriptores esté dentro de un rango determinado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber.
        
    Retorno:
        list: Lista con los diccionarios de los CupiTubers que cumplen los criterios de búsqueda.
              Si no hay coincidencias, retorna una lista vacía.
    """
    
    resultado = []
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (suscriptores_min <= cupituber["subscribers"] <= suscriptores_max and 
                cupituber["category"] == categoria_buscada):
                
                resultado.append(cupituber)

    return resultado


# Función 3:

def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización específicos.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría de los videos.
        monetizacion_buscada (str): Tipo de monetización de los videos.
        
    Retorno:
        list: Lista con los diccionarios de los CupiTubers que cumplen con los criterios.
              Si no hay coincidencias o el país no existe, retorna una lista vacía.
    """
    
    resultado = []

    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if (cupituber["category"] == categoria_buscada and 
                cupituber["monetization_type"] == monetizacion_buscada):
                
                resultado.append(cupituber)

    return resultado
    

# Función 4:

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate, se retorna el primer CupiTuber encontrado.
    """

    mas_antiguo = None

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:  
                mas_antiguo = cupituber 

    return mas_antiguo 
    

# Función 5:

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
        int: Número total de visitas para la categoría especificada.
             Si la categoría no está presente en los datos, el resultado será 0.
    """
    
    total_visitas = 0 
    
    for pais in cupitube: 
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada:
                total_visitas += cupituber["video_views"] 
    
    return total_visitas


# Función 6:

def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Nombre de la categoría con más visitas.
            - "visitas": Total de visitas acumuladas para esa categoría.
    """
    visitas_por_categoria = {} 

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]

            
            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = visitas
            else:
                visitas_por_categoria[categoria] += visitas

    
    categoria_max = None
    visitas_max = -1

    for categoria, visitas in visitas_por_categoria.items():
        if visitas > visitas_max:
            categoria_max = categoria
            visitas_max = visitas

    return {"categoria": categoria_max, "visitas": visitas_max}
    

# Funcion 7:

def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico 
    y la añade al diccionario. Esta función modifica el diccionario recibido, añadiendo una nueva llave 
    "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    """
    for pais in cupitube:
        for cupituber in cupitube[pais]:
           
            nombre = cupituber["cupituber"]
            nombre_limpio = ''.join(c for c in nombre if c.isalnum())[:15]  # Solo caracteres alfanuméricos

            
            fecha_inicio = cupituber["started"]
            año = fecha_inicio[:4]
            mes = fecha_inicio[5:7]

           
            correo = f"{nombre_limpio.lower()}.{año[-2:]}{mes}@cupitube.com"

            
            cupituber["correo"] = correo


# Función 8:

def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    """
    Recomienda al primer CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    """
    

    categoria_mas_visitas = None
    max_visitas = 0
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            if visitas > max_visitas:
                max_visitas = visitas
                categoria_mas_visitas = categoria

    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
           
            if cupituber["category"] != categoria_mas_visitas:
                continue
            
            
            if not (suscriptores_min <= cupituber["subscribers"] <= suscriptores_max):
                continue
            
   
            if cupituber["video_count"] < videos_minimos:
                continue
            
           
            if not (fecha_minima <= cupituber["started"] <= fecha_maxima):
                continue
            
            
            if palabra_clave.lower() not in cupituber["description"].lower():
                continue
            
            
            return cupituber

   
    return {}


# Función 9:

def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados)
    de origen de los CupiTubers en esa categoría.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos
              un CupiTuber en dicha categoría.
    
    Ejemplo:
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
    """
    
    categorias_paises = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            if categoria not in categorias_paises:
                categorias_paises[categoria] = set()  
            categorias_paises[categoria].add(pais) 

    
    for categoria in categorias_paises:
        categorias_paises[categoria] = list(categorias_paises[categoria])

    return categorias_paises
