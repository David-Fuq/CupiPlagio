# -*- coding: utf-8 -*-
"""
Created on Thu May  1 17:03:41 2025

@author: Luis Posada
"""

import cupitube as ct

cupitube = ct.cargar_cupitube("cupitube.csv")

ct.crear_correo_para_cupitubers(cupitube)

