#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1:
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber.
    
    Notas importantes:
        1. Usar readline().strip() para eliminar saltos de línea.
        2. Usar open(archivo, "r", encoding="utf-8").
    """
    pais = {}

    with open(archivo, "r", encoding="utf-8") as arch:
        arch.readline().strip()
        l = arch.readlines()

        for linea in l:
            val = linea.strip().replace(";", ",").split(",")

            if len(val) == 10:
                rank = int(val[0].strip())
                cupituber = val[1].strip()
                subscribers = int(val[2].strip())
                video_views = int(val[3].strip())
                video_count = int(val[4].strip())
                category = val[5].strip()
                started = val[6].strip()
                country = val[7].strip()
                monetization_type = val[8].strip()
                description = val[9].strip()

                info_cupituber = {
                    "rank": rank,
                    "cupituber": cupituber,
                    "subscribers": subscribers,
                    "video_views": video_views,
                    "video_count": video_count,
                    "category": category,
                    "started": started,
                    "monetization_type": monetization_type,
                    "description": description
                }

                if country not in pais:
                    pais[country] = [info_cupituber]
                else:
                    pais[country] = pais[country] + [info_cupituber]

    return pais

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con los CupiTubers que cumplen con los criterios de búsqueda.
    """
    resultado = []
    categoria_buscada = categoria_buscada.lower()

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"].lower() == categoria_buscada:
                suscriptores = cupituber["subscribers"]
                if suscriptores_min <= suscriptores <= suscriptores_max:
                    resultado = resultado + [cupituber]
    
    return resultado

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada.
        
    Retorno:
        list: Lista con los CupiTubers que cumplen todos los criterios de búsqueda.
    """
    resultado = []

    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if (cupituber["category"].lower() == categoria_buscada.lower()) and (cupituber["monetization_type"].lower() == monetizacion_buscada.lower()):
                resultado = resultado + [cupituber]

    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Información del CupiTuber más antiguo.
    """
    mas_antiguo = None

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber

    return mas_antiguo


# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
    """
    total_visitas = 0
    categoria_buscada = categoria_buscada.lower()

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"].lower() == categoria_buscada:
                total_visitas = total_visitas + cupituber["video_views"]

    return total_visitas

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las llaves "categoria" y "visitas".
    """
    visitas_por_categoria = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            vistas = cupituber["video_views"]

            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = vistas
            else:
                visitas_por_categoria[categoria] = visitas_por_categoria[categoria] + vistas

    categoria_mayor = None
    visitas_mayor = -1

    for categoria in visitas_por_categoria:
        if visitas_por_categoria[categoria] > visitas_mayor:
            visitas_mayor = visitas_por_categoria[categoria]
            categoria_mayor = categoria

    return {
        "categoria": categoria_mayor,
        "visitas": visitas_mayor
    }

# Función 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    """
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre_original = cupituber["cupituber"]
            fecha = cupituber["started"]

            nombre_limpio = nombre_original.replace("@", "")
            nombre_limpio = nombre_limpio.replace(" ", "")
            nombre_limpio = nombre_limpio.replace("!", "")
            nombre_limpio = nombre_limpio.replace("#", "")
            nombre_limpio = nombre_limpio.replace("$", "")
            nombre_limpio = nombre_limpio.replace("%", "")
            nombre_limpio = nombre_limpio.replace("&", "")
            nombre_limpio = nombre_limpio.replace("(", "")
            nombre_limpio = nombre_limpio.replace(")", "")
            nombre_limpio = nombre_limpio.replace("-", "")
            nombre_limpio = nombre_limpio.replace("_", "")
            nombre_limpio = nombre_limpio.replace(".", "")
            nombre_limpio = nombre_limpio.replace(",", "")
            nombre_limpio = nombre_limpio.replace("?", "")
            nombre_limpio = nombre_limpio.replace("'", "")
            nombre_limpio = nombre_limpio.replace('"', "")


            nombre_limpio = nombre_limpio.lower()[:15]

            anio = fecha[2:4]
            mes = fecha[5:7]

            correo = nombre_limpio + "." + anio + mes + "@cupitube.com"

            cupituber["correo"] = correo

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
    """
    categoria_objetivo = obtener_categoria_con_mas_visitas(cupitube)["categoria"]

    palabra_clave = palabra_clave.lower()

    todos_cupitubers = []
    for lista in cupitube.values():
        todos_cupitubers = todos_cupitubers + lista

    i = 0
    recomendado = {}

    while i < len(todos_cupitubers) and recomendado == {}:
        actual = todos_cupitubers[i]
        if actual["category"] == categoria_objetivo:
            subs = actual["subscribers"]
            fecha = actual["started"]
            videos = actual["video_count"]
            descripcion = actual["description"].lower()

            if (suscriptores_min <= subs <= suscriptores_max) and \
               (fecha_minima <= fecha <= fecha_maxima) and \
               (videos >= videos_minimos) and \
               (palabra_clave in descripcion):
                recomendado = actual
        i = i + 1

    return recomendado

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.
    """
    categorias = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]

            if categoria not in categorias:
                categorias[categoria] = []

            if pais not in categorias[categoria]:
                categorias[categoria] = categorias[categoria] + [pais]

    return categorias
