# -*- coding: utf-8 -*-

"""
Ejercicio nivel 3: Notas de curso.
Módulo de cálculos.

Temas:
* Instrucciones repetitivas.
* Listas
* Diccionarios


@author: Cupi2
"""

import math

def cargar_estudiantes(nombre_archivo: str)->list:
    """ Carga las notas de los estudiantes de un curso a partir de un archivo en formato CSV.
    Se espera que el archivo CSV tenga una primera fila con los títulos de las columnas, seguida de varias filas,
    cada una de las cuales contiene la información de un estudiante.
    Las columnas deben estar separadas por comas y ordenadas de la siguiente manera:
        1. Código del estudiante
        2. Nombre del estudiante
        3. Nota obtenida por el estudiante
    Parámetros:
        nombre_archivo (str): El nombre del archivo que se va a cargar.
    Retorno: list
        Una lista con las notas que se cargaron del archivo. 
        La lista contiene diccionarios y cada uno de esos diccionarios tiene las siguientes llaves:
              1. codigo
              2. nombre
              3. nota
    """
    dict_estudiantes = {}
    archivo = open(nombre_archivo)
    titulos = archivo.readline().split(",")

    linea = archivo.readline()
    while len(linea) > 0:
        datos = linea.split(",")
        codigo = datos[0]
        estudiante = {"codigo": codigo, "nombre": datos[1], "nota": float(datos[2])}
        dict_estudiantes[codigo] = estudiante
        linea = archivo.readline()

    archivo.close()
    return list(dict_estudiantes.values())


def agregar_estudiante(estudiantes: list, codigo: str, nombre: str, nota: float)->bool:
    """ Agrega al final de la lista un nuevo estudiante con la información que se recibe
    por parámetro, siempre y cuando no exista previamente un estudiante con el mismo 
    código.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
        codigo (str): El código del estudiante que se desea añadir a la lista.
        nombre (str): El nombre del estudiante que se desea añadir a la lista.
        nota (float): La nota del estudiante que se desea añadir a la lista.
    Retorno: bool
        True si se pudo agregar el estudiante porque previamente no existía en la lista otro estudiante con el mismo código.
        False si ya existía un estudiante con el mismo código que entra por parámetro, 
        en cuyo caso el nuevo estudiante no es añadido.
    """
    
    x=True
    i=0
    
    while x==True and i<len(estudiantes):
        if estudiantes[i]["codigo"]== codigo:
            x= False
            i+=1
    if x==True:
        
        estudiantes.append({"codigo":codigo, "nombre":nombre, "nota":nota})
            
    return x


def cambiar_nota_estudiante(estudiantes: list, codigo: str, nota: float)->bool:
    """ Modifica la nota de un estudiante.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
        codigo (str): El código del estudiante a quien se desea cambiar la nota.
        nota (float): La nueva nota del estudiante.
    Retorno: bool
        True si se pudo modificar la nota del estudiante porque se encontró el estudiante en la lista
        False si en la lista no existía un estudiante con ese código y por consiguiente no se pudo cambiar la nota.
        
    """
    
    x=False
    i=0

    while x==False and i<len(estudiantes):
        if estudiantes[i]["codigo"]==codigo:
            x==True
        i+=1
        estudiantes[i]["nota"]= nota
            
            
    return x


def buscar_estudiante(estudiantes: list, codigo: str)->dict:
    """ Busca la información de un estudiante dado su código.
        Si el estudiante existe en la lista, retorna un diccionario con las llaves "codigo", "nombre" y "nota".
        Si el estudiante no existe en la lista, retorna None.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
        codigo (str): El código del estudiante buscado.
    Retorno: dict
        Un diccionario con las llaves "codigo", "nombre" y "nota", si se encuentra el estudiante con el código dado.
        None si no se encuentra un estudiante con el código dado.
        
    """
    
    i=0
    r=None
    while i<len(estudiantes):
        if estudiantes[i]["codigo"]==codigo:
            r= estudiantes[i]
        i+=1
    return r


def promedio(estudiantes: list) -> float:
    """Calcula y retorna el promedio de las notas de los estudiantes.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    Retorno: float
        El promedio de las notas de los estudiantes.
    """
    
    i=0
    r=0
    
    while i<len(estudiantes):
        r+=estudiantes[i]["nota"]
        i+=1
    r/= len(estudiantes)
    
    return r


def cuantos_encima_promedio(estudiantes: list) -> int:
    """Calcula y retorna la catidad de estudiantes cuya nota está por encima de la nota 
    promedio del curso.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    Retorno: int
        La cantidad de estudiantes cuya nota se encuientra por encima del promedio.
    """
    
    i=0
    r=0
    
    while i<len(estudiantes):
        if estudiantes[i]["nota"]> promedio(estudiantes):
            r+=1
        i+=1
    return 0


def peor_nota(estudiantes: list) -> float:
    """Retorna la peor nota de los estudiantes.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    Retorno: float
        La nota más baja entre todos los estudiantes.
    """
    
    i=0
    r=0
    peor=estudiantes[i]["nota"]
    
    while i<len(estudiantes):
        if estudiantes[i]["nota"]<
    return 0


def cuantos_peores_que(estudiantes: list, posicion: int) -> int:
    """Calcula y retorna la cantidad de estudiantes cuya nota es menor que la nota del estudiante
       que se encuentra, dentro de la lista, en la posición recibida por parámetro.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
        posicion (int): La posición del estudiante cuya nota será comparada con las demás.
    Retorno: int
        La cantidad de estudiantes cuyas notas son peores que la nota del estudiante en la posición dada por parámetro.
    """
    return 0


def cuantos_mejores_que(estudiantes: list, posicion: int) -> int:
    """Calcula y retorna la cantidad de estudiantes cuya nota es mejor que la nota del estudiante
       que se encuentra, dentro de la lista, en la posición recibida por parámetro.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
        posicion (int): La posición del estudiante cuya nota que será comparada con las demás.
    Retorno: int
        La cantidad de estudiantes cuyas notas son mejores que la nota del estudiante en la posición dada por parámetro.
    """
    return 0


def rango_con_mas_notas(estudiantes: list) -> int:
    """Calcula y retorna el rango en el cual se encuentra la mayoría de las notas del
    curso. Los rangos están definidos de la siguiente manera: 
        El rango 1 tiene las notas entre 0.0 a 1.99.
        El rango 2 tiene las notas entre 2.0 a 3.49.
        El rango 3 tiene las notas entre 3.5 a 5.0.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    Retorno: int
        El número del rango con una mayor cantidad de notas. La respuesta puede ser 1, 2 o 3.
    """
    return 0


def alguien_con_5(estudiantes: list) -> bool:
    """Informa si en la lista de estudiantes hay alguien con nota igual a 5.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    Retorno: bool
        True si se encuentra un estudiante con nota igual a 5.
        False de lo contrario.
    """
    return False


def posicion_tercer_5(estudiantes: list)->int:
    """Calcula y retornar la posición en la lista del tercer estudiante con nota igual a 5.
        Si dicha nota no aparece al menos 3 veces, el método debe retornar el valor –1
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    Retorno: int
        La posición en la lista del tercer estudiante con nota igual a 5.
        Si no hay al menos 3 estudiantes con nota igual a 5, retorna -1.
    """
    return 0


def aplicar_curva(estudiantes: list) -> None:
    """Aplica una curva a las notas de todos los estudiantes, aumentando cada una en un 5%.
    Ninguna nota aumentada puede sobrepasar el valor de 5.0.
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    """

def lista_aprobados(estudiantes: list) -> list:
    """Retorna una lista de valores booleanos en la que cada posición tiene el valor True si y solamente
       si el estudiante correspondiente (es decir, en esa misma posición) en la lista de estudiantes 
       dada por parámetro tiene una nota mayor o igual a 3.0
    Parámetros:
        estudiantes (list): La lista de estudiantes. Cada estudiante es un diccionario con "codigo", "nombre" y "nota".
    Retorno: list
        Lista de booleanos en el que cada posición tiene el valor True si el estudiante correspondiente
        en la lista aprobó el curso, False de lo contrario.
    """
    return []