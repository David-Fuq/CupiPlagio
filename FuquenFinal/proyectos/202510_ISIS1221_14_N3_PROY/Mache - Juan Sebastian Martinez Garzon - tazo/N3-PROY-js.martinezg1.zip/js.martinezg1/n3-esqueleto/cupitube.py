#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    youtubers = {}
    archivo = open(archivo, "r", encoding="utf-8")
    archivo.readline().strip()
    linea = archivo.readline().strip()
    while (len(linea) > 0):
        datos = linea.strip("\n").split(",")
        youtuber = {}
        youtuber["rank"] = int(datos[0])
        youtuber["cupituber"] = datos[1]
        youtuber["subscribers"] = int(datos[2])
        youtuber["video_views"] = int(datos[3])
        youtuber["video_count"] = int(datos[4])
        youtuber["category"] = datos[5]
        youtuber["started"] = datos[6]
        youtuber["monetization_type"] = datos[8]
        youtuber["description"] = datos[9]
        if not (datos[7] in youtubers):
            youtubers[datos[7]] = [youtuber]
        else:
            youtubers[datos[7]].append(youtuber)
        linea = archivo.readline()
    archivo.close()
    return youtubers


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resp = []
    for pais in cupitube:
        i = 0
        while i < len(cupitube[pais]):
            if cupitube[pais][i]["category"] == categoria_buscada and cupitube[pais][i]["subscribers"] >= suscriptores_min and cupitube[pais][i]["subscribers"] <= suscriptores_max:
                resp.append(cupitube[pais][i])
            i += 1
    return resp


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resp = []
    if cupitube.get(pais_buscado, -1) == -1:
        resp = []
    else:
        i = 0
        while i < len(cupitube[pais_buscado]):
            if cupitube[pais_buscado][i]["category"] == categoria_buscada and cupitube[pais_buscado][i]["monetization_type"] == monetizacion_buscada:
                resp.append(cupitube[pais_buscado][i])
            i += 1
    return resp


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    resp = {}
    for pais in cupitube:
        i = 0
        while i < len(cupitube[pais]):
            if resp == {}:
                resp = cupitube[pais][i]
            elif cupitube[pais][i]["started"] < resp["started"]:
                resp = cupitube[pais][i]
            i += 1
    return resp
       

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    resp = 0
    for pais in cupitube:
        i = 0
        while i < len (cupitube[pais]):
            if cupitube[pais][i]["category"] == categoria_buscada:
                resp += cupitube[pais][i]["video_views"]
            i += 1
    return resp


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categorias = {}
    for pais in cupitube:
        i = 0
        while i < len(cupitube[pais]):
            if cupitube[pais][i]["category"] not in categorias:
                categorias[cupitube[pais][i]["category"]] = cupitube[pais][i]["video_views"]
            else:
                categorias[cupitube[pais][i]["category"]] += cupitube[pais][i]["video_views"]
            i += 1
    mejor_n = -1
    mejor_c = ""
    for categoria in categorias:
        if categorias[categoria] > mejor_n:
            mejor_n = categorias[categoria]
            mejor_c = categoria
    resp = {"categoria": mejor_c, "visitas": mejor_n}
    return resp


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    caracteres = "abcdefghijklmnñopqrstuvwxyz0123456789"
    for pais in cupitube:
        i = 0
        while i < len(cupitube[pais]):
            nombre = ""
            j = 0
            while j < len(cupitube[pais][i]["cupituber"]):
                if cupitube[pais][i]["cupituber"].lower()[j] in caracteres:
                    nombre += cupitube[pais][i]["cupituber"].lower()[j]
                j += 1
            if len(nombre) > 15:
                nombre = nombre[:15]
            y = cupitube[pais][i]["started"][2:4]
            z = cupitube[pais][i]["started"][5:7]
            correo = nombre + "." + y + z + "@cupitube.com"
            cupitube[pais][i]["correo"] = correo
            i += 1


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    resp = {}
    datos = cargar_cupitube("cupitube.csv")
    categoria_buscada = obtener_categoria_con_mas_visitas(datos)["categoria"]
    for pais in cupitube:
        i = 0
        while i < len(cupitube[pais]) and resp == {}:
            if cupitube[pais][i] in buscar_por_categoria_y_rango_suscriptores(datos, suscriptores_min, suscriptores_max, categoria_buscada) and cupitube[pais][i]["video_count"] >= videos_minimos and cupitube[pais][i]["started"] >= fecha_minima and cupitube[pais][i]["started"] <= fecha_maxima and palabra_clave.lower() in cupitube[pais][i]["description"].lower():
                resp = cupitube[pais][i]
            i += 1
    return resp


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resp = {}
    for pais in cupitube:
        i = 0
        while i < len(cupitube[pais]):
            if cupitube[pais][i]["category"] not in resp:
                resp[cupitube[pais][i]["category"]] = [pais]
            else:
                if pais not in resp[cupitube[pais][i]["category"]]:
                    resp[cupitube[pais][i]["category"]].append(pais)
            i += 1
    return resp
