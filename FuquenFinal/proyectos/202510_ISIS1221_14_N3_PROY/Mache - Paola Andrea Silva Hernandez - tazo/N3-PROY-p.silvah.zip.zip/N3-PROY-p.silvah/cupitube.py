#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitubers={}
    archivos=open(archivo,"r")
    titulos=archivos.readline()
    print(titulos)
    linea=archivos.readline()
    while (len(linea)>0):
        datos=linea.strip("\n").split(",")
        cupituber={}
        cupituber["rank"] = int(datos[0])
        cupituber["cupituber"] = datos[1]
        cupituber["subscribers"] = int(datos[2])
        cupituber["video_views"]=int(datos[3])
        cupituber["video_count"] = int(datos[4])
        cupituber["category"] = datos[5]
        cupituber["started"] = datos[6]
        cupituber["monetization_type"] = datos[8]
        cupituber["description"] = datos[9]
        if not (datos[7] in cupitubers):
            cupitubers[datos[7]]=[cupituber]
        else:
            cupitubers[datos[7]].append(cupituber)
        
        linea=archivos.readline()
    archivos.close()
    return cupitubers 

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    cumple=[]
    for pais in cupitube.keys():
        for cupi in cupitube[pais]:
            if cupi["subscribers"] >= suscriptores_min and cupi["subscribers"]<= suscriptores_max and cupi["category"]==categoria_buscada:
                cumple.append(cupi)
    return cumple
 

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cumple=[]
    for pais in cupitube.keys():
        if pais == pais_buscado:
           for cupi in cupitube[pais]:
               if cupi["category"] == categoria_buscada and cupi["monetization_type"]==monetizacion_buscada:
                cumple.append(cupi)
    return cumple
   

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    antiguo={}
    viejo=None
    for pais in cupitube.keys():
        for cupi in cupitube[pais]:
            if viejo is None or cupi["started"] <= viejo:
                viejo=cupi["started"]
                antiguo=cupi
    return antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    visitas=0
    for pais in cupitube.keys():
        for cupi in cupitube[pais]:
            if "category" in cupi and cupi["category"]==categoria_buscada:
                visitas+=cupi["video_views"]
    return visitas



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mas_visitas={}
    mas=0
    for pais in cupitube.keys():
       for cupi in cupitube[pais]:
           categoria=cupi["category"]
           visitas=obtener_visitas_por_categoria(cupitube, categoria)
           if visitas>mas:
               mas = visitas
               mas_visitas = {"categoria": categoria, "visitas": visitas}
    return mas_visitas
               
   

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube.keys():
        for cupi in cupitube[pais]:
            nombre=cupi["cupituber"].lower()
            nombre2=""
            for caracter in nombre:
                if caracter.isalnum():
                    nombre2+=caracter
            if len(nombre2)>15:
                nombre2=nombre2[0:15]
            fecha=cupi["started"]
            num=fecha.split("-")
            año=num[0][-2:]
            mes=num[1]
            correo=nombre2+"."+año+mes+"@cupitube.com"
            cupi["correo"]=correo
  


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    mas_visitas = obtener_categoria_con_mas_visitas(cupitube)
    for pais in cupitube.keys():
        for cupi in cupitube[pais]:
            if cupi["subscribers"]>=suscriptores_min and cupi["subscribers"]<=suscriptores_max and cupi["started"]>=fecha_minima and cupi["started"]<=fecha_maxima and cupi["video_count"]>=videos_minimos and palabra_clave.lower() in cupi["description"].lower() and cupi["category"] == mas_visitas["categoria"]:
                recomendado=cupi
                return recomendado
    return {}
    
   


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    paises_en={}
    for pais in cupitube.keys():
       categoria=cupitube[pais]["category"]
       if categoria not in paises_en:
          paises_en[categoria] =[]
       if pais not in paises_en[categoria]:
                paises_en[categoria].append(pais)
    return paises_en
                
     