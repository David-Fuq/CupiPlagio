#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    nombres = {}
    archivo= open(archivo, "r", encoding="utf-8")
    titulos = archivo.readline()  # Leer la línea de encabezados y eliminar saltos de línea
    linea = archivo.readline()    # Leer la primera línea de datos
    while len(linea) > 0:
        datos = linea.strip("\n").split(",")
        dic = {"rank": int(datos[1]),"cupituber": datos[2],"subscribers": int(datos[3]),"video_views": int(datos[4]),"video_count": int(datos[5]),"category": datos[6],"started": datos[7],"monetization_type": datos[8],"description": datos[9]}
        pais = datos[0]
        if pais in nombres:
            nombres[pais].append(dic)
        else:
            nombres[pais] = [dic]
        linea = archivo.readline().strip()  # Leer la siguiente línea
    archivo.close()
    return nombres
    #TODO 1: Implemente la función tal y como se describe en la documentación.
    pass


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resp = []
    for pais in cupitube:
     for nombre in cupitube[pais]:
         if nombre["category"] == categoria_buscada and suscriptores_min <= nombre["subscribers"] <= suscriptores_max:
             resp.append(nombre)
    return resp
    #TODO 2: Implemente la función tal y como se describe en la documentación.
    pass


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resp=[]
    if pais_buscado in cupitube:
        for nombre in cupitube[pais_buscado]:
            if (nombre["category"] == categoria_buscada and nombre["monetization_type"] == monetizacion_buscada):
                resp.append(nombre)
    return resp
    #TODO 3: Implemente la función tal y como se describe en la documentación.
    pass


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    resp= {}
    for pais in cupitube:
        for nombre in cupitube[pais]:
            if (resp== {}) or (nombre["started"] < resp["started"]):
                resp = nombre
    return resp
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    pass
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    resp = 0
    for pais in cupitube:
        for nombre in cupitube[pais]:
            if nombre["category"] == categoria_buscada:
                resp += nombre["video_views"]
    return resp
    #TODO 5: Implemente la función tal y como se describe en la documentación.
    pass


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_categoria = {}
    for pais in cupitube:
        for nombre in cupitube[pais]:
            categoria = nombre["category"]
            visitas = nombre["video_views"]
            if categoria in visitas_categoria:
                visitas_categoria[categoria] += visitas
            else:
                visitas_categoria[categoria] = visitas
    categoria_max = ""
    visitas_max = -1
    for categoria, visitas in visitas_categoria.items():
        if visitas > visitas_max:
            categoria_max = categoria
            visitas_max = visitas
    return {"categoria": categoria_max, "visitas": visitas_max}
    #TODO 6: Implemente la función tal y como se describe en la documentación.
    pass


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for nombre in cupitube[pais]:
            nom = nombre["cupituber"]
            nombre2= ""
            for c in nom:
                if c.isalnum():
                    nombre2+= c
                    nom = nombre2[:15].lower()
            anio = nombre["started"][:4][-2:]
            mes = nombre["started"][5:7]
            correo = nom + "." + anio + mes + "@cupitube.com"
            nombre["correo"] = correo
       #TODO 7: Implemente la función tal y como se describe en la documentación.
    pass


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    visitas_categoria = {}
    for pais in cupitube:
        for c in cupitube[pais]:
            categoria = c["category"]
            visitas_categoria[categoria] = visitas_categoria.get(categoria, 0) + c["video_views"]
    categoria_max = ""
    visitas_max = -1
    for categoria in visitas_categoria:
        if visitas_categoria[categoria] > visitas_max:
            visitas_max = visitas_categoria[categoria]
            categoria_max = categoria
    palabra_clave = palabra_clave.lower()
    for pais in cupitube:
        for c in cupitube[pais]:
            if (c["category"] == categoria_max and suscriptores_min <= c["subscribers"] <= suscriptores_max and c["video_count"] >= videos_minimos and fecha_minima <= c["started"] <= fecha_maxima and palabra_clave in c["description"].lower()):
                return c
    return {}
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    pass


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resp= {}
    for pais in cupitube:
        for nombre in cupitube[pais]:
            categoria = nombre["category"]
            if categoria not in resp:
                resp[categoria] = []
            if pais not in resp[categoria]:
                resp[categoria].append(pais)
    return resp
    #TODO 9: Implemente la función tal y como se describe en la documentación.
    pass
