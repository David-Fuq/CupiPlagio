#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube (Módulo Lógica)
"""



# Función 1: 
    
def cargar_cupitube(archivo: str) -> dict:
    
    cupitube = {}  # ESTRUCUTRA GLOBAL
    
    archivo = open(archivo, "r" , encoding = "utf-8")
    titulos = archivo.readline().strip()
    print(titulos)
    linea = archivo.readline().strip()
    
    while (len(linea) > 0):
        
        datos = linea.strip("\n").split(",")
        
        country = {}
        country["rank"] = int(datos[0])
        country["cupituber"] = str(datos[1])       
        country["subscribers"] = int(datos[2])        
        country["video_views"] = int(datos[3])        
        country["video_count"] = int(datos[4])       
        country["category"] = str(datos[5])       
        country["started"] = str(datos[6])
        country["country"] = str(datos[7])  # LLAVE EN LA ESTRUCTURA GLOBAL
        country["monetization_type"] = str(datos[8])
        country["description"] = str(datos[9])
        
        if not(datos[7] in cupitube):
            cupitube[datos[7]] = [country]
        else:
            cupitube[datos[7]].append(country)
         
        linea = archivo.readline()
    
    archivo.close()
    
    return cupitube    






# Función 2: CHECK

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    respuesta = []
    
    
    for country in cupitube: 
                
        for cupituber in cupitube[country]: 
            
            if cupituber['category'] == categoria_buscada and cupituber['subscribers'] >= suscriptores_min and cupituber['subscribers'] <= suscriptores_max: 
                respuesta.append(cupituber)
    
    return respuesta
    
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """






# Función 3: CHECK 
    
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    respuesta = []
    
    
    if pais_buscado in cupitube: 
        
        for cupituber in cupitube[pais_buscado]: 
                    
            if cupituber['category'] == categoria_buscada and cupituber['monetization_type'] == monetizacion_buscada:
                respuesta.append(cupituber)
                        
    
    return respuesta
    
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """






# Función 4: CHECK
    
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    cupituber_mas_antiguo = None
    fecha_mas_antigua = None
    
    
    for country in cupitube: 
        
        for cupituber in cupitube[country]: 
            
            if fecha_mas_antigua == None: 
                fecha_mas_antigua = cupituber['started']
                cupituber_mas_antiguo = cupituber
            
            elif cupituber['started'] < fecha_mas_antigua: 
                fecha_mas_antigua = cupituber['started']
                cupituber_mas_antiguo = cupituber
                
                
    return cupituber_mas_antiguo
    
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """

            




# Función 5: CHECK
    
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    contador = 0 
    
    
    for country in cupitube: 
        
        for cupituber in cupitube[country]: 
            
            if cupituber['category'] == categoria_buscada: 
                contador += cupituber['video_views']
                
                
    return contador 
     
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """






# Función 6:
    
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    categoria_con_mas_visitas = None

    max_views = 0
    
    categorias = []
    
    
    for country in cupitube: 
        
        for cupituber in cupitube[country]: 
            
            categoria_buscada = cupituber['category']
            
            if not(categoria_buscada in categorias):   
            
                categorias.append(categoria_buscada)
            
                visitas_categoria_buscada = obtener_visitas_por_categoria(cupitube, categoria_buscada)
                
                if visitas_categoria_buscada > max_views:  
                    max_views = visitas_categoria_buscada
                    categoria_con_mas_visitas = {'categoria' : cupituber['category'], 'visitas' : visitas_categoria_buscada}
                

    return categoria_con_mas_visitas
            
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """






# Funcion 7:
    
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    
    for country in cupitube: 
        
        for cupituber in cupitube[country]: 
            
            
            # NOMBRE
            
            nombre = cupituber['cupituber'].lower()
            nombre = nombre.replace(' ', '')
   
            
            lista_isalnum = []
            i = 0 
            while i < len(nombre) and len(lista_isalnum) < 15: 
                
                caracter = nombre[i]
                
                if caracter.isalnum():
                    lista_isalnum.append(caracter)
                
                i += 1
            
            nombre = ''.join(lista_isalnum)
                

            # NUMEROS
            
            numeros = str(cupituber['started'][2])+str(cupituber['started'][3]) + str(cupituber['started'][5])+str(cupituber['started'][6])
             
                               
            # CORREO (asignacion en el dict del cupituber)
            
            cupituber['correo'] = nombre + '.' + numeros + '@cupitube.com' 
    
    
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """



 


# Función 8:
    
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    respuesta = {}
    
    
    dict_categoria_buscada = obtener_categoria_con_mas_visitas(cupitube)
    categoria_buscada = dict_categoria_buscada['categoria']
    
    lista_cupitubers = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria_buscada)
    
    
    i = 0 
    encontro = False
    
    while i < len(lista_cupitubers) and not(encontro): 
    
            if (lista_cupitubers[i]['video_count'] >= videos_minimos) and (fecha_maxima >= lista_cupitubers[i]['started']) and (lista_cupitubers[i]['started'] >= fecha_minima) and (palabra_clave.lower() in lista_cupitubers[i]['description'].lower()):            
                respuesta = lista_cupitubers[i]
                encontro = not(encontro)
            
            i += 1
            
            
    return respuesta
    
    
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales. (f.aux)
       - Tiene un número de suscriptores dentro del rango especificado. (f.aux)
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """






# Función 9:
    
def paises_por_categoria(cupitube: dict) -> dict:
    
    respuesta = {}
    
    for country in cupitube: 
        
        for cupituber in cupitube[country]: 
            
            categoria = cupituber['category']
            
            if not (categoria in respuesta):                
                respuesta[categoria] = [country]
    
            elif (categoria in respuesta) and not(country in respuesta[categoria]):                 
                respuesta[categoria].append(country)
             
                
    return respuesta                 
    
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
