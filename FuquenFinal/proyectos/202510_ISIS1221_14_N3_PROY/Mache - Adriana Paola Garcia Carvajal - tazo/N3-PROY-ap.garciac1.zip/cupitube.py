#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitubers={}
    archivo= open(archivo, "r", encoding="utf-8")
    archivo.readline().strip()
    linea=archivo.readline().strip()
    while (len(linea)>0):
        datos= linea.strip("\n").split(",")
        pais={}
        pais["rank"] = int(datos[0]) 
        pais["cupituber"] = datos[1] 
        pais["subscribers"] = int(datos[2]) 
        pais["video_views"] = int(datos[3]) 
        pais["video_count"] = int(datos[4])
        pais["category"] = datos[5]
        pais["started"] = datos[6] 
        pais["monetization_type"] = datos[8] 
        pais["description"] = datos[9] 
        pais_origen = datos[7] 
        if pais_origen in cupitubers:
           cupitubers[pais_origen].append(pais) 
        else:
           cupitubers[pais_origen] = [pais] 
           
        linea=archivo.readline().strip()
    archivo.close()
    return cupitubers 
   
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resp=[]
    for pais in cupitube.keys():
        for cupituber in cupitube[pais]:
            if (cupituber["subscribers"] in range(suscriptores_min,suscriptores_max+1)) and cupituber["category"]==categoria_buscada:
                resp.append(cupituber)
    return resp
  
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resp= []
    for cupituber in cupitube[pais_buscado]:
        if cupituber["category"]==categoria_buscada and cupituber["monetization_type"]== monetizacion_buscada:
            resp.append(cupituber)
    return resp

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    fecha_antiguo="2100-12-31"
    resp={}
    for pais in cupitube.keys():
        for cupituber in cupitube[pais]:
            if cupituber["started"] < fecha_antiguo:
                fecha_antiguo = cupituber["started"]
                resp = cupituber
    return resp

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    resp=0
    for pais in cupitube.keys():
        for cupituber in cupitube[pais]:
            if categoria_buscada==cupituber["category"]:
                resp+=cupituber["video_views"]
    return resp

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mas_vistas=0
    resp={}
    for pais in cupitube.keys():
        for cupituber in cupitube[pais]:
            categoria=cupituber["category"]
            visitas_categoria=obtener_visitas_por_categoria(cupitube, categoria)
            if visitas_categoria>mas_vistas:
                    mas_vistas=visitas_categoria 
                    resp["categoria"]=categoria
                    resp["visitas"]=visitas_categoria
    return resp
                    
# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    correo=""
    for pais in cupitube.keys():
        for cupituber in cupitube[pais]:
            nom=""
            for l in cupituber["cupituber"]:
                if l.isalnum():
                    nom+=l.lower()
            if len(nom)>15:
                nom=nom[0:14]
            anio=cupituber["started"][2:4]
            mes=cupituber["started"][5:7]
            correo= nom + "." + anio + mes + "@cupitube.com"
            cupituber["correo"]=correo

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    resp={}
    llaves=list(cupitube.keys())
    i=0
    x=obtener_categoria_con_mas_visitas(cupitube)
    categoria=x["categoria"]
    while i<len(llaves) and resp=={}:
        c=cupitube[llaves[i]]
        j=0
        while j<len(c) and resp=={}:
            cupituber=c[j]
            if (cupituber["category"]==categoria) and (suscriptores_min <= cupituber["subscribers"] <= suscriptores_max) and (cupituber["video_count"]>=videos_minimos) and (fecha_minima <= cupituber["started"] <= fecha_maxima) and (palabra_clave.lower() in cupituber["description"].lower()):
                resp=cupituber
            j+=1
        i+=1
    return resp
            
# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resp={}
    for pais in cupitube.keys():
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            if categoria not in resp:
                resp[categoria] = []
            if pais not in resp[categoria]:
                resp[categoria].append(pais)
    return resp
