#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    f = open(archivo, "r", encoding="utf-8")
    
    
    linea = f.readline().strip()
    
    cupitubers_por_pais = {}

    
    linea = f.readline()
    
    while linea:
        datos = linea.strip().split(",")

        rank = int(datos[0])
        cupituber = datos[1].strip()
        subscribers = int(datos[2])
        video_views = int(datos[3])
        video_count = int(datos[4])
        category = datos[5].strip()
        started = datos[6].strip()
        country = datos[7].strip()
        monetization_type = datos[8].strip()
        description = datos[9].strip()
        
        info = {
            "rank": rank,
            "cupituber": cupituber,
            "subscribers": subscribers,
            "video_views": video_views,
            "video_count": video_count,
            "category": category,
            "started": started,
            "monetization_type": monetization_type,
            "description": description
        }
        
        if country not in cupitubers_por_pais:
            cupitubers_por_pais[country] = []

        cupitubers_por_pais[country].append(info)

        
        linea = f.readline()
    
    f.close()
    return cupitubers_por_pais
   
    
        

ruta = "C:/Users/usuario/Downloads/cupitube.csv"
cupitube = cargar_cupitube(ruta)
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    resultado = []

    for pais in cupitube:
        for creador in cupitube[pais]:
            suscriptores = creador["subscribers"]
            categoria = creador["category"]

            if categoria == categoria_buscada and suscriptores_min <= suscriptores <= suscriptores_max:
                resultado.append(creador)

    return resultado

#print( buscar_por_categoria_y_rango_suscriptores(cupitube, 1000000, 111000000,  "Gaming"))

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
   
    resultado = []

    # Verificar si el país existe en el diccionario
    if pais_buscado in cupitube:
        for creador in cupitube[pais_buscado]:
            if (creador["category"] == categoria_buscada and creador["monetization_type"] == monetizacion_buscada):
                resultado.append(creador)

    return resultado

#print(buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, "UK" , "Gaming", "Crowdfunding"))
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
   
    mas_antiguo = None
    fecha_mas_antigua = "9999-12-31"  

    for pais in cupitube:
        for creador in cupitube[pais]:
            fecha_inicio = creador["started"]
            if fecha_inicio < fecha_mas_antigua:
                fecha_mas_antigua = fecha_inicio
                mas_antiguo = creador

    return mas_antiguo
    
#print(buscar_cupituber_mas_antiguo(cupitube))            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total_visitas = 0

    for pais in cupitube:
           for creador in cupitube[pais]:
               if creador["category"] == categoria_buscada:
                   total_visitas += creador["video_views"]

    return total_visitas
   
#print(obtener_visitas_por_categoria(cupitube, "Music"))

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    visitas_por_categoria = {}

    for pais in cupitube:
        for creador in cupitube[pais]:
            categoria = creador["category"]
            vistas = creador["video_views"]
            
            if categoria in visitas_por_categoria:
                visitas_por_categoria[categoria] += vistas
            else:
                visitas_por_categoria[categoria] = vistas

    
    categoria_max = None
    visitas_max = -1

    for categoria, total_visitas in visitas_por_categoria.items():
        if total_visitas > visitas_max:
            categoria_max = categoria
            visitas_max = total_visitas

    return {
        "categoria": categoria_max,
        "visitas": visitas_max
    }

#print(obtener_categoria_con_mas_visitas(cupitube))


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
       for creador in cupitube[pais]:
           nombre = creador["cupituber"]

          
           nombre_limpio = ''.join(c for c in nombre if c.isalnum())

           
           nombre_limpio = nombre_limpio[:15]

           
           fecha = creador["started"] 
           año = fecha[2:4] 
           mes = fecha[5:7]  

          
           correo = f"{nombre_limpio.lower()}.{año}{mes}@cupitube.com"

           
           creador["correo"] = correo
    
    
        


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    categoria_max_visitas = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    palabra_clave = palabra_clave.lower()
    recomendado = {}

    encontrado = False

    for pais in cupitube:
        if not encontrado:
            for creador in cupitube[pais]:
                if (
                    creador["category"] == categoria_max_visitas and
                    suscriptores_min <= creador["subscribers"] <= suscriptores_max and
                    creador["video_count"] >= videos_minimos and
                    fecha_minima <= creador["started"] <= fecha_maxima and
                    palabra_clave in creador["description"].lower()
                ):
                    recomendado = creador
                    encontrado = True

    return recomendado


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    categorias_por_pais = {}

    for pais in cupitube:
        for creador in cupitube[pais]:
            categoria = creador["category"]

            if categoria not in categorias_por_pais:
                categorias_por_pais[categoria] = []

            if pais not in categorias_por_pais[categoria]:
                categorias_por_pais[categoria].append(pais)

    return categorias_por_pais
