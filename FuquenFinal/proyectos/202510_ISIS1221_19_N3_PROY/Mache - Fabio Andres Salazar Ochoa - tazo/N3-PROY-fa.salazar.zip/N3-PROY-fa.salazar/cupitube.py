ruta_archivo = "D:/tareas/IP/n3/cupitube.csv"

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    archivo = open(archivo, "r", encoding="utf-8")
    
    linea = archivo.readline()
    linea = archivo.readline().strip()
    
    cupitubers = {} # dict grande
    
    while linea != "":
        datos = linea.split(",")
        
        dictpequeño = {
            "rank": int(datos[0]),
            "cupituber" : datos[1].strip(),
            "subscribers": int(datos[2]),
            "video_views": int(datos[3]),
            "video_count": int(datos[4]),
            "category": datos[5].strip(),
            "started": datos[6].strip(),
            "monetization_type": datos[8].strip(),
            "description": datos[9].strip()
            }
        
        for llave in dictpequeño:
            valor = dictpequeño[llave]
            if type(valor) == str and llave != "description":
                nuevovalor = ""
                for caracter in valor:
                    if caracter.isalnum():
                        nuevovalor += caracter
                dictpequeño[llave] = nuevovalor
                
        llave = datos[7].strip() # pais
        
        if llave not in cupitubers:
            lista2 = []
        else:
            lista2 = cupitubers[llave]
            
        lista2.append(dictpequeño)
        cupitubers[llave] = lista2
        
        linea = archivo.readline().strip()
        
    archivo.close()
        
    return cupitubers
            
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    resultado = []
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            if cupituber["category"] == categoria_buscada:
                if suscriptores_min <= cupituber["subscribers"] <= suscriptores_max:
                    resultado.append(cupituber)
                    
    return resultado
            

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:

    resultado = []
    
    if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]
        for cupituber in lista_cupitubers:
            if cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
                resultado.append(cupituber)
    
    return resultado
   
  
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    resultado = {}
    menor = "9999-12-31"
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["started"] < menor:
                menor = cupituber["started"]
                resultado = cupituber
    
    return resultado
        
# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    visitas = 0
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada:
                visitas += cupituber["video_views"]
                
    return visitas
    
# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    mayor = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            if categoria not in mayor:
                mayor[categoria] = obtener_visitas_por_categoria(cupitube, categoria)
                
    maxi = ""
    visitas_maxi = -2
    
    for categoria in mayor:
        if mayor[categoria] > visitas_maxi:
            maxi = categoria
            visitas_maxi = mayor[categoria]
            
    retorno = {
        "categoria": maxi,
        "visitas": visitas_maxi
        }
    
    return retorno


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre = cupituber["cupituber"]
            fecha = cupituber["started"]
            
            nombre_nuevo = ""
            for caracter in nombre:
                if caracter.isalnum():
                    nombre_nuevo += caracter
            
            nombre_nuevo = nombre_nuevo[:16].lower()
            
            año = fecha[2:4]
            mes = fecha[5:7]
            
            correo = nombre_nuevo + "." + año + mes + "@cupitube.com"
            cupituber["correo"] = correo
            

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    recomendacion = {}
    categoriamas = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    palabra_clave = palabra_clave.lower()

    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
                if cupituber["category"] == categoriamas:
                    if suscriptores_min <= cupituber["subscribers"] <= suscriptores_max:
                        if cupituber["video_count"] >= videos_minimos:
                            if fecha_minima <= cupituber["started"] <= fecha_maxima:
                                descripcion = cupituber["description"].lower()
                                if palabra_clave in descripcion:
                                    recomendacion = cupituber
                                    return recomendacion

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    dictpaises = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            if categoria not in dictpaises:
                dictpaises[categoria] = []
            if pais not in dictpaises[categoria]:
                dictpaises[categoria].append(pais)
                
    return dictpaises


