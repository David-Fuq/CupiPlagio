#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 

archivo=  "C:/Users/jp12b/Downloads/n3-esqueleto (1)/cupitube.csv"

def cargar_cupitube(archivo: str) -> dict:
    
    archivoo= open(archivo,"r",encoding="utf-8")
    linea= archivoo.readline().strip()
    linea= archivoo.readline().strip()
    g= {}
    
    
    while linea != "":
        lista=linea.split(",")
        
        p= {}
        p["rank"]= lista[0]
        p["cupituber"]=lista[1]
        p["subscribers"]=int(lista[2])
        p["video_views"]=int(lista[3])
        p["video_count"]=lista[4]
        p["category"]=lista[5]
        p["started"]=lista[6]
        llave=lista[7]
        p["monetization_type"]=lista[8]
        p["description"]=lista[9]
        
        if llave not in g:
            lista2= []
        else:
            lista2=g[llave]
        
        lista2.append(p)
        
        g[llave]=lista2
        linea=archivoo.readline().strip()
    
    archivoo.close()
    
    return g

#print(cargar_cupitube(archivo))

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
        
   subs=0
    
   for country in cupitube:
       lista= cupitube[country]
       for valores in lista:
           if categoria_buscada== valores["category"] :
              if valores["subscribers"]>suscriptores_min and valores["subscribers"]<suscriptores_max :
                  subs= valores["subscribers"]
                  respuesta=valores
              
   return respuesta
   
cupitube= cargar_cupitube(archivo)
#print(buscar_por_categoria_y_rango_suscriptores(cupitube, 1000000, 11100000000000, "Gaming"))
        
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    for valores in cupitube[pais_buscado]:
        if categoria_buscada== valores["category"] and monetizacion_buscada== valores["monetization_type"]:
            respuesta= valores
       
    return respuesta

#print(buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, "UK", "Gaming", "Crowdfunding"))
    
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    cupi_mas_antiguo= "2025-04-29"
    
    for paises in cupitube:
        lista= cupitube[paises]
        for cupituber in lista:
            if cupituber["started"]<cupi_mas_antiguo:
                cupi_mas_antiguo= cupituber["started"]
                respuesta= cupituber
    return respuesta


print(buscar_cupituber_mas_antiguo(cupitube))

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
      
    cantidad= 0 
    
    for paises in cupitube:
        lista= cupitube[paises]
        for vistas in lista:
            if vistas["category"]== categoria_buscada:
                cantidad+= vistas["video_views"]
    return cantidad

#print(obtener_visitas_por_categoria(cupitube, "Gaming"))
    
# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    cat= {}
    

    for paises in cupitube:
        lista= cupitube[paises]
        for dic in lista:
            categoria= dic["category"]
            if categoria in cat:
                cat[categoria]+=dic["video_views"]
            else:
                cat[categoria]=dic["video_views"]
                
   
    mas_views= list(cat.values())[0]
    cat_final= list(cat.keys())[0]
    

    for categoria in cat:
        if mas_views<cat[categoria]:
            mas_views= cat[categoria]
            cat_final=categoria
    dic={"visitas":mas_views, "categoria":cat_final}
    
    return dic

#print(obtener_categoria_con_mas_visitas(cupitube))
    
# Funcion 7:
    

"no pude hacerla"

def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
   for paises in cupitube:
       lista=cupitube[paises]
       for d in lista:
           nom= d["cupituber"].lower()
           if nom.isalnum()== False:
               for c in nom:
                   if c.isalnum()==False:
                       nombre= nom.replace(c,"")
           
           if 15< len(nombre):
               nombre_limpio=nombre[:15]
          
           año=d["started"][2:4]
           mes=d["started"][5:7]
           
           correo= nombre_limpio+"."+año+mes+"@cupitube.com"
           cupitube["correo"]=correo
#print(crear_correo_para_cupitubers(cupitube))

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
     

 

 
    
 
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    pass


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    diccionario_categorias= {}
    
    for paises in cupitube:
        llaves= cupitube[paises]
        for valores in llaves:
            categorias= valores["category"]
            if categorias in paises:
                diccionario_categorias= {"categorias":paises}
    
    return diccionario_categorias

#print(paises_por_categoria(cupitube))
                
        
    
    #TODO 9: Implemente la función tal y como se describe en la documentación.
   