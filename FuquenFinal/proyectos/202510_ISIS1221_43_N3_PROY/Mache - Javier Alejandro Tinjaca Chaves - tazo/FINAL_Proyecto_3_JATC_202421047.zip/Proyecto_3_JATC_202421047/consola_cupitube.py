#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""



#Proyecto Nivel 3, IP
# #Módulo de Consola
# nombre: Javier Alejandro Tinjacá Chaves 
# código: 202421047










import cupitube as ct
#Importante estoy importando todas las funciones del otro modulo como ct.XXXXXXX


###### Funciones auxiliares (NO MODIFICAR):
    
# Función auxiliar que muestra la información de un CupiTuber
def mostrar_cupituber(cupituber: dict) -> None:
    """
    Muestra la información de un CupiTuber.
    
    Parámetros:
        cupituber (dict): Diccionario con la información del CupiTuber.
    """
    print("\n")
    print("#" * 50)
    
    print((
        "\nNombre: {}\n"
        "Ranking: {}\n"
        "Suscriptores: {}\n"
        "Visitas de videos: {}\n"
        "Cantidad de videos: {}\n"
        "Categoría: {}\n"
        "Año de inicio: {}\n"
        "Tipo de monetización: {}\n"
        "Descripción: {}\n"
    ).format(
        cupituber["cupituber"], cupituber["rank"], cupituber["subscribers"],
        cupituber["video_views"], cupituber["video_count"], cupituber["category"],
        cupituber["started"], cupituber["monetization_type"], cupituber["description"]
    ))
    
    print("#" * 50)

# Función auxiliar que muestra la información de múltiples CupiTubers
def mostrar_cupitubers(cupitubers: list) -> None:
    """
    Muestra la información de una lista de CupiTubers.
    
    Parámetros:
        cupitubers (list): Lista de diccionarios con la información de los CupiTubers.
    """
    print("\nCupiTubers encontrados:")
    print("-" * 50)
    
    for cupituber in cupitubers:
        mostrar_cupituber(cupituber)

    print("-" * 50)
    
# Función auxiliar que muestra los países de CupiTubers en una categoría específica.
def mostrar_paises(paises: list) -> None:
    """ 
    Muestra los países que tienen CupiTubers en una categoría específica.
    
    Parámetros:
        paises (list): Lista de nombres de países.
    """
    print("-" * 50)
    
    for pais in paises:
        print(pais)
    
    print("-" * 50)
###### Fin de las funciones auxiliares



# Funciones a implementar (solo aquellas con TODOs):

def ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube: dict) -> None:
    

    """
    Muestra los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores se encuentre dentro del rango especificado.
    Ya se provee la implementación completa de esta función y no se requiere ningún cambio.
               
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Se debe pedir al usuario la categoría, y el mínimo y el máximo del rango de suscriptores.    
    
    Hay 2 casos posibles:
        - Si no se encuentra ningún CupiTuber que cumpla con los criterios, el mensaje es:
            - "No se encontraron CupiTubers que cumplan con los criterios."
        
        - Caso contrario, debe usar la función auxiliar: mostrar_cupitubers() para mostrar a todos los CupiTubers que cumplan con los criterios.
    """
    
    categoria = input("Ingrese la categoría: ")
    minimo = int(input("Ingrese el mínimo de suscriptores: "))
    maximo = int(input("Ingrese el máximo de suscriptores: "))
    
    cupitubers = ct.buscar_por_categoria_y_rango_suscriptores(cupitube, minimo, maximo, categoria)
    
    if cupitubers != []:
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


#     oooooooooooooooooooooooooooooooooooooooooo
# Funciones de consola a realizar (las de arriba son auxiliares)




#TODO 10
def ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict) -> None:
    
    #Recordar el data type de los parametros que voy a pasar
    categoria_BUSCADA = input("Ingrese la categoría: ")
    pais_BUSCADO = input("Ingrese el pais de origen del Cupituber: ")
    monetiza_BUSCADA = input("Ingrese el tipo de monetizacion que le interesa: ")
    
    Lista_dicts_MATCH = ct.buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais_BUSCADO, categoria_BUSCADA, monetiza_BUSCADA)
    
    #Recordar que:
        
    """
    Returnea:  Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, 
    su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
    Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    
    
    #Hay 2 casos posibles:
    
    #- Si no se encuentra ningún CupiTuber que cumpla con los criterios, el mensaje es:
    
    if (Lista_dicts_MATCH == []):
        
        print("\n")
        print ("No se encontraron CupiTubers que cumplan con los criterios.")
        
    else:
        
        print("\n")
        print( f"Los CupiTubers de {pais_BUSCADO} que pertenecen a la categoría {categoria_BUSCADA} y tienen monetización {monetiza_BUSCADA} son:")
        mostrar_cupitubers(Lista_dicts_MATCH)
    
    
    
    
    
    
    
#TODO 11     
def ejecutar_buscar_cupituber_mas_antiguo(cupitube: dict) -> None:
    
    #Ojo: No hay datos que solicitar al usuario.
    #Debo hacer uso de: buscar_cupituber_mas_antiguo
        
        
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    Devolviendo el diccionario!!! de dicho youtuber
    
    """
    """
    Recordar que los dicionarios de los Cupiyoutubers son asi: 
        
        {"rank": (int),
         "cupituber": (str),
         "subscribers": (int),
         "video_views": (int),
         "video_count": (int),
         "category": (str),
         "started": (str -> YYYY-MM-DD),
         "monetization_type": (str),
         "description": (str)},
            
            
    """
    
    Dict_CUPI_mas_ANT = ct.buscar_cupituber_mas_antiguo(cupitube)
    
    Nombre_Cupi_Viejo = Dict_CUPI_mas_ANT["cupituber"]
    Fecha_inicio_Viejo_Cupi = Dict_CUPI_mas_ANT["started"]
    
    print("\n")
    print(f"El CupiTuber más antiguo es {Nombre_Cupi_Viejo} y empezó en {Fecha_inicio_Viejo_Cupi}.")
    

    
    



#TODO 12

def ejecutar_obtener_visitas_por_categoria(cupitube: dict) -> None:
    
    #Recordar que la funcion que voy a usar 
    #obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
     
    Cat_BUSC = input("Ingrese la categoria por la cual quiere encontrar un # acumulado de Views:    ")
    
    Visitas_ACUMULADAS_cat = ct.obtener_visitas_por_categoria(cupitube, Cat_BUSC)
    
    
    print("\n")
    print(f"El total de visitas para la categoría {Cat_BUSC} es: {Visitas_ACUMULADAS_cat}.")
    
    #Notaa: No retornea pero si printea
    

     

#TODO 13 
def ejecutar_obtener_categoria_con_mas_visitas(cupitube: dict) -> None:
    
    #Recordando que la funcion que voy a llamr es
    
    """
    # Función 6:
        
    def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
        
        
        
        Identifica la categoría con el mayor número de visitasacumuladas.
      
        Retorno:
            dict:  con las siguientes llaves:
                - "categoria": str
                - "visitas": int
            
        
    
    """
    
    #NOTAA: No hay datos que solicitar al usuario.
    
    DICT_CAT_MAYOR_visitasacumuladas = ct.obtener_categoria_con_mas_visitas(cupitube)
    
    Nombre_CAT_mayor = DICT_CAT_MAYOR_visitasacumuladas["categoria"]
    Num_Visitas_MAYOR = DICT_CAT_MAYOR_visitasacumuladas["visitas"]
    
    
    print("\n")
    print(f"La categoría con más visitas es {Nombre_CAT_mayor} con {Num_Visitas_MAYOR} visitas.")
    
    
    
    
    

# --------------------------------------------------------------------------
#AUXILIAR

def ejecutar_crear_correo_para_cupitubers(cupitube: dict) -> None:
    """ 
    Ejecuta la función de crear correos para CupiTubers.
    Ya se provee la implementación completa de esta función y no se requiere ningún cambio.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    A modo de ejemplo, se muestra el correo creado para el primer CupiTuber del país 'USA'.
    
    El mensaje tiene el siguiente formato:
        - "El correo para el primer Cupituber de 'USA' con nombre '[X]' es: [Y]."

        Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
        
        Donde:
            - [X] es el nombre del CupiTuber.
            - [Y] es el correo creado.
    """
    if "USA" in cupitube and cupitube["USA"] != [] and cupitube["USA"][0] is not None:
        ct.crear_correo_para_cupitubers(cupitube)
        cupituber = cupitube["USA"][0]
        print("El correo para el primer Cupituber de 'USA' con nombre '" + cupituber["cupituber"] + "' es: " + cupituber["correo"] + ".")
        


#-----------------------------------------------------------------------

#TODO 14

def ejecutar_recomendar_cupituber(cupitube: dict) -> None:
    
    
    #Recordar que la funcion que voy a llamar: def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
        
    #Donde el DICT que me devuelve se ve asi:
        
        """
        {"rank": (int),
         "cupituber": (str),
         "subscribers": (int),
         "video_views": (int),
         "video_count": (int),
         "category": (str),
         "started": (str -> YYYY-MM-DD),
         "monetization_type": (str),
         "description": (str)}
        
        """
        #Cosas que debo pedir
        
        #1) El límite inferior del rango de suscriptores
        #la funcion espera un INT
        #Recordar; Input siempre devuelve str
        Lim_INFERIOR_subs = int(input("Cual es el límite inferior (MIN) del rango de suscriptores que usted considera (INCLUSIVO):  "))
        #2) El límite superior del rango de suscriptores.
        #tmb debe ser INT
        Lim_SUUUPERIOR_subs = int(input("Ingrese el límite superior (MAX) del rango de suscriptores que usted considera (INCLUSIVO):  "))
        #3) El límite inferior (MIN) del rango de fechas. 
        #se espera un STR: de formato de ingreso: YYYY-MM-DD
        Fecha_MINIMA = input("Ingrese la fecha minima (MIN) de creacion del canal, en el formato -> YYYY-MM-DD:  ")
        #4) El límite superior del rango de fechas. El formato de ingreso debe ser: YYYY-MM-DD
        Fecha_MAXIMAA = input("Ingrese la fecha Maxima (MAX) de creacion del canal, en el formato -> YYYY-MM-DD:  ")
        #5) La cantidad mínima de videos requerida
        #Es decir un int
        Videos_Minimos= int(input("Por favor ingrese La cantidad # mínima de videos requerida:  "))
        
        #6) La palabra clave que se desea sea parte de la descripción
        #PERO OJO NO puede ser una cadena vacia
        PALABRA_clave = input("especifica una La palabra clave que se desea que sea parte de la descripción del Canal:  ")
        
        while PALABRA_clave == "":
            
            print("No ingresaste una palabra clave, esta es obligatoria...  ")
            PALABRA_clave = input("vuelva a ingresarla:  ")
            
        Dict_cupi_MATCH = ct.recomendar_cupituber(cupitube, Lim_INFERIOR_subs, Lim_SUUUPERIOR_subs, Fecha_MINIMA, Fecha_MAXIMAA, Videos_Minimos, PALABRA_clave)
        
        
        if (Dict_cupi_MATCH == {}):
            
            print("\n")
            print("No se encontró un CupiTuber que cumpla con los criterios.")
        
        else: 
            
            print("El Cupituber recomendado tiene la siguiente información:")
            print("\n")
            mostrar_cupituber(Dict_cupi_MATCH)
            
    
    
    
    
    
   


#Otras funciones auxiliares------------------------

def ejecutar_paises_por_categoria(cupitube: dict) -> None:
    """ 
    Ejecuta la función que obtiene el diccionario de los países por categoría.
    Ya se provee la implementación completa de esta función y no se requiere ningún cambio.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Se debe pedir al usuario una categoría y mostrar los países que tienen CupiTubers en esa categoría.
    
    Hay dos casos posibles:
        - Si no se encuentra la categoría, el mensaje es:
            - "La categoría ingresada no existe en los datos."
    
        - Caso contrario, el mensaje debe tener el siguiente formato:
            - "Los países con CupiTubers en la categoría [X] son:"
        
            Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
        
            Donde:
                - [X] es el nombre de la categoría ingresada por el usuario.
            
        - Luego, use la función auxiliar mostrar_paises() para mostrar la información de los países encontrados.
    """
    estructura = ct.paises_por_categoria(cupitube)
    
    categoria = input("Ingrese la categoría: ")
    
    if categoria != "" and categoria in estructura:
        paises = estructura[categoria]
        if paises != {} and paises is not None:
            print("\nLos países con CupiTubers en la categoría " + categoria + " son:")
            mostrar_paises(paises)
    else:
        print("La categoría ingresada no existe en los datos.")


###### Funciones del ménu (NO MODIFICAR):
def iniciar_aplicacion() -> None:
    """
    Función principal de la aplicación.
    """
    ejecutando = False
    archivo = input("Ingrese el nombre del archivo de datos o presione Enter si su archivo se llama cupitube.csv: ")
    
    if archivo == "":
        archivo = "cupitube.csv"
        
    estados = ct.cargar_cupitube(archivo)
    if estados != {} and estados is not None:
        ejecutando = True
        print("#" * 50)
        print("¡Bienvenido a la aplicación de CupiTube!")
        print("#" * 50)
    
        while ejecutando:
            ejecutando = mostrar_menu_aplicacion(estados)
            if ejecutando:
                input("Presione Enter para continuar...")
    else:
        print("\nError: No se ha podido cargar el archivo. \nRevise su implementación de la función: cargar_cupitube() en cupitube.py")
      
            
# Función para mostrar el menú de la aplicación:
def mostrar_menu_aplicacion(cupitube: dict) -> bool:
    """ 
    Muestra el menú de la aplicación y ejecuta la opción seleccionada por el usuario.
    """
    print("\nMenú de opciones:")
    print("1. Buscar CupiTubers por categoría y rango de suscriptores.")
    print("2. Buscar CupiTubers por país, categoría y monetización.")
    print("3. Buscar CupiTuber más antiguo.")
    print("4. Obtener visitas para una categoría.")
    print("5. Obtener categoría con más visitas.")
    print("6. Crear correo para CupiTubers.")
    print("7. Recomendar un CupiTuber.")
    print("8. Obtener países por categoría.")
    print("9. Salir.")

    opcion_elegida = input("Ingrese la opción que desea ejecutar: ").strip()

    continuar_ejecutando = True

    if opcion_elegida == "1":
        ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube)
    elif opcion_elegida == "2":
        ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube)
    elif opcion_elegida == "3":
        ejecutar_buscar_cupituber_mas_antiguo(cupitube)
    elif opcion_elegida == "4":
        ejecutar_obtener_visitas_por_categoria(cupitube)
    elif opcion_elegida == "5":
        ejecutar_obtener_categoria_con_mas_visitas(cupitube)
    elif opcion_elegida == "6":
        ejecutar_crear_correo_para_cupitubers(cupitube)
    elif opcion_elegida == "7":
        ejecutar_recomendar_cupituber(cupitube)
    elif opcion_elegida == "8":
        ejecutar_paises_por_categoria(cupitube)
    elif opcion_elegida == "9":
        print("\n¡Gracias por usar la aplicación de CupiTube!")
        continuar_ejecutando = False
    else:
        print("Opción inválida. Por favor inténtelo de nuevo.")

    return continuar_ejecutando
###### Fin de las funciones del menú


# Punto de entrada de la aplicación
if __name__ == "__main__":
    iniciar_aplicacion()
    
    
    
#***************************************************************************************

# Instrucciones de las funciones de Consola

# Task 10


""" 
Muestra los CupiTubers de un país que pertenezcan a una categoría específica y tengan una monetización en particular.

Parámetros:
    cupitube (dict): Diccionario con la información de los CupiTubers.

Se debe pedir al usuario el país, la categoría y el tipo de monetización.
Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"

Hay 2 casos posibles:
    - Si no se encuentra ningún CupiTuber que cumpla con los criterios, el mensaje es:
        - "No se encontraron CupiTubers que cumplan con los criterios."

    - De lo contrario, el mensaje tiene el siguiente formato:
        - "Los CupiTubers de [X] que pertenecen a la categoría [Y] y tienen monetización [Z] son:"

        Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:

        Donde:
            - [X] es el nombre del país ingresado por el usuario.
            - [Y] es la categoría ingresada por el usuario.
            - [Z] es el tipo de monetización ingresado por el usuario.
            
       - Luego, use la función auxiliar mostrar_cupitubers() para mostrar la información de los CupiTubers encontrados.
"""

#*************************

#Task 11


   
"""
    Muestra el CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    No hay datos que solicitar al usuario.
    
    El mensaje debe tener el siguiente formato:
        - "El CupiTuber más antiguo es [X] y empezó en [Y]."

        Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
        
        Donde:
            - [X] es el nombre del CupiTuber.
            - [Y] es la fecha en la que empezó a publicar videos (started) en formato YYYY-MM-DD.
"""    

#*******************************************************

#Task 12


""" 
Muestra el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.

Parámetros:
    cupitube (dict): Diccionario con la información de los CupiTubers.
    
Se debe pedir al usuario la categoría de CupiTubers.

El mensaje debe tener el siguiente formato:    
    - "El total de visitas para la categoría [X] es: [Y]."

    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X] es el nombre de la categoría ingresada por el usuario.
        - [Y] es el número total de visitas acumuladas para la categoría. Este número puede ser cero.
"""
#*******************************************************************

#Task 13

""" 
Muestra la categoría con el mayor número de visitas (video_views) acumuladas.

Parámetros:
    cupitube (dict): Diccionario con la información de los CupiTubers.
    
No hay datos que solicitar al usuario.
    
El mensaje debe tener el siguiente formato:
    - "La categoría con más visitas es [X] con [Y] visitas."

    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X] es el nombre de la categoría con el mayor número de visitas acumuladas.
        - [Y] es el número total de visitas acumuladas para la categoría con más visitas.
"""
#*************************************************
#TASK 14


""" 
Ejecuta la función de  que recomienda al primer CupiTuber que cumpla con todos los criterios de búsqueda especificados:
- Pertenece a la categoría con más visitas totales.
- Tiene un número de suscriptores dentro del rango especificado.
- Ha publicado al menos la cantidad mínima de videos indicada.
- Ha comenzado a publicar dentro del rango de fechas especificado.
- Contiene la palabra clave indicada como parte de la descripción (sin distinguir entre mayúsculas/minúsculas).
    
Parámetros:
    cupitube (dict): Diccionario de países con la información de los CupiTubers.
    
Se debe pedir al usuario la siguiente información:
    - El límite inferior del rango de suscriptores.
    - El límite superior del rango de suscriptores.
    - El límite inferior del rango de fechas. El formato de ingreso debe ser: YYYY-MM-DD
    - El límite superior del rango de fechas. El formato de ingreso debe ser: YYYY-MM-DD
    - La cantidad mínima de videos requerida.
    - La palabra clave que se desea sea parte de la descripción.
      - La palabra clave no puede ser una cadena vacía.
    
El mensaje debe tener el siguiente formato:

Hay dos casos posibles:
    - Si no se encuentra un CupiTuber que cumpla con los criterios o la palabra clave dada es una cadena vacía, el mensaje es:
        - "No se encontró un CupiTuber que cumpla con los criterios."

    - Caso contrario, proceda así:
        - Primero imprima el encabezado: "El Cupituber recomendado tiene la siguiente información:"
          - Luego, use la función auxiliar mostrar_cupituber() para mostrar la información del CupiTuber recomendado.
"""

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    