#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

#Proyecto Nivel 3, IP
# #Módulo de Lógica
# nombre: Javier Alejandro Tinjacá Chaves 
# código: 202421047


#Recordar la logica para INICIALIZAR/importar el archivo csv
#Recordar siempre Cerrar el csv

#el outer diccionario va a tener como formato
"""
 { 
  pais_1(str): [
      
      #Formato del inner dict 
      
               {"rank": (int),
                "cupituber": (str),
                "subscribers": (int),
                "video_views": (int),
                "video_count": (int),
                "category": (str),
                "started": (str -> YYYY-MM-DD),
                "monetization_type": (str),
                "description": (str)}, 
                
                 {.....},
                 
                 {....} 
                 
                 ], 
  
   pais_2(str): [ {....} , {....} , {....} ], 
  
   pais_3(str): [ {} , {} , {} ] 
  
  }
 
"""


#TODO 1
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    """ 
    Carga un archivo en formato CSV con la información de los CupiTubers y 
    devuelve un diccionario donde la llave es el país de origen, 
    y los valores son Listas de diccionarios, segun el pais de outer Key.
    """
    #primero debo abrir el archivo csv, en modo read "r" y con la especificacion de guia encoding="utf-8" 
    
    File_Ctubers = open(archivo, "r", encoding="utf-8")
    
    #por ahora vacio
    Outer_dict_Countries = {}
    
   
    
    #SKIP: debo saltarme la primera fila/row pues esa contiene titulos mas no Info
    #Uso strip() como se especifica en la guia 
    File_Ctubers.readline().strip()
    linea = File_Ctubers.readline().strip()
    
    while (len(linea) > 0):
        
        #Las columnas en el CSV estan separadas por COMAS(,)
        #Creo un LISTA que puedo accesar con los index!!
        #Ojo me crea una lista de STRINGS pues el csv es texto!! aun cuando algunas columnas contengan INTS
        Data = linea.split(",")
        #Asumo que ningun valor dentro de una columna tiene una coma que no corresponda a la separacion por columnas
        
        
        
        Country_outer_Key = Data[7]
        
        
        
        Inner_youtuber_DICT = {}
        
        Inner_youtuber_DICT["rank"] = int(Data[0])
        Inner_youtuber_DICT["cupituber"] = Data[1]
        Inner_youtuber_DICT["subscribers"] = int(Data[2])
        Inner_youtuber_DICT["video_views"] = int(Data[3])
        Inner_youtuber_DICT["video_count"] = int(Data[4])
        Inner_youtuber_DICT["category"] = Data[5]
        Inner_youtuber_DICT["started"] = Data[6]
        #Skipee un indice pues era el que almacena el pais (aqui No me interesa)
        Inner_youtuber_DICT["monetization_type"] = Data[8]
        Inner_youtuber_DICT["description"] = Data[9]
        
        #Solo si el pais (outer key) Aun No existe en el Outer diccionario, debo inicializarlo como una lista vacia
        
        if (Country_outer_Key not in Outer_dict_Countries):
            
            Outer_dict_Countries[Country_outer_Key] = []
         
        #De lo contrario (el pais ya existe como llave) solo debo añadir a la cola de la lista 
        
        Outer_dict_Countries[Country_outer_Key].append(Inner_youtuber_DICT)
        
        #-----------------------
        #OJOOO: .append(xx) Añade a la lista pero NO ME DEVUELVE NADA
        #No puede realizar un asignacion, debe realizarse de manera directa
        #------------------------
        
      
        #Asegurarme de pasar de linea
        
        linea = File_Ctubers.readline().strip()
    
    
    File_Ctubers.close()
    return Outer_dict_Countries
    
    
    
    
    
    

#TODO 2
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado (INCLUSIVO).
    Retornea una lista de los diccionarios de los youtubers filtrados (Independientemente del pais)
    
    """
    
    
    #Ojo no busco el max o el min, sino los Youtubers que estan en el rango (ambos extremos INCLUSIVOS)
    #Independientememnte del PAIS!! 
    #Traversear completo!! todos los Outer_keys, y todos los diccionarios internos , almacenados en una Lista como outer_value
    
    #aqui se van a almacenar los diccionarios de los Cupitubers que cumplen con las condicones
    List_dicts_Cupitubers = []
    
    
    for Outer_key, Outer_value_list in cupitube.items():
        #Ojo: Outer_value es una LISTA! que contiene diccionarios
        #Puedo acceder usando indice O implicitamente 
        #don't work harder work smarter
        
        for Dict_CupiTuber in Outer_value_list:
            #Acceso implicito al VALOR = DICIONARIO
            
            if (  (Dict_CupiTuber["category"] == categoria_buscada) and (  (Dict_CupiTuber["subscribers"] >= suscriptores_min)   and (Dict_CupiTuber["subscribers"] <= suscriptores_max) )   ):
                
                
                List_dicts_Cupitubers.append(Dict_CupiTuber)
                
                
    
    
    
    return List_dicts_Cupitubers

                

#TODO: 3
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    
    
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización especificos.
        
       Returnea:  Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, 
       su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
       Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    
    
    
    #No hay necesidad de iterar Todos los outer_keys, solo el contenido (Lista de diccionarios) del pais en especifico/INTERES (solo ese outer key)
    #Pues existe 1 sola llave por pais
    
    
    
    
    List_DICTS_cupis = []
    
    #Si el pais no esta dentro del "repertorio"/ outer_dicionario
    #devuelvo una lista vacia
    if (pais_buscado not in cupitube):
        
        #acabo la funcion antes, aun cuando la lista esta vacia
        #y antes de extraer la Inner lista, que de no existir el pais me genera un error
        return List_DICTS_cupis
    
    
    List_cupis_pais_INTERES = cupitube[pais_buscado]
    
    #implicito!! acceso directo a valores (en este caso DICCIONARIOS INTERNOS)
    for Dict_CUPI in List_cupis_pais_INTERES:
        
        if (Dict_CUPI["category"] == categoria_buscada) and (Dict_CUPI["monetization_type"] == monetizacion_buscada):
            
            
            List_DICTS_cupis.append(Dict_CUPI)
            
            
    return List_DICTS_cupis
      
            
            
        
    
    


#TODO: 4
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    Devolviendo el diccionario de dicho youtuber
    
    """
    
    
    
    #Seteo los contadores de quien va ganando 
    #Default values (valores abusrdos de forma tal que el primero en entrar sea asignado como mas ANTIGUO )
    
    Año_del_masANT = 2099
    Mes_del_masANT = 15
    Dia_del_masANT = 35
    
    #Default un dict VACIO
    DIIICT_del_masANTIGUO = {}
    
    
    
    
    #Debo traversear COMPLETO cada pais/outer key pues puede estar en cualquier lado 
    
    for Outer_key_Country, Outer_value_LIST in cupitube.items():
        
        #Donde Outer_value_LIST es la lista de diccionarios asociados a ESE PAIS
        
        #For loop Implicito para poder accesar directamente el DICT
        for DICT_CUPI in Outer_value_LIST:
            
            #Extraer la info de LLAVE interna  "started": (str -> YYYY-MM-DD),  
            #para poder realizar comparaciones
            
            FECHA_completa = (DICT_CUPI["started"]).split("-")
            #Ahora tengo una lista asi 
            # ["YYYY","MM","DD"]
            
            #ahora aislo las partes segun indice (0,1,2) y las convierto en int
            AÑO_cupi_ACTUAL = int(FECHA_completa[0])
            MES_cupi_ACTUAL = int(FECHA_completa[1])
            DIA_cupi_ACTUAL = int(FECHA_completa[2])
            
            
            #Ahora si comparo busco el MENOR (<)
            
            # si tiene un año mas antiguo No hay necesidad de entrar a comparar otros campos
            if (AÑO_cupi_ACTUAL < Año_del_masANT):
                
                #Update de las que llevan el record
                Año_del_masANT = AÑO_cupi_ACTUAL
                Mes_del_masANT = MES_cupi_ACTUAL
                Dia_del_masANT = DIA_cupi_ACTUAL
                
                DIIICT_del_masANTIGUO = DICT_CUPI
            
            #If años iguales BUT gana en mes 
            elif ( (AÑO_cupi_ACTUAL == Año_del_masANT) and (MES_cupi_ACTUAL < Mes_del_masANT)  ):
                
                Año_del_masANT = AÑO_cupi_ACTUAL
                Mes_del_masANT = MES_cupi_ACTUAL
                Dia_del_masANT = DIA_cupi_ACTUAL
                
                DIIICT_del_masANTIGUO = DICT_CUPI
            
            
            #If AÑOS iguales AND MES iguales BUT dia le gana
            
            elif ( (AÑO_cupi_ACTUAL == Año_del_masANT) and (MES_cupi_ACTUAL == Mes_del_masANT) and (DIA_cupi_ACTUAL < Dia_del_masANT) ):
                
                Año_del_masANT = AÑO_cupi_ACTUAL
                Mes_del_masANT = MES_cupi_ACTUAL
                Dia_del_masANT = DIA_cupi_ACTUAL
                
                DIIICT_del_masANTIGUO = DICT_CUPI
                
                
            
        
        
    
    
    
    #RECORDAR: EL RETURN DEBE IR FUERA DE LOS LOOPS
    
    return DIIICT_del_masANTIGUO
                
                
     
            
     
        
#TODO: 5
# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    """
    Obtiene y devuelve el número (int) total de visitas (video_views) acumuladas 
    para una categoría dada de CupiTubers.
    
    """
   
    
    
    
    #si nunguno le pega a la categoria (osea No existe), se retornea el valor default
    Counter_VIEWS_de_Categoria = 0
    
    
    #Realizar un traverseo COMPLETO, pues pueden haber youtubers de cualquier pais que esten en la categoria
    
    for Country_OUTER_key, List_OUTER_Value in cupitube.items():
        
        #Iteracion implicita
        
        for Cupi_dict in List_OUTER_Value:
            #acceso directo al dict
            
            if (Cupi_dict["category"] == categoria_buscada):
                
                Counter_VIEWS_de_Categoria += Cupi_dict["video_views"]
                
                
    return Counter_VIEWS_de_Categoria



#TODO 6:

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    
    """
    Identifica la categoría con el mayor número de visitasacumuladas.
  
    Retorno:
        dict:  con las siguientes llaves:
            - "categoria": str
            - "visitas": int
        
    """
    
    
    
    
    
    #Tener una forma de almacenar todas las categorias y tener accountability de la cantidad de Views para pode hacer una seleccion/SORTEO/filtro mas adelate
    """ que tenga la forma { Categoria(str): views (int),
                             Categoria(str): views (int),
                             Categoria(str): views (int),
                            }
    
    """
    
    Dict_all_Categorias_Views = {}
    
    for Outer_key_pais, Outer_list_VALUE in cupitube.items():
        
        for DICT_CUPI in Outer_list_VALUE:
            
            Category_Cupi_ACTUAL = DICT_CUPI["category"]
            Views_Cupi_ACTUAL = DICT_CUPI["video_views"]
            
            
            #Si aun no existe la categoria la creo e inicializo 
            if (Category_Cupi_ACTUAL not in Dict_all_Categorias_Views):
                
                Dict_all_Categorias_Views[Category_Cupi_ACTUAL] = Views_Cupi_ACTUAL
            
            #Si no (es decir Ya existe) solo le sumo las nuevas views/ ACTUALIZO
            
            else: 
                
                Dict_all_Categorias_Views [Category_Cupi_ACTUAL] += Views_Cupi_ACTUAL
            
            
            
    #Ahora ya tengo una estructura de datos donde puedo realizar comparaciones
    
    Max_total_views = -999
    Categoria_GANADORA = ""
    
    #Si no esta vacia 
    if (Dict_all_Categorias_Views != {}):
        
        for Categoria_key, Views_Value in Dict_all_Categorias_Views.items():
            #Ya realizo un acceso directo tanto al key como al value
            if (Views_Value > Max_total_views):
                
                Max_total_views = Views_Value
                Categoria_GANADORA = Categoria_key
                
    
    
    #Luego de todo el sorteo creo el dict de retorno 
    
    DicT_categoria_GANADORA = {
                               "categoria": Categoria_GANADORA, 
                               "visitas": Max_total_views
                               }

    return DicT_categoria_GANADORA
    
     
        
      
    
#TODO 7
# Funcion 7:

def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" 
    con el valor asociado: [X].[Y][Z]@cupitube.com
    
    - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
    - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
    - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    """
    
    #Funcion modifica el DICT pasado mas NO devuelve nada
    
    #Cosas clave: el correo debe ser de la forma (str);
    #"pewdiepie.1006@cupitube.com" (sin la linea debajo jajaj)
    
    """
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico!!!!
        - La longitud máxima del nombre debe ser de 15 caracteres INCLUSIVO. Si se excede! este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
   
    """
    
    #Asingo en una varible la cosa comun de todos los correos 
    Parte_Final = "@cupitube.com"
    
    
    for Pais_outer_Key, Lista_outer_Value in cupitube.items():
        
        #Implicito
        for Dict_Cupituber in Lista_outer_Value:
            
            Correo = ""
            
            
            # [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales. Y en minuscula
         
            Nombre_cupi_str = Dict_Cupituber["cupituber"].lower()
            
            #Pero esto es un str es decir NO puedo modificar. Pero quiero quitar " " y caracteres especiales
            #entonces creo una lista
            
            Nombre_cupi_LISTA = list(Nombre_cupi_str)
            Nomnbre_LIMPIO_STR = ""
            
            #Implicito
            for Character in Nombre_cupi_LISTA:
                
                #Elimino tanto " " como caracteres especiasles pues si les hago .isalnun() me da FALSE
                
                if (Character.isalnum() == True):
                    
                    #añado ese caracter al str Limpio
                    #que en realidad no estoy añadiendo sino creando un nuevo str, pero CERO GRAVE
                    Nomnbre_LIMPIO_STR += Character
                    
            #Ahora solo tomo los primeros 15 caracteres del nombre, si hay menos no pasa nada
            Nomnbre_LIMPIO_STR = Nomnbre_LIMPIO_STR[0:15]
            
              
            #- [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
            # "started": (str -> YYYY-MM-DD)
            #Por indice el año es de 0,1,2,3
            
            Fecha_inicio_ENTERA = Dict_Cupituber["started"]
            #Indice 4 No inclusivo
            AÑO = Fecha_inicio_ENTERA[2:4]
            
            #[Z]: Los dos dígitos del mes de inicio del CupiTuber
            #mes indices 5 y 6
            
            MES = Fecha_inicio_ENTERA[5:7]
            
            #[X].[Y][Z]@cupitube.com
            
            Correo = Nomnbre_LIMPIO_STR + "." + AÑO + MES + Parte_Final
            
       
            
            
            
            #Ahora creo una nueva llave y asigno valor en el INNER diccionario actual
            #CRUCIAL
            
            Dict_Cupituber["correo"] = Correo
            
            
            
      
#TODO 8
# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    """
    ecomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    """
    
    #Pero primero que todo el diccionario debe estar LLENO
    
    if (cupitube == {}):
        return {}
    
    DICT_categoria_GANADORAAA = obtener_categoria_con_mas_visitas(cupitube)
    Nombre_categoria_GANA = DICT_categoria_GANADORAAA["categoria"]
    
    #Primera condicion: DEBE Pertenece a la categoría con más visitas totales.
    #Puedo hacer llamdo a la funcion que me devolvia un diccionario asi, con la categoria de mas vistas totales 
    """
    
    DicT_categoria_GANADORA = {
                               "categoria": Categoria_GANADORA, 
                               "visitas": Max_total_views
                               }
    
    
    """
    
    
    
    
    palabra_clave = palabra_clave.lower() 
    
    
    #Basicamente debo recorrer TOTAL y hacer ifs, ANIDADOS pues TODAS las conciciones se deben cumplir
    
    for PAIS_Outer_key, Outer_value_list in cupitube.items():
        # Recordar que Outer_value_list es una lista de diccionarios!

        for Dict_CupiTuber in Outer_value_list:
            # Forloopeo implicito para accesar directamente a los valores, los dicts

            if (Dict_CupiTuber["category"] == Nombre_categoria_GANA):
                
                
                
                
                
                #Segunda condicon: Tiene un número de suscriptores dentro del rango especificado.
                #INCLUSIVO
                if ( (Dict_CupiTuber["subscribers"] >= suscriptores_min) and (Dict_CupiTuber["subscribers"] <= suscriptores_max) ):
                    
                    
                    
                    
                    
                    #Tercera condicion: Ha publicado AL MENOS (INCLUSI) la cantidad mínima de videos indicada.

                    if (Dict_CupiTuber["video_count"] >= videos_minimos):
                        
                        #Cuarta: Ha comenzado a publicar dentro del rango de fechas especificado


                        if ( (Dict_CupiTuber["started"] >= fecha_minima) and (Dict_CupiTuber["started"] <= fecha_maxima) ):

                            #Como ambas estan en lower si puedo comparar
                            if (palabra_clave in (Dict_CupiTuber["description"].lower())):
                                
                                
                                
                                # si paso por todos los if filtros
                                #Acabo la funcion prematuramente con el primero que cumpla todo
                                #Entonces No necesariamente voy a recorrer todo el DICT externo
                                return Dict_CupiTuber

    # Si AL FINAL DEL RECORRIDO TOTAL, no encontron nada quiere decir que No hay match (Nada entro en todos los ifs)
    return {}
    
    
 
#TODO 9
# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers 
    con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    
    """
    
    """
    Clav!!!e lo que debo crear y retornear es algo aSI: 
        
        {  Categoria_x(str) : [ Pais_1(str), Pais_2(str), pais_3(str), .......   ],
           Categoria_p(str) : [ Pais_1(str), Pais_2(str), pais_3(str), .......   ],
           Categoria_y(str) : [  .......   ] 
         
            #Listas de cadenas, strings
            
            }
        
        
        
    """
    
    
    
    DICT_categoria_listapaises = {}

    #Debe ser un recorrido TOTAL
    for Outer_KEY_pais, Outer_VALUE_cupitubers_Lista in cupitube.items():
        
        #For loop implicito para el Valor/Lista
        for cupituber in Outer_VALUE_cupitubers_Lista:
            # Obtener la categoría del cupituber
            categoria = cupituber["category"]
            
            # Si la categoría AUN no está en el diccionario, agregarla, como KEY
            if categoria not in DICT_categoria_listapaises:
                #Asigno un lista vacia como valor pues es la primera vez que sale
                DICT_categoria_listapaises[categoria] = []
            
            # Si el país AUN no está en la lista de esa categoría, agregarlo!!
            #de forma tal que aqui solo se entra la primera vez que aparece un pais
            if Outer_KEY_pais not in DICT_categoria_listapaises[categoria]:
                #Recuerda el .append() modifica (añade a la cola), pero No devuelve una lista
                DICT_categoria_listapaises[categoria].append(Outer_KEY_pais)

    # Retornaa
    return DICT_categoria_listapaises
    
    
    
    


#------------------------------------------------------------------------------------------------------------------
#Instrucciones

#Task 1



"""
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
              - El país de origen de un CupiTuber se encuentra en la columna "country" del archivo CSV.
              - El país es un string no vacío, sin espacios al inicio o al final.
                Ejemplo: "India"
            
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber. 
              - Cada diccionario contiene los siguientes campos basados en las columnas del archivo CSV:
    
                "rank" (int): Ranking del CupiTuber en el mundo. Es un valor entero mayor a cero.
                              Ejemplo: 1
    
                "cupituber" (str): Nombre del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                   Ejemplo: "T-Series"
    
                "subscribers" (int): Cantidad de suscriptores del CupiTuber. Es un valor entero mayor a cero.
                                     Ejemplo: 222000000
    
                "video_views" (int): Cantidad de visitas de todos los videos del CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 198459090822
    
                "video_count" (int): Cantidad de videos publicados por el CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 17317
    
                "category" (str): Categoría principal de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                  Ejemplo: "Music"
    
                "started" (str): Fecha en la que el CupiTuber empezó a publicar videos en formato YYYY-MM-DD.
                                Es un string no vacío, sin espacios al inicio o al final.
                                Ejemplo: "2006-11-15"
    
                "monetization_type" (str): Tipo de monetización de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                           Ejemplo: "AdSense"
    
                "description" (str): Descripción del tipo de videos que publica el CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                     Ejemplo: "Amazing travel vlogs worldwide!"
    
    Notas importantes:
        1. Al usar readline(), agregue strip() de esta forma: readline().strip() para garantizar que se eliminen los saltos de línea.
            Documentación de str.strip(): https://docs.python.org/es/3/library/stdtypes.html#str.strip
            Documentación de readline(): https://docs.python.org/es/3/tutorial/inputoutput.html#methods-of-file-objects
            
        2. Al usar open(), agregue la codificación "utf-8" de esta forma: open(archivo, "r", encoding="utf-8") para garantizar la lectura de caracteres especiales del archivo CSV.
"""
#********************************************

#Task 2

"""
Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.

Parámetros:
    cupitube (dict): Diccionario con la información de los CupiTubers.
    suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
    suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
    categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
    
Retorno:
    list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
          Si no se encuentra ningún CupiTuber, retorna una lista vacía.

Ejemplo:
    Para los siguientes valores:
    - suscriptores_min = 1000000
    - suscriptores_max = 111000000
    - categoria_buscada = "Gaming"
    
    Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
    ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
"""

#**************************************************************
#Task 3

    
"""
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
"""

#**************************************************************
#Task 4
"""
 Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
 
 Parámetros:
     cupitube (dict): Diccionario con la información de los CupiTubers.
 
 Retorno:
     dict: Diccionario con la información del CupiTuber más antiguo.
           En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
 
 Nota:
     Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
     En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
     
     Ejemplos de comparaciones:
         "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
         "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
         "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
"""

#****************************************************************
#Task 5

"""
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
"""
#***************************************************************
#Task 6

    
    
"""
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
"""
     
#***************************************************************************************
#Task 7

    
    
"""
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
"""
#***************************************************************************************

#Task 8

"""
 Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
 
 La función busca un CupiTuber que:
    - Pertenece a la categoría con más visitas totales.
    - Tiene un número de suscriptores dentro del rango especificado.
    - Ha publicado al menos la cantidad mínima de videos indicada.
    - Ha comenzado a publicar dentro del rango de fechas especificado.
    - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
 
 Parámetros:
    cupitube (dict): Diccionario con la información de los CupiTubers.
    suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
    suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
    fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
    fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
    videos_minimos (int): Cantidad mínima de videos requerida.
    palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
        
 Retorno:
    dict: Información del primer CupiTuber que cumpla con todos los criterios.
          Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
 
 Notas:
    - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
      Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
    - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
      Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
 """
#*******************************************************************************
#Task 9 

"""
Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

Parámetros:
    cupitube (dict): Diccionario con la información de los CupiTubers.

Retorno:
    dict: Diccionario en el que las llaves son los nombres de las categorías y 
          los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

Nota:
    - No se permiten países repetidos en la misma categoría.
    - Un país puede aparecer en varias categorías.
    - Cada categoría debe tener al menos un país asociado.
    - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"

Ejemplo:    
   Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
       ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
   ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
   Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
"""









    
