import cupitube as ct

def mostrar_cupituber(cupituber: dict) -> None:
    
    print("\n")
    print("#" * 50)
    
    print((
        "\nNombre: {}\n"
        "Ranking: {}\n"
        "Suscriptores: {}\n"
        "Visitas de videos: {}\n"
        "Cantidad de videos: {}\n"
        "Categoría: {}\n"
        "Año de inicio: {}\n"
        "Tipo de monetización: {}\n"
        "Descripción: {}\n"
    ).format(
        cupituber["cupituber"], cupituber["rank"], cupituber["subscribers"],
        cupituber["video_views"], cupituber["video_count"], cupituber["category"],
        cupituber["started"], cupituber["monetization_type"], cupituber["description"]
    ))
    
    print("#" * 50)

def mostrar_cupitubers(cupitubers: list) -> None:
    
    print("\nCupiTubers encontrados:")
    print("-" * 50)
    
    for cupituber in cupitubers:
        mostrar_cupituber(cupituber)

    print("-" * 50)
    
    
def mostrar_paises(paises: list) -> None:
    
    print("-" * 50)
    
    for pais in paises:
        print(pais)
    
    print("-" * 50)


def ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube: dict) -> None:
    
    
    categoria = input("Ingrese la categoría: ")
    categoria=categoria.title()
    minimo = int(input("Ingrese el mínimo de suscriptores: "))
    maximo = int(input("Ingrese el máximo de suscriptores: "))
    
    cupitubers = ct.buscar_por_categoria_y_rango_suscriptores(cupitube, minimo, maximo, categoria)
    
    if cupitubers != []:
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict) -> None:
    

    
    categoria = input("Ingrese la categoría: ")
    categoria=categoria.title()
    monetizacion = input("Ingrese el tipo de monetizacion que quiere buscar: ")
    pais = input("Ingrese el pais que desee buscar: ")
    pais=pais.title()
    
    cupitubers = ct.buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais, categoria, monetizacion)
    
    if cupitubers != []:
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")

        
def ejecutar_buscar_cupituber_mas_antiguo(cupitube: dict) -> None:
    
    ans=ct.buscar_cupituber_mas_antiguo(cupitube)
    print("El CupiTuber más antiguo/a es "+ans["cupituber"]+" y empezó en "+ans["started"])
    
    pass


def ejecutar_obtener_visitas_por_categoria(cupitube: dict) -> None:
    
    categoria = input("Ingrese la categoría: ")
    categoria=categoria.title()
    
    cupitubers = ct.obtener_visitas_por_categoria(cupitube, categoria)
    
    print("Dada la categoría "+categoria+", hay un total de ",cupitubers," vistas.")
        
    pass


def ejecutar_obtener_categoria_con_mas_visitas(cupitube: dict) -> None:
    
    
    ans=ct.obtener_categoria_con_mas_visitas(cupitube)
    
    print("La categoría con más visitas es ",ans[1]," con ",ans[0]," visitas.")
    
    pass

    
def ejecutar_crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    if "USA" in cupitube and cupitube["USA"] != [] and cupitube["USA"][0] is not None:
        ct.crear_correo_para_cupitubers(cupitube)
        cupituber = cupitube["USA"][0]
        print("El correo para el primer Cupituber de 'USA' con nombre '" + cupituber["cupituber"] + "' es: " + cupituber["correo"] + ".")
        

def ejecutar_recomendar_cupituber(cupitube: dict) -> None:
    
    
    suscriptores_min = int(input("Ingrese los subscriptores minimos que necesita tener el YouTuber: "))
    suscriptores_max = int(input("Ingrese los subscriptores maximos que necesita tener el YouTuber: "))
    videos_minimos = int(input("Ingrese los videos minimos que necesita tener el YouTuber: "))
    palabra_clave = input("Ingrese una palabra clave que quiera que el YouTuber presenta en su descripción: ")
    fecha_min=input("Ingres la fecha minima en la que el Youtuber haya empezado (año/mes/dia:2025/04/29): ")
    fecha_max=input("Ingres la fecha maxima en la que el Youtuber haya empezado (año/mes/dia:2025/04/29): ")
    fecha_minima=fecha_min[:4]+"-"+fecha_min[5:7]+"-"+fecha_min[8:]
    fecha_maxima=fecha_max[:4]+"-"+fecha_max[5:7]+"-"+fecha_max[8:]
    
    cupitubers = ct.recomendar_cupituber(cupitube, suscriptores_min, suscriptores_max, fecha_minima, fecha_maxima, videos_minimos, palabra_clave)
    
    if cupitubers==[]:
        print("No se encontro al Youtuber con estas caracteristicas")
    else:
        print(mostrar_cupituber(cupitubers))
    
    pass
    
    
def ejecutar_paises_por_categoria(cupitube: dict) -> None:
    
    estructura = ct.paises_por_categoria(cupitube)
    
    categoria = input("Ingrese la categoría: ")
    
    if categoria != "" and categoria in estructura:
        paises = estructura[categoria]
        if paises != {} and paises is not None:
            print("\nLos países con CupiTubers en la categoría " + categoria + " son:")
            mostrar_paises(paises)
    else:
        print("La categoría ingresada no existe en los datos.")


def iniciar_aplicacion() -> None:
    
    ejecutando = False
    archivo = input("Ingrese el nombre del archivo de datos o presione Enter si su archivo se llama cupitube.csv: ")
    
    if archivo == "":
        archivo = "cupitube.csv"
        
    estados = ct.cargar_cupitube(archivo)
    if estados != {} and estados is not None:
        ejecutando = True
        print("#" * 50)
        print("¡Bienvenido a la aplicación de CupiTube!")
        print("#" * 50)
    
        while ejecutando:
            ejecutando = mostrar_menu_aplicacion(estados)
            if ejecutando:
                input("Presione Enter para continuar...")
    else:
        print("\nError: No se ha podido cargar el archivo. \nRevise su implementación de la función: cargar_cupitube() en cupitube.py")
      
            
def mostrar_menu_aplicacion(cupitube: dict) -> bool:
    
    print("\nMenú de opciones:")
    print("1. Buscar CupiTubers por categoría y rango de suscriptores.")
    print("2. Buscar CupiTubers por país, categoría y monetización.")
    print("3. Buscar CupiTuber más antiguo.")
    print("4. Obtener visitas para una categoría.")
    print("5. Obtener categoría con más visitas.")
    print("6. Crear correo para CupiTubers.")
    print("7. Recomendar un CupiTuber.")
    print("8. Obtener países por categoría.")
    print("9. Salir.")

    opcion_elegida = input("Ingrese la opción que desea ejecutar: ").strip()

    continuar_ejecutando = True

    if opcion_elegida == "1":
        ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube)
    elif opcion_elegida == "2":
        ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube)
    elif opcion_elegida == "3":
        ejecutar_buscar_cupituber_mas_antiguo(cupitube)
    elif opcion_elegida == "4":
        ejecutar_obtener_visitas_por_categoria(cupitube)
    elif opcion_elegida == "5":
        ejecutar_obtener_categoria_con_mas_visitas(cupitube)
    elif opcion_elegida == "6":
        ejecutar_crear_correo_para_cupitubers(cupitube)
    elif opcion_elegida == "7":
        ejecutar_recomendar_cupituber(cupitube)
    elif opcion_elegida == "8":
        ejecutar_paises_por_categoria(cupitube)
    elif opcion_elegida == "9":
        print("\n¡Gracias por usar la aplicación de CupiTube!")
        continuar_ejecutando = False
    else:
        print("Opción inválida. Por favor inténtelo de nuevo.")

    return continuar_ejecutando


if __name__ == "__main__":
    iniciar_aplicacion()