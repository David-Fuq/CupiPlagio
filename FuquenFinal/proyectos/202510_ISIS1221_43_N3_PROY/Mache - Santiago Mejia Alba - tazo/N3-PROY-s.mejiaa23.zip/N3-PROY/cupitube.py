# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    youtubers={}
    archivos=open(archivo,"r", encoding="utf-8")
    titulos=archivos.readline().strip().split(",")
    print(titulos)      
    
    linea=archivos.readline().strip()
    while len(linea)>0:
        datos=linea.split(",")
        pais=datos[7]
        youtuber={}
        youtuber["rank"]=int(datos[0])
        youtuber["cupituber"]=datos[1]
        youtuber["subscribers"]=int(datos[2])
        youtuber["video_views"]=int(datos[3])
        youtuber["video_count"]=int(datos[4])
        youtuber["category"]=datos[5]
        youtuber["started"]=datos[6]
        youtuber["monetization_type"]=datos[8]
        youtuber["description"]=datos[9]
        
        if pais not in youtubers:
            youtubers[pais]=[]
        youtubers[pais].append(youtuber)
        linea=archivos.readline().strip()
    
    archivos.close()
    
    return youtubers


def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    ans=[]
    
    for i in cupitube.values():
        for j in i:
            if (suscriptores_min <= j["subscribers"]) and ((suscriptores_max >= j["subscribers"])) and (categoria_buscada==j["category"]):
                ans.append(j)
    
    return ans


def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    
    ans=[]
    
    if pais_buscado in cupitube:
        
        for i in cupitube[pais_buscado]:
            if (categoria_buscada==i.get("category")) and (monetizacion_buscada==i.get("monetization_type")):
                ans.append(i)
    
    return ans
    

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    ans=[]
    
    for i in cupitube.values():
        for j in i:
            if ans==[] or j["started"]<ans["started"]:
                ans=j
    
    return ans
 

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    
    suma_vistas=0
    
    for i in cupitube.values():
        for j in i:
            if j["category"]==categoria_buscada:
                suma_vistas+=j["video_views"]
    
    return suma_vistas


def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    vistas={}
    
    for i in cupitube:
        for j in cupitube[i]:
            categoria=j["category"]
            visitas=j["video_views"]
            if categoria not in vistas:
                vistas[categoria]=0
            vistas[categoria]+=visitas
    
    maximo=0
    
    for i in vistas:
        if vistas[i]>maximo:
            maximo=vistas[i]
            categoria_visitas=i
    
    return maximo, categoria_visitas


def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    
    for i in cupitube.values():
        for j in i:
            nombre=j["cupituber"].lower()
            anio=j["started"][2:4]
            dia=j["started"][5:7]
            
            new_nombre=""
            for l in nombre:
                if l.isalnum():
                    new_nombre+=l
            
            nombreco=new_nombre[:15]
            
            correo=nombreco+"."+anio+dia+"@cupitube.com"
            
            j["correo"]=correo
            
    return 
                    

def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    
    categoria=obtener_categoria_con_mas_visitas(cupitube)
    
    for i in cupitube:
        for j in cupitube[i]:
            if j["category"]==categoria[1]:
                if (suscriptores_min<=j["subscribers"]) and (suscriptores_max>=j["subscribers"]):
                    if (fecha_minima<=j["started"]) and (fecha_maxima>=j["started"]):
                        if videos_minimos<=j["video_count"]:
                            if palabra_clave.title() in j["description"].title():
                                return j


def paises_por_categoria(cupitube: dict) -> dict:
    
    
    ans={}
    
    for i in cupitube:
        for j in cupitube[i]:
            cat=j["category"]
            if cat not in ans:
                ans[cat]=[]
            if i not in ans[cat]:
                ans[cat].append(i)
    
    return ans