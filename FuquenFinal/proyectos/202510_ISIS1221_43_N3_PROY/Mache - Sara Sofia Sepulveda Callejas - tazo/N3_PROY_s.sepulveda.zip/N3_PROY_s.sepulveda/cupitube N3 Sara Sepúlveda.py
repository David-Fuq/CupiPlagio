#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
# Funcion 1:
def cargar_cupitube(archivo: str) -> dict:
    datos = {}

    with open(archivo, "r", encoding="utf-8") as archivo:
        archivo.readline()  # Ignorar encabezado
        linea = archivo.readline().strip()

        while linea != "":
            columnas = linea.split(",")
            cupituber = {
                "rank": int(columnas[0]),
                "cupituber": columnas[1],
                "subscribers": int(columnas[2]),
                "video_views": int(columnas[3]),
                "video_count": int(columnas[4]),
                "category": columnas[5],
                "started": columnas[6],
                "country": columnas[7],
                "monetization_type": columnas[8],
                "description": columnas[9]
            }

            pais = columnas[7]

            if pais not in datos:
                datos[pais] = []

            datos[pais].append(cupituber)
            linea = archivo.readline().strip()

    return datos

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria: str) -> list:
    resultado = []

    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            if cupituber["category"] == categoria and suscriptores_min <= cupituber["subscribers"] <= suscriptores_max:
                resultado.append(cupituber)

    return resultado

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if (cupituber["category"] == categoria_buscada and 
                cupituber["monetization_type"] == monetizacion_buscada):
                resultado.append(cupituber)
    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber

    return mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_busqueda: str) -> int:
    total_visitas = 0

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_busqueda:
                total_visitas += cupituber["video_views"]

    return total_visitas

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> tuple:
    visitas_por_categoria = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = 0
            visitas_por_categoria[categoria] += visitas

    categoria_mayor = ""
    visitas_mayores = -1

    for categoria in visitas_por_categoria:
        if visitas_por_categoria[categoria] > visitas_mayores:
            categoria_mayor = categoria
            visitas_mayores = visitas_por_categoria[categoria]

    return categoria_mayor, visitas_mayores

# Función 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre = cupituber["cupituber"].lower().replace(" ", "")
            correo = nombre + "@cupitube.com"
            cupituber["correo"] = correo

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int,
                          fecha_minima: str, fecha_maxima: str, videos_minimos: int,
                          palabra_clave: str) -> list:
    resultados = []

    for pais in cupitube:
        lista = cupitube[pais]
        for cupituber in lista:
            subs = cupituber["subscribers"]
            videos = cupituber["video_count"]
            fecha = cupituber["started"]
            descripcion = cupituber["description"].lower()

            if (suscriptores_min <= subs <= suscriptores_max and
                videos >= videos_minimos and
                fecha_minima <= fecha <= fecha_maxima and
                palabra_clave.lower() in descripcion):
                resultados.append(cupituber)

    return resultados

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            if categoria not in categorias:
                categorias[categoria] = set()
            categorias[categoria].add(pais)

    for categoria in categorias:
        categorias[categoria] = list(categorias[categoria])

    return categorias