
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    
    cupitubers = {} 

    abrir_archivo = open( archivo , "r" )

    titulos = abrir_archivo.readline().strip()

    linea = abrir_archivo.readline().strip()

    while linea != "":
        columna = linea.split(",")

        rank = int(columna[0])
        cupituber = columna[1].strip()
        subscribers = int(columna[2])
        video_views = int(columna[3])
        video_count = int(columna[4])
        category = columna[5].strip()
        started = columna[6].strip()
        country = columna[7].strip()
        monetization_type = columna[8].strip()
        description = columna[9].strip()

        cupituber_info = {
            "rank": rank,
            "cupituber": cupituber,
            "subscribers": subscribers,
            "video_views": video_views,
            "video_count": video_count,
            "category": category,
            "started": started,
            "monetization_type": monetization_type,
            "description": description
        }

        if country not in cupitubers:
            cupitubers[country] = []

        cupitubers[country].append(cupituber_info)

        linea = abrir_archivo.readline().strip()

    abrir_archivo.close()

    return cupitubers


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    rta = []
    
    for pais in cupitube:
        
        ctubers = cupitube[pais]
        
        for cupituber in ctubers:
            categoria = cupituber["category"]
            suscriptores =  cupituber["subscribers"]
            
            if categoria == categoria_buscada and suscriptores_min <= suscriptores <= suscriptores_max:
                rta.append(cupituber)
        

    return rta


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    rta = []
     
    if pais_buscado in cupitube:
        ctubers_en_el_pais = cupitube[pais_buscado]
        
        for cupituber in ctubers_en_el_pais:
            categoria = cupituber["category"]
            monetizacion = cupituber["monetization_type"]
            
            if categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                rta.append(cupituber)
            
    return rta

    


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:

    
    
    cupituber_mas_antiguo = None
    fecha_mas_baja = None
    
    for pais in cupitube:
        ctubers = cupitube[pais]
        
        for cupituber in ctubers:
            inicio = cupituber["started"]
            
            if fecha_mas_baja < inicio:
                fecha_mas_baja = inicio
                cupituber_mas_antiguo = cupituber

    return cupituber_mas_antiguo
        
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    visitas = 0

    for pais in cupitube:
        ctubers = cupitube[pais]
        
        for cupituber in ctubers:
            categoria = cupituber["category"]
            if categoria == categoria_buscada:
                visitas += cupituber["video_views"]
    
    return visitas
         
         


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:

    visitas_por_categoria = {}
        
    for pais in cupitube:
            ctubers = cupitube[pais]
            
            for cupituber in ctubers:
                categoria = cupituber["category"]
                visitas = cupituber["video_views"]
                
                if categoria not in visitas_por_categoria:
                    visitas_por_categoria[categoria] = visitas
                else:
                    visitas_por_categoria[categoria] += visitas
    
    categoria_mas_visitada = None
    visitas_maximas = None
        
    for categoria in visitas_por_categoria:
            visitas = visitas_por_categoria[categoria]
            
            if visitas_maximas is None or visitas > visitas_maximas:
                visitas_maximas = visitas
                categoria_mas_visitada = categoria
    
    return {"categoria": categoria_mas_visitada,"visitas": visitas_maximas}

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        ctubers = cupitube[pais]
        
        for cupituber in ctubers:
            nombre = cupituber["cupituber"]
            fecha_inicio = cupituber["started"]
            
            nombre_limpio = ""
            for caracter in nombre:
                if caracter.isalnum():
                    nombre_limpio += caracter

            nombre_limpio = nombre_limpio[:15]

            anio = fecha_inicio[2:4]
            mes = fecha_inicio[5:7]

            correo = nombre_limpio.lower() + "." + anio + mes + "@cupitube.com"
            
            cupituber["correo"] = correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    resultado = obtener_categoria_con_mas_visitas(cupitube)
    categoria_mas_visitada = resultado["categoria"]

    palabra_clave = palabra_clave.lower()
    
    for pais in cupitube:
        ctubers = cupitube[pais]
        
        for cupituber in ctubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            fecha_inicio = cupituber["started"]
            cantidad_videos = cupituber["video_count"]
            descripcion = cupituber["description"].lower()
            
            if categoria == categoria_mas_visitada:
                if suscriptores_min <= suscriptores <= suscriptores_max:
                    if fecha_minima <= fecha_inicio <= fecha_maxima:
                        if cantidad_videos >= videos_minimos:
                            if palabra_clave in descripcion:
                                return cupituber
                                
    return {}


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias_paises = {}
    
    for pais in cupitube:
        ctubers = cupitube[pais]
        
        for cupituber in ctubers:
            categoria = cupituber["category"]
            
            if categoria not in categorias_paises:
                categorias_paises[categoria] = []
            
            if pais not in categorias_paises[categoria]:
                categorias_paises[categoria].append(pais)
    
    return categorias_paises
