#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    resultado = {}
    archivo = open("./cupitube.csv", "r", encoding="utf-8")
    encabezado = archivo.readline().strip().split(",")

    linea = archivo.readline()
    while linea != "":
        datos = linea.strip().split(",")

        if len(datos) == len(encabezado):
            fila = {}
            i = 0
            while i < len(encabezado):
                fila[encabezado[i]] = datos[i].strip()
                i += 1

            pais = fila["country"]
            informacion_cupituber = {"rank": int(fila["rank"]),"cupituber": fila["cupituber"],\
                "subscribers": int(fila["subscribers"]), "video_views": int(fila["video_views"]), \
                "video_count": int(fila["video_count"]),"category": fila["category"],\
                "started": fila["started"],"monetization_type": fila["monetization_type"],\
                "description": fila["description"]}

            if pais not in resultado:
                resultado[pais] = []
            resultado[pais].append(informacion_cupituber)

        linea = archivo.readline()

    archivo.close()
    return resultado

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    resultado = []
   
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada and suscriptores_min <= cupituber["subscribers"] and cupituber["subscribers"] <= suscriptores_max:
                resultado.append(cupituber)
    
    return resultado
    
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    resultado = []
    
    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
                resultado.append(cupituber)

    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    mas_antiguo = None
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber
    return mas_antiguo          

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
  
    total_visitas = 0
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada:
                total_visitas += cupituber["video_views"]
    return total_visitas

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    visitas_por_categoria = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]

            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = visitas
            else:
                visitas_por_categoria[categoria] += visitas

    categoria_max = None
    max_visitas = -1

    for categoria in visitas_por_categoria:
        if visitas_por_categoria[categoria] > max_visitas:
            categoria_max = categoria
            max_visitas = visitas_por_categoria[categoria]

    return {"categoria": categoria_max, "visitas": max_visitas}

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre = cupituber["cupituber"]
            fecha = cupituber["started"]

            nombre_filtrado = ""
            for c in nombre:
                if c.isalnum():
                    nombre_filtrado += c
            nombre_filtrado = nombre_filtrado.lower()

            if len(nombre_filtrado) > 15:
                nombre_filtrado = nombre_filtrado[:15]

            anio = fecha[2:4] 
            mes = fecha[5:7]

            
            correo = f"{nombre_filtrado}.{anio}{mes}@cupitube.com"

            cupituber["correo"] = correo

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    categorias_visitas = {}
    for pais in cupitube:
        for c in cupitube[pais]:
            categoria = c["category"]
            visitas = c["video_views"]
            if categoria not in categorias_visitas:
                categorias_visitas[categoria] = 0
            categorias_visitas[categoria] += visitas
    
    max_categoria = ""
    max_visitas = -1
    for categoria, visitas in categorias_visitas.items():
        if visitas > max_visitas:
            max_visitas = visitas
            max_categoria = categoria
    
    respuesta = {}  
    palabra_clave = palabra_clave.lower()
 
    encontrado = False  
    for pais in cupitube:
        for c in cupitube[pais]:
            if not encontrado and c["category"] == max_categoria and suscriptores_min <= c["subscribers"] <= suscriptores_max and c["video_count"] >= videos_minimos and fecha_minima <= c["started"] <= fecha_maxima and palabra_clave in c["description"].lower():
                respuesta = c
                encontrado = True
    
    return respuesta 

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    resultado = {}

    for pais in cupitube:
        for c in cupitube[pais]:
            categoria = c["category"]
            if categoria not in resultado:
                resultado[categoria] = []
            if pais not in resultado[categoria]:
                resultado[categoria].append(pais)

    return resultado
