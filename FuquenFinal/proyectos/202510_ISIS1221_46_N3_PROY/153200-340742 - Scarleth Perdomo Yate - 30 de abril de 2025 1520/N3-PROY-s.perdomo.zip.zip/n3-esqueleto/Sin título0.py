def buscar_vuelos_escala(vuelos: dict, origen: str, destino: str) -> list:
    """ Buscar vuelos (con escala)
    Parámetros:
      vuelos (dict): Es un diccionario de diccionarios con la información de los vuelos.
      origen (str): El código del aeropuerto de origen
      destino (str): El código del aeropuerto de destino
    Retorno:
      list: Retorna una lista con los itinerarios posibles entre el origen y el destino.
    """
    itinerarios = []
    
    for codigo_vuelo, info_vuelo in vuelos.items():
        if info_vuelo["origen"] == origen and info_vuelo["destino"] == destino:
            itinerarios.append([codigo_vuelo])
    
    for codigo_v1, info_v1 in vuelos.items():
        if info_v1["origen"] == origen:
            conexion = info_v1["destino"]
            
            hora_salida_v1 = info_v1["salida"]
            horas_v1 = hora_salida_v1 // 100
            minutos_v1 = hora_salida_v1 % 100
            total_minutos_salida_v1 = horas_v1 * 60 + minutos_v1
            llegada_v1 = total_minutos_salida_v1 + info_v1["duracion"] + info_v1["retraso"]
            
            for codigo_v2, info_v2 in vuelos.items():
                if (info_v2["origen"] == conexion and 
                    info_v2["destino"] == destino):
                    
                    hora_salida_v2 = info_v2["salida"]
                    horas_v2 = hora_salida_v2 // 100
                    minutos_v2 = hora_salida_v2 % 100
                    total_minutos_salida_v2 = horas_v2 * 60 + minutos_v2
                    
                    if llegada_v1 <= total_minutos_salida_v2:
                        itinerarios.append([codigo_v1, codigo_v2])
    
    return itinerarios
