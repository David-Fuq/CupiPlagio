#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
def crear_diccionario_cupituber(datos:list)->dict():
    cupituber = {"rank": int(datos[0]),
          "cupituber": datos[1],
          "subscribers": int(datos[2]),
          "video_views": int(datos[3]),
          "video_count": int(datos[4]),
          "category": datos[5],
          "started": datos[6],
          "monetization_type": datos[8],
          "description": datos[9],
          }
    return cupituber
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    paises = {}
    arch = open(archivo, "r", encoding="utf-8")
    arch.readline()
    linea = arch.readline().strip()
    while linea != "":
        datos = linea.split(',')
        ct = crear_diccionario_cupituber(datos)
        pais = datos[7]
        if pais not in paises:
            paises[pais] = []
        paises[pais].append(ct)
        linea = arch.readline().strip()
    arch.close()
    return paises

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    misma_categoria_suscriptores = []
    for pais in cupitube:
        for info in cupitube[pais]:
            
            if info["category"] == categoria_buscada and suscriptores_min <= info["subscribers"] <= suscriptores_max:
                
                misma_categoria_suscriptores.append(info)
    
    return misma_categoria_suscriptores
    
    


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    
    for pais in cupitube:
        if pais == pais_buscado:
            for info in cupitube[pais]:
                if info["category"] == categoria_buscada and info["monetization_type"] == monetizacion_buscada:
                    resultado.append(info)
    
    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = {"started": "9999-99-99"}
    
    for pais in cupitube:
        for info in cupitube[pais]:
            if info["started"] < mas_antiguo["started"]:
                mas_antiguo = info
            else: 
                mas_antiguo = mas_antiguo
                
    return mas_antiguo
            
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0 
    
    for pais in cupitube:
        for info in cupitube[pais]:
            if info["category"] == categoria_buscada:
                total += info["video_views"]
                
    return total


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    resultado = {"categoria": "", 
                 "visitas": 0}
    
    
    for pais in cupitube:
        for info in cupitube[pais]:
            categoria = info["category"]
            posible_mayor = obtener_visitas_por_categoria(cupitube, categoria)
            if categoria != resultado["categoria"] and posible_mayor > resultado["visitas"]:
                resultado["categoria"] = categoria 
                resultado["visitas"] = posible_mayor
                
    return resultado            
                
# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for info in cupitube[pais]: 
            
            nombre = info["cupituber"]
            nombre_limpio = ""
            
            for caracter in nombre:
                if caracter.isalnum():
                    nombre_limpio += caracter.lower()
            
            if len(nombre_limpio) > 15:
                nombre_limpio = nombre_limpio[:15]
            
            fecha_inicio = info["started"]  
            partes_fecha = fecha_inicio.split("-")
            anio = partes_fecha[0]
            mes = partes_fecha[1]
            
            ultimos_dos_anio = anio[len(anio)-2:]
            
            if len(mes) == 1:
                mes = "0" + mes
            
            correo = nombre_limpio + "." + ultimos_dos_anio + mes + "@cupitube.com"
            info["correo"] = correo  


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    palabra_clave = palabra_clave.lower()
    categoria = obtener_categoria_con_mas_visitas(cupitube)
    cupitubers_rango = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria["categoria"])
    encontrado = False
    i = 0 
    resultado = {}
    while encontrado == False and i < len(cupitubers_rango):
        
        if fecha_minima <= cupitubers_rango[i]["started"] <= fecha_maxima and palabra_clave in cupitubers_rango[i]["description"].lower() and videos_minimos <= cupitubers_rango[i]["video_count"]:
            resultado = cupitubers_rango[i]
            encontrado = True
        else: 
            i += 1
    
    return resultado
            
    
    
# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}

    for pais in cupitube:
        for info in cupitube[pais]:
            categoria = info["category"]
            
            if categoria not in resultado:
                resultado[categoria] = []
    
            if pais not in resultado[categoria]:
                resultado[categoria].append(pais)
    
    return resultado
