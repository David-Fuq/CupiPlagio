"""
CupiTube
"""

# Función 1:    QUITAR CARACTERES ESPECIALES
def cargar_cupitube(ruta: str) -> dict:
    cupituber = {}
    archivo = open(ruta, "r", encoding="utf-8")
    archivo.readline().strip().split(",")

    
    linea = archivo.readline()
    while len(linea)>0:
        datos = linea.split(",")
        pais_cupituber = datos[7].strip()
        
        data_tuber = {}
        
        data_tuber["rank"] = datos[0]
        data_tuber["Nombre"] = datos[1].strip()
        data_tuber["Suscriptores"] = int(datos[2].strip())
        data_tuber["views_videos"] = int(datos[3].strip())
        data_tuber["video_count"] = int(datos[4].strip())
        data_tuber["category"] = datos[5].strip()
        data_tuber["started"] = datos[6].strip()
        data_tuber["monetizacion"] = datos[8].strip()
        data_tuber["description"] = datos[9].strip().lower()
        
        if pais_cupituber not in cupituber:
            cupituber[pais_cupituber] = []
        cupituber[pais_cupituber].append(data_tuber)
        
        linea = archivo.readline().strip()
        
    archivo.close()
    
    return cupituber
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
rta = cargar_cupitube(ruta)
#print(rta)


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    rta = []

    for pais in cupitube:
        for tuber in cupitube[pais]:
            if tuber["category"] == categoria_buscada and tuber["Suscriptores"] >= suscriptores_min and tuber["Suscriptores"] <= suscriptores_max:
                rta.append(tuber)
    
    return rta
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
rta = buscar_por_categoria_y_rango_suscriptores(cargar_cupitube(ruta), 1000000, 111000000, "Gaming")
#print(rta)


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    rta = []
    
    for pais in cupitube:
        if pais == pais_buscado:
            for tuber in cupitube[pais]:
                if tuber["category"] == categoria_buscada and tuber["monetizacion"] == monetizacion_buscada:
                    rta.append(tuber)
    
    return rta
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
rta = buscar_cupitubers_por_pais_categoria_monetizacion(cargar_cupitube(ruta), "UK","Gaming", "Crowdfunding")
#print(rta)


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    antiguo = None
    fecha_a = "2056-06-19"
    
    for pais in cupitube:
        for tuber in cupitube[pais]:
            fecha = tuber["started"]
            if fecha < fecha_a:
                fecha_a = fecha
                antiguo = tuber
    return antiguo      
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
rta = buscar_cupituber_mas_antiguo(cargar_cupitube(ruta))
#print(rta)

# Función 5: FALTA DEFINIR cual es 
def obtener_visitas_por_categoria(cupitube: dict,categoria_buscada: str) -> int:
    acumulado = 0
    
    for pais in cupitube:
        for tuber in cupitube[pais]:
            if categoria_buscada == tuber["category"]:
                acumulado += int(tuber["views_videos"])
    return acumulado     
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
rta = obtener_visitas_por_categoria(cargar_cupitube(ruta), "Music")
#print(rta)
        
# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categoria_visitas = {}
    
    for pais in cupitube:
        for tuber in cupitube[pais]:
            categoria = tuber["category"]
            visitas = tuber["views_videos"]
            
            if categoria in categoria_visitas:
                categoria_visitas[categoria] += visitas
            else:
                categoria_visitas[categoria] = visitas
    
    categoria_top = None
    max_visitas = -1
    
    for categoria in categoria_visitas:
        if categoria_visitas[categoria] > max_visitas:
            max_visitas = categoria_visitas[categoria]
            categoria_top = categoria

    return {"category": categoria_top, "views": max_visitas}
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
rta = obtener_categoria_con_mas_visitas(cargar_cupitube(ruta))
#print(rta)

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for tuber in cupitube[pais]:
            nombre = tuber["Nombre"]
            nombre_l = ""

            for c in nombre:
                if c.isalnum() == True:
                    nombre_l += c
            nombre_l = nombre_l.lower()[:15]

            fecha = tuber["started"]
            y = fecha[2:4]
            x = fecha[5:7]
            correo = f"{nombre_l}.{y}{x}@cupitube.com"
            tuber["correo"] = correo
        
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
rta = crear_correo_para_cupitubers(cargar_cupitube(ruta))
#print(rta)


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    visitas_por_categoria = {}
    centinela =  False
    
    for pais in cupitube:
        for tuber in cupitube[pais]:
            categoria = tuber["category"]
            visitas = tuber["views_videos"]
            visitas_por_categoria[categoria] = visitas_por_categoria.get(categoria, 0) + visitas
            
    categoria_top = max(visitas_por_categoria, key=visitas_por_categoria.get)
    candidato =  buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min,suscriptores_max,categoria_top)
     
    pos = 0
    recomendado = {}


    while pos < len(candidato) and centinela == False:
        tuber = candidato[pos]
        if (fecha_minima <= tuber["started"] <= fecha_maxima and tuber["video_count"] >= videos_minimos and palabra_clave.lower() in tuber["description"].lower()):
            recomendado = tuber
            centinela = True
        else:
            pos += 1
            
    return recomendado 
            
ruta = "C:/Users/Andrés Aldana/Desktop/Andres Aldana - IP/trabajos/proyectos/N3/cupitube.csv"
# print(rta)


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:

    categoria_recomendado = {}

    for pais in cupitube:
        for tuber in cupitube[pais]:
            categoria = tuber["category"]
            
            if categoria not in categoria_recomendado:
                categoria_recomendado[categoria] = [pais]
                
            elif pais not in categoria_recomendado[categoria]:
                categoria_recomendado[categoria].append(pais)
                
    return categoria_recomendado