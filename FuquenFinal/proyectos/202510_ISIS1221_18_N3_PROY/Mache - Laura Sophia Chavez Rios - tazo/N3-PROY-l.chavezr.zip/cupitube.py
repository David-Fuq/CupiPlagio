#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
archivo = "C:/Users/cslau/Desktop/cupitube1.csv"
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    archivo = open(archivo,"r", encoding="utf-8") 
    k = {}
    linea = archivo.readline().strip()
    linea = archivo.readline().strip()
    while linea != "": 
        lista = linea.split(",")
        v = {}
        v["rank"] = int(lista[0]) 
        v["cupituber"] = lista[1] 
        v["subscribers"] = int(lista[2])
        v["video_views"] = int(lista[3]) 
        v["video_count"] = int(lista [4]) 
        v["category"] = lista[5]
        v["started"] = lista[6]
        v["monetization_type"] = lista[8]
        v["description"] = lista[9]
        country = lista[7]
        if country not in k:
            k[country] = []
        k[country].append(v)
        
        linea = archivo.readline().strip()
        
    archivo.close() 
    return k

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    rta = []
    for pais in cupitube:
        for c in cupitube[pais]:
            if c["category"] == categoria_buscada and c["subscribers"] >= suscriptores_min and c["subscribers"] <= suscriptores_max:
                rta.append(c)
    return rta

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    rta = []
    for pais in cupitube:
        if pais == pais_buscado:
            for c in cupitube[pais]:
                if c["category"] == categoria_buscada and c["monetization_type"] == monetizacion_buscada :
                    rta.append(c)
    return rta

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    menor = {}
    ant = "2100-01-01"
    for pais in cupitube:
        for c in cupitube[pais]:
            if ant > c["started"]:
                menor = c
                ant = c["started"]
    return menor           

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    rta = 0
    for pais in cupitube:
        for c in cupitube[pais]:
            if c["category"] == categoria_buscada:
                rta += c["video_views"]
    return rta

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mayor = 0
    rta = {}
    for pais in cupitube:
        for c in cupitube[pais]:
            if mayor < obtener_visitas_por_categoria(cupitube, c["category"]):
                rta["categoria"] = c["category"]
                mayor = obtener_visitas_por_categoria(cupitube, c["category"])
                rta["visitas"] = mayor
    return rta

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    x = ""
    for pais in cupitube:
        for c in cupitube[pais]:
            
            for a in c["cupituber"]:
                if a.isalnum() == True and len(x)<=15:
                    x += a.lower()
                    
            for a in c["started"]:
                y = c["started"][2:4]
                z = c["started"][5:7]
                
            c["correo"] = x+"."+y+z+"@cupitube.com"
            x = ""
    return None
                    
# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    rta = {}
    i = 0
    s = True
    cat = obtener_categoria_con_mas_visitas(cupitube)
    categoria_buscada = cat["categoria"]
    num_sus = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria_buscada)
    while s and i<len(num_sus):
        if (num_sus[i]["started"] > fecha_minima) and (num_sus[i]["started"] < fecha_maxima) and (num_sus[i]["video_count"] >= videos_minimos) and (palabra_clave.lower() in num_sus[i]["description"].lower()):
            rta = num_sus[i]
            s = False
        i += 1
    return rta       

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    v = {}
    
    for pais in cupitube:
        for c in cupitube[pais]:
            categoria = c["category"]
            
            if categoria not in v:
                v[categoria] = []

            if pais not in v[categoria]:
                v[categoria].append(pais)
            
    return v