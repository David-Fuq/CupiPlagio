#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""


# Función 1: 
    

archivo = "/Users/tomaspalmaescallon/Desktop/cupitube.csv"

def cargar_cupitube(archivo: str) -> dict:
    
    doc = open(archivo, "r", encoding = "utf-8")
    
    grande = {}
    linea = doc.readline()
    linea = doc.readline().strip() 
      
    
    while linea != "":
    
        lista = linea.split(",")
        pais = lista[7]
        
        mini = {}
            
        mini["rank"] = int(lista[0])
        mini["cupituber"] = lista[1]
        mini["subscribers"] = int(lista[2])
        mini["video_views"] = int(lista[3])
        mini["video_count"] = int(lista[4])
        mini["category"] = lista[5]
        mini["started"] = lista[6]
        mini["monetization_type"] = lista[8]
        mini["description"] = lista[9]
       
        if pais in grande:
            l = grande[pais]
        else:
            l = []
    
        l.append(mini)
        grande[pais] = l
        
        linea = doc.readline().strip() 
       
    
    doc.close()
    
    return grande

# print(cargar_cupitube(archivo))

cupitube = cargar_cupitube(archivo)




# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:

    l = []
 
    for pais in cupitube:      
        lista = cupitube[pais]
        
        
        for mini in lista:
                   
            if (mini["category"] == categoria_buscada) and (mini["subscribers"] >= suscriptores_min) and (mini["subscribers"] <= suscriptores_max):  
                l.append(mini)
                    
    return l
    
    
# print(buscar_por_categoria_y_rango_suscriptores(cupitube, 1000000, 111000000, "Gaming"))



# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    l = []
        
    for pais in cupitube:
        
        if pais == pais_buscado:
                    
            lista = cupitube[pais]
      
            for mini in lista:
                if (mini["category"] == categoria_buscada) and (mini["monetization_type"] == monetizacion_buscada):
                    l.append(mini)
                
    return l

# print(buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, "UK", "Gaming", "Crowdfunding"))
        
    
# Función 4:
    
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:

    antiguo = "2026-12-31"
    
    for pais in cupitube:
        lista = cupitube[pais]
        for mini in lista:
            if mini["started"] < antiguo:
                antiguo = mini["started"]
                elegido = mini
                
    return elegido
            

# print(buscar_cupituber_mas_antiguo(cupitube))            

# Función 5:
    
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:

    visitas = 0
        
    for pais in cupitube:
        lista = cupitube[pais]
      
        for mini in lista:
            if (mini["category"] == categoria_buscada):
                visitas += mini["video_views"]
            
                
                
    return visitas

# print(obtener_visitas_por_categoria(cupitube, "Music"))



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:

    mayor = 0
    mejor = ""
    v = {}
      
    for pais in cupitube:
        lista = cupitube[pais]
        
      
        for mini in lista:
            vistas = mini["video_views"]
            categoria = mini["category"]
            
            if categoria not in v:
                v[categoria] = vistas

            else:
                v[categoria] += vistas
                
    if v[categoria] > mayor:
        mayor = v[categoria]
        mejor = categoria 

    elif v[categoria] == mayor :
        mayor = mayor
        mejor = mejor
    
    v1 = {"categoria": mejor, "visitas": mayor}
                
    return v1
    
# print(obtener_categoria_con_mas_visitas(cupitube))

m_categoria = obtener_categoria_con_mas_visitas(cupitube)

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    

    for pais in cupitube:
        lista = cupitube[pais]
        
        for mini in lista: 
            x = ""
            nombre = mini["cupituber"].lower()
            pos = 0
                
            while (pos < len(nombre)) and (len(x) < 15):
                if nombre[pos] >= "a" and nombre[pos] <= "z":
                    x += nombre[pos]
                    pos += 1
                else:
                    pos += 1
            
            y = mini["started"][2:4]
            z = mini["started"][5:7]
    
            mini["correo"] = x + "." + y + z + "@cupitube.com"
    
    # print(cupitube)
    
    
crear_correo_para_cupitubers(cupitube)



# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:

    
    recomendado = {}

    
    for pais in cupitube:
        lista = cupitube[pais]
        
        for mini in lista:
            if mini["category"] == m_categoria["categoria"]:           
                   if (mini["subscribers"] >= suscriptores_min) and (mini["subscribers"] <= suscriptores_max):
                       if (mini["started"] >= fecha_minima) and (mini["started"] <= fecha_maxima):
                           if (mini["video_count"] >= videos_minimos):
                               if palabra_clave.lower() in (mini["description"]).lower():
                                   if recomendado == {}:
                                       recomendado = mini
                                   else:
                                       recomendado = recomendado
            

    return recomendado


# print(recomendar_cupituber(cupitube, 53000, 54000000, "2006-01-01", "2008-01-01", 130, "stor" ))

    
# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    d_categoria = {}

    for pais in cupitube:
        lista = cupitube[pais] 
  
        for mini in lista:      
            categoria = mini["category"]
            
            if categoria not in d_categoria:
                d_categoria[categoria] = []
                
            if pais not in d_categoria[categoria]:  
                d_categoria[categoria].append(pais)
        

    return d_categoria

# print(paises_por_categoria(cupitube))

