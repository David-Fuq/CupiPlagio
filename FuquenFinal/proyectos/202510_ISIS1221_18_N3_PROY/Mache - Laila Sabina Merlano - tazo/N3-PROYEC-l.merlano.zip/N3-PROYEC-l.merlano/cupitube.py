#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    """
    
    archivo = open(archivo, "r", encoding = "utf-8")
    archivo.readline().strip()
    datos = {}
    
    for l in archivo:
        l = l.strip()
        partes = l.split(",")

        cupituber = {
            "rank": int(partes[0]),
            "cupituber": partes[1],
            "subscribers": int(partes[2]),
            "video_views": int(partes[3]),
            "video_count": int(partes[4]),
            "category": partes[5],
            "started": partes[6],
            "country": partes[7],
            "monetization_type": partes[8],
            "description": partes[9]
        }

        pais = partes[7]
        if pais not in datos:
            datos[pais] = []
        datos[pais].append(cupituber)
        
    archivo.close()
    return datos


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
   """
    resultados = []

    for pais in cupitube:    
        for ct in cupitube[pais]:
            if ct["category"] == categoria_buscada and suscriptores_min <= ct["subscribers"] <= suscriptores_max:
               resultados.append(ct)
                
    return resultados 


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    """
    
    resultados = []
    
    if pais_buscado not in cupitube:
        return resultados #si el pais no existe
    
    for cupituber in cupitube[pais_buscado]:
        if (cupituber["category"] == categoria_buscada and cupituber ["monetization_type"] == monetizacion_buscada):
            resultados.append(cupituber)
            
    return resultados 


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    """
    
    mas_antiguo = None
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber
                
    return mas_antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    """
    

    total_vistas = 0
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"].strip().lower() == categoria_buscada.strip().lower():
                total_vistas += cupituber["video_views"]
                
    return total_vistas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    """

    vistas_por_categoria = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            
            if categoria not in vistas_por_categoria:
                vistas_por_categoria[categoria] = 0
            
            vistas_por_categoria[categoria] += visitas
        
    categoria_max = None
    visitas_max = -1
    
    for categoria, total in vistas_por_categoria.items():
        if total > visitas_max:
            visitas_max = total
            categoria_max = categoria 
            
    return {
        "categoria": categoria_max,
        "visitas":  visitas_max
    }


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    """

    for pais in cupitube:
       for cupituber in cupitube[pais]:
            nombre = "".join(c for c in cupituber["cupituber"] if c.isalnum())[:15]
            fecha = cupituber["started"]
            anio = fecha[2:4]
            mes = fecha[5:7]
            correo = (nombre + "." + anio + mes + "@cupitube.com").lower()
            cupituber["correo"] = correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    """

    categoria_top = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    palabra_clave = palabra_clave.strip().lower()

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (
            cupituber["category"] == categoria_top and
            str(suscriptores_min) <= str(cupituber["subscribers"]) <= suscriptores_max and
            str(fecha_minima) <= cupituber["started"] <= fecha_maxima and
            str(cupituber["video_count"]) >= videos_minimos and
            palabra_clave in cupituber["description"].lower()
        ):
             return cupituber
    
    return {}



# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    """

    resultado = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            if categoria not in resultado:
                resultado[categoria] = []
                
            if  pais not in resultado[categoria]:
                resultado[categoria].append(pais)
                
    return resultado








