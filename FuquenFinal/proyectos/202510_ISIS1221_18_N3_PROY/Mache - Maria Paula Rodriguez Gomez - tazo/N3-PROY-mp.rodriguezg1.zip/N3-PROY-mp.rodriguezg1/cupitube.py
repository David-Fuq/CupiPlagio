# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
"""
CupiTube
"""

#Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    dic = {}
    cupitube = open(archivo, "r", encoding="utf-8")
    linea = cupitube.readline().strip() 
    linea = cupitube.readline().strip() 

    while linea != "":
        lista = linea.split(",")
        CupiTuber_lista = []
        CupiTuber = {}
        country = lista[7]
        CupiTuber["rank"] = lista[0]
        CupiTuber["cupituber"] = lista[1]
        CupiTuber["subscribers"] = int(lista[2])
        CupiTuber["video_views"] = int(lista[3])
        CupiTuber["video_count"] = int(lista[4])
        CupiTuber["category"] = lista[5]
        CupiTuber["started"] = lista[6]
        CupiTuber["monetization_type"] = lista[8]
        CupiTuber["description"] = lista[9]
        if country in dic:
            dic[country].append(CupiTuber)
        else:
            CupiTuber_lista.append(CupiTuber)
            dic[country] = CupiTuber_lista
        linea = cupitube.readline().strip() 

    cupitube.close()
    return dic

#Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    rta = []
    
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for dic_cupituber in lista_pais:
            categoria = dic_cupituber["category"]
            if categoria == categoria_buscada:
                suscriptores = dic_cupituber["subscribers"]
                if suscriptores >= suscriptores_min and suscriptores <= suscriptores_max:
                    rta.append(dic_cupituber)
    return rta


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    rta = []
    
    for pais in cupitube:
        if pais == pais_buscado:
            lista_pais = cupitube[pais]
            for dic_cupituber in lista_pais:
                categoria = dic_cupituber["category"]
                if categoria == categoria_buscada:
                    monetizacion = dic_cupituber["monetization_type"]
                    if monetizacion == monetizacion_buscada:
                        rta.append(dic_cupituber)
    return rta

#Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    rta = {}
    year_menor = "3000-12-30"
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for dic_cupituber in lista_pais:
            year = dic_cupituber["started"]
            if year < year_menor:
                year_menor = year
                rta = dic_cupituber
          
    return rta

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    rta = 0
    
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for dic_cupituber in lista_pais:
            categoria = dic_cupituber["category"]
            if categoria == categoria_buscada:
                vistas = dic_cupituber["video_views"]
                rta += vistas
    return rta

#Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mayor = 0
    lista = []
    d = {}
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for dic_cupituber in lista_pais:
            categoria = dic_cupituber["category"]
            if categoria not in lista:
                lista.append(categoria)
    for c in lista:
        total = obtener_visitas_por_categoria(cupitube, c)
        if total > mayor:
            mayor = total
            d["categoria"] = c
            d["visitas"] = mayor 
    return d


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> dict:
    lista_max_caracteres = []
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for dic_cupituber in lista_pais:
            X = "".join((dic_cupituber["cupituber"]).split())
            Y = (dic_cupituber["started"])[2:4]
            Z = (dic_cupituber["started"])[5:7]
            for letra in X:
                if letra.isalnum()== False:
                    X = X.replace(letra,"")
            if X not in lista_max_caracteres:
                lista_max_caracteres.append(X)
            for nombre in lista_max_caracteres:
                if len(nombre) > 15:
                    X= X[0:15]     
            correo = X + "." + Y + Z + "@cupitube.com"
            dic_cupituber["correo"] = correo
    return cupitube
    

def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    rta = False
    d = {}
    lista_paises = list(cupitube.keys())  
    i = 0 
    while rta == False and i < len(lista_paises):
        pais = lista_paises[i]
        valor_pais = cupitube[pais]
        j = 0  
        while rta == False and j < len(valor_pais):
            dic_cupituber = valor_pais[j]
            categoria = (obtener_categoria_con_mas_visitas(cupitube))["categoria"]
            if dic_cupituber in (buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria)):
                if dic_cupituber["video_count"] >= videos_minimos:
                    if dic_cupituber["started"]>= fecha_minima and dic_cupituber["started"]<= fecha_maxima:
                        clave_minuscula = palabra_clave.lower()
                        descripcion = dic_cupituber["description"].lower()
                        if clave_minuscula in descripcion:
                            rta = True
                            d = dic_cupituber   
            j += 1
        i += 1
                    
    return d

def paises_por_categoria(cupitube: dict) -> dict:
    d = {}  

    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            if categoria not in d:
                d[categoria] = []
            if pais not in d[categoria]:
                d[categoria].append(pais)

    return d

