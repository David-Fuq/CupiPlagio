#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    archivo = open(archivo, "r", encoding = "utf-8")
    linea = archivo.readline()
    linea = archivo.readline().strip()
    
    cupitubers = {}
    
    while linea != "":
        lista = linea.split(",")
        
        d = {}
        
        d["rank"] = int(lista[0])
        d["cupituber"] = lista[1]
        d["subscribers"] = int(lista[2])
        d["video_views"] = int(lista[3])
        d["video_count"] = int(lista[4])
        d["category"] = lista[5]
        d["started"] = lista[6]
        d["country"] = lista[7]
        d["monetization_type"] = lista[8]
        d["description"] = lista[9]
        
        llave_pais = lista[7]
        
        if llave_pais in cupitubers:
            l = cupitubers[llave_pais] #Busca en el diccionario cupitubers el valor asociado a la clave llave_pais, y lo guarda en la variable l
            l.append(d) 
        else:
            l = [d] #estás creando una nueva lista que contiene un único elemento, y ese elemento es el diccionario d
            
        cupitubers[llave_pais] = l #en el diccionario cupitubers la llave pais va a tener como valor la lista l 
        linea = archivo.readline().strip() #.stip() para quitarle los valores como /n
        
    archivo.close()  
    return cupitubers
        
archivo = "/Users/mariafernandalozano/Desktop/N3_PROY_MF.LOZANO2/cupitube.csv"
cupitube = cargar_cupitube(archivo)


 #print(cupitubers)   

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    cumplen = []
    
    for llave_pais in cupitube:
        for d in cupitube[llave_pais]:
            categoria = d["category"]
            
            if categoria_buscada == categoria:
                suscriptores = d["subscribers"]
                
                if suscriptores >= suscriptores_min and suscriptores <= suscriptores_max:
                    cumplen.append(d)
            
    return cumplen 

x = buscar_por_categoria_y_rango_suscriptores(cupitube, 1000000, 40000000, "Education")
print(len(x))



"""
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    #TODO 2: Implemente la función tal y como se describe en la documentación.
   


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    cumplen = []
    
    for llave_pais in cupitube:
        if pais_buscado == llave_pais:
            for d in cupitube[llave_pais]:
                categoria = d["category"]
                if categoria_buscada == categoria:
                    monetizacion = d["monetization_type"]
                    if monetizacion_buscada == monetizacion:
                        cumplen.append(d) #SI SE CUMPLEN TODAS ESTAS CONDICIONES SE LE SUMA A LA LISTA EL DICCIONARIO 
    return cumplen       
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    #TODO 3: Implemente la función tal y como se describe en la documentación.
   


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    mas_antiguo = {}
    
    for llave_pais in cupitube:
        for d in cupitube[llave_pais]:
            
            if  mas_antiguo == {}:
                
                mas_antiguo = d
           
            elif d["started"] < mas_antiguo["started"]: #se usa elif porque solo evaluamos la segunda condicion si la primera no se cumple 
                
                mas_antiguo = d
                
    return mas_antiguo
            
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total_vistas = 0 
    
    for llave_pais in cupitube: #Como el diccionario cupitube tiene claves de países y cada país tiene una lista de los diccionarios de CupiTubers se tiene que recorrer todos los países y sus listas de CupiTubers para poder sacar la info de estas listas 
        for d in cupitube[llave_pais]: # cupitube[llave_pais] es la lista de CupiTubers que pertenecen a ese país específico
            categoria = d["category"]
            if categoria == categoria_buscada:
                total_vistas += d["video_views"] 
                
    return total_vistas
            
    
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    #TODO 5: Implemente la función tal y como se describe en la documentación.
   


# Función 6 REVISAR:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    categoria_max = ""
    max_vistas = 0
    
    
    
    for llave_pais in cupitube:
        for d in cupitube[llave_pais]: # d es cada uno de los diccionarios de cupitubers en el pais 
            categoria = d["category"]
            vistas = obtener_visitas_por_categoria(cupitube, categoria)
            
            if vistas > max_vistas:
                max_vistas = vistas
                categoria_max = categoria 
                
            
        
    mas_vistas = {"categoria": categoria_max, "vistas": max_vistas}  #el diccionario que voy a retornar 
    
    return mas_vistas


           

    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    #TODO 6: Implemente la función tal y como se describe en la documentación.



# Funcion 7 REVISAR:  
    
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for llave_pais in cupitube:
        for d in cupitube[llave_pais]:
            
            nombre = d["cupituber"]
            nombre_apto = "" 
            
          
            for caracteres in nombre:  
                if caracteres.isalnum():  # Si caracteres es alfanumérico es permitido 
                    nombre_apto += caracteres #se suman las letras al str vacio 

            
            
            if len(nombre_apto) > 15: #CUAND  ACABE DE REVISAR EL NOMBRE
                nombre_apto = nombre_apto[:15]
                
           
            fecha_inicio = d["started"] 
            
            anio = fecha_inicio[2:4]  
            
             
            mes = fecha_inicio[5:7]  
            
          
            correo  = nombre_apto + "." + anio + mes + "@cupitube.com"
            
         
            d["correo"] = correo.lower()  # se crea una llave en el diccionario d cuya llave es correo y su valor asignado es la variable correo



"""
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    #TODO 7: Implemente la función tal y como se describe en la documentación.
   


# Función 8 REVISAR:
    
    
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    categoria_mas_vistas = obtener_categoria_con_mas_visitas(cupitube)["categoria"] #QUIERO EL VALOR DE LA LLAVE DE CATEGORIA 
    vacio = {}
    
    cumple_categoria = False
    cumple_suscriptores = False
    cumple_videos = False
    cumple_fecha = False
    cumple_palabra = False
    
    for llave_pais in cupitube:
        for d in cupitube[llave_pais]: #ASIGNA LO SIGUIENTE EN LA CADA UNA DE LOS DICCIONARIOS DE CUPITUBERS QUE PERTENECEN A CADA PAIS 
        
                
                categoria = d["category"]
                suscriptores = int(d["subscribers"])
                videos = d["video_count"]
                fecha = d["started"]
                descripcion = d["description"]
                
                
                if categoria == categoria_mas_vistas:
                    cumple_categoria = True
                    
                if suscriptores_min < suscriptores < suscriptores_max:
                    cumple_suscriptores = True
                    
                if videos >= videos_minimos:
                    cumple_videos = True
                    
                if fecha_minima <= fecha <= fecha_maxima:
                    cumple_fecha = True
                
                if palabra_clave.lower() in descripcion.lower():
                    cumple_palabra = True
            
                if cumple_categoria == True and cumple_suscriptores == True and cumple_videos == True and cumple_fecha == True and cumple_palabra == True:
                    
                    return d 
            
        
        return vacio #SI LUEGO DE REVISAR TODOS LOS CUPITUBERS NO ENCUENTRA NADA, POR ESO ESTA ALINEADO CON EL SEGUNDO FOR
            
    
            
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #TODO 8: Implemente la función tal y como se describe en la documentación.
   


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    dic_categorias = {}
    

    for llave_pais in cupitube:
        for d in cupitube[llave_pais]: 
            categoria = d["category"]

            if categoria not in dic_categorias:
                dic_categorias[categoria] = []  # SI NO ESTA EN EL NUEVO DICCIONARIO CREA UNA LISTA VACIA. EL VALOR DE LA LLAVE CATEGORIA ES UNA LISTA VACIA 

            if llave_pais not in dic_categorias[categoria]:
                dic_categorias[categoria].append(llave_pais)
                
    return dic_categorias
    
    
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    #TODO 9: Implemente la función tal y como se describe en la documentación.
   
