"""
CupiTube
"""

def cargar_cupitube(archivo: str) -> dict:
    
    
    arch = open(archivo, "r" , encoding="utf-8")
    linea = arch.readline().strip()
    linea = arch.readline().strip()
    
    grande = {}
    
    while linea != "":
        
        lista = linea.split(",")
        mini = {}
        
        mini["rank"] = int(lista[0])
        mini["cupituber"] = lista[1]
        mini["subscribers"] = int(lista[2])
        mini["video_views"] = int(lista[3])
        mini["video_count"] = int(lista[4])
        mini["category"] = lista[5]
        mini ["started"] = lista[6]
        mini["monetization_type"] = lista[8]
        mini["description"] = lista[9]
        
        llave = lista[7]
        
        if llave not in grande:
            l= []
        else:
            l= grande[llave]
            
        l.append(mini)
        grande[llave] = l
        
        linea = arch.readline().strip()
        
    arch.close()
    return grande
    
    #print(grande)
        
    
archivo = "C:/Users/SERGIO/OneDrive - Universidad de los andes/Universidad/Quinto Semestre/IP/Módulo 3/Proyecto/cupitube.csv"
cupitube = cargar_cupitube(archivo)
        
        
    
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
   
    categoria = []
    
    for pais in cupitube.keys():
        lista = cupitube[pais]
        for cupituber in lista:
            if suscriptores_min <= cupituber["subscribers"] <= suscriptores_max and cupituber["category"] == categoria_buscada:
                
                categoria.append(cupituber)
    
    return categoria
#suscriptores_min = 1000000
#suscriptores_max = 111000000
#categoria_buscada = "Gaming"

#print(buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria_buscada))


def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    respuesta = []
    
    lista = cupitube[pais_buscado]
    for cupituber in lista:
        if categoria_buscada == cupituber["category"] and monetizacion_buscada == cupituber["monetization_type"]:
                respuesta.append(cupituber)
    return respuesta

#pais_buscado = "UK"
#categoria_buscada = "Gaming"
#monetizacion_buscada = "Crowdfunding"

#print(buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais_buscado, categoria_buscada, monetizacion_buscada))

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    mas_viejo = "2025/04/28"
    respuesta = {}
    
    for pais in cupitube.keys():
        lista = cupitube[pais]
        for cupituber in lista:
            if cupituber["started"] < mas_viejo:
                respuesta = cupituber
                mas_viejo = cupituber["started"]
    return respuesta

#print(buscar_cupituber_mas_antiguo(cupitube))
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
  
   respuesta = 0
   for pais in cupitube.keys():
       lista = cupitube[pais]
       for cupituber in lista:
           if categoria_buscada == cupituber["category"]:
               respuesta += cupituber["video_views"]
   return respuesta
#categoria_buscada = "Music"
#print(obtener_visitas_por_categoria(cupitube, categoria_buscada))


def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    respuesta = []
    mayor = {"categoria":"", "vistas_totales":0}
    for pais in cupitube.keys():
        lista = cupitube[pais]
        
        for cupituber in lista:
            if cupituber["category"] not in respuesta:
                respuesta.append(cupituber["category"])
        
    for categoria in respuesta:
        visitas = obtener_visitas_por_categoria(cupitube, categoria)
        if visitas > mayor["vistas_totales"]:
            mayor["categoria"] = categoria
            mayor["vistas_totales"] = visitas
    return mayor
#print(obtener_categoria_con_mas_visitas(cupitube))   


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    #TODO 7: Implemente la función tal y como se describe en la documentación.
    pass


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    pass


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    #TODO 9: Implemente la función tal y como se describe en la documentación.
    pass
