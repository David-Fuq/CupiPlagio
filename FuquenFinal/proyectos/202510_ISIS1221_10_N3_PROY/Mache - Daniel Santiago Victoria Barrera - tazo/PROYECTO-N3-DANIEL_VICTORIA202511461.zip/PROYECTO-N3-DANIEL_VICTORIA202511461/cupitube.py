#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    datos = {}
    archivo_csv = open(archivo, "r", encoding="utf-8")
    
    archivo_csv.readline()  
    
    linea = archivo_csv.readline()
    
    while linea != "":
        partes = linea.strip().split(",")
        cupituber = {
            "rank": int(partes[0]),
            "cupituber": partes[1],
            "subscribers": int(partes[2]),
            "video_views": int(partes[3]),
            "video_count": int(partes[4]),
            "category": partes[5],
            "started": partes[6],
            "country": partes[7],
            "monetization_type": partes[8],  
            "description": partes[9]
        }
        pais = cupituber["country"]
        if pais not in datos:
            datos[pais] = []
        datos[pais].append(cupituber)
        
        linea = archivo_csv.readline()
        
    archivo_csv.close()
    return datos
    
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    resultado = []
    
    for pais in cupitube:
        lista_cupitubers = cupitube [pais]
        for cupituber in lista_cupitubers:
            if (cupituber["category"] == categoria_buscada and suscriptores_min <= cupituber["subscribers"] <= suscriptores_max):
                    resultado.append(cupituber)
    return resultado   
  
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []

    if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]
        for cupituber in lista_cupitubers:
            if (cupituber["category"] == categoria_buscada and
                cupituber["monetization_type"] == monetizacion_buscada):
                resultado.append(cupituber)

    return resultado

 
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    primero = True
    mas_antiguo = {}
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            if primero:
                mas_antiguo = cupituber
                primero = False
            elif cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber
                
    return mas_antiguo
    
# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total_visitas = 0
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            if cupituber["category"] == categoria_buscada:
                total_visitas = total_visitas + cupituber ["video_views"]
                
    return total_visitas
 
# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    visitas_por_categoria = {}
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            
            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = visitas
            else:
                visitas_por_categoria[categoria] = visitas_por_categoria[categoria] + visitas
                
    categoria_maxima = ""
    visitas_maximas = 0
    
    for categoria in visitas_por_categoria:
        if visitas_por_categoria[categoria] > visitas_maximas:
            visitas_maximas = visitas_por_categoria[categoria]
            categoria_maxima = categoria 
    
    resultado = {}
    resultado["categoria"] = categoria_maxima
    resultado["visitas"] = visitas_maximas
    
    return resultado
  
# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            nombre= cupituber["cupituber"].lower()
            
            nombre_correo = ""
            caracteres = 0
            for caracter in nombre:
                if caracter.isalnum():
                    if caracteres < 15:
                        nombre_correo += caracter
                        caracteres += 1
                        
            fecha = cupituber["started"]
            anio = fecha[0:4]
            mes = fecha[5:7]
            dos_digitos_anio = anio[2:4]
            
            correo = nombre_correo + "." + dos_digitos_anio + mes + "@cupitube.com"
            
            cupituber["correo"] = correo
            
# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int,fecha_minima: str, fecha_maxima: str, videos_minimos: int,palabra_clave: str) -> dict:

    resultado = obtener_categoria_con_mas_visitas(cupitube)
    categoria_mas_visitas = resultado["categoria"]

    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            cantidad_videos = cupituber["video_count"]
            fecha = cupituber["started"]
            descripcion = cupituber["description"]

            if (categoria == categoria_mas_visitas and
                suscriptores_min <= suscriptores <= suscriptores_max and
                cantidad_videos >= videos_minimos and
                fecha_minima <= fecha <= fecha_maxima and
                palabra_clave.lower() in descripcion.lower()):
                return cupituber

    return {}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    resultado = {}
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            if categoria not in resultado:
                resultado[categoria] = []
            if pais not in resultado[categoria]:
                resultado[categoria].append(pais)
                
    return resultado
  