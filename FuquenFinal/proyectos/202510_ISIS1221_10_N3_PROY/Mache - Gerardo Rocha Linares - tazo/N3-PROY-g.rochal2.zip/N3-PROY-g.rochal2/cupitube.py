#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitubers={}
    archivo=open(archivo, "r", encoding="utf-8")
    titulos= archivo.readline().strip()
    for cada_linea in archivo:
        datos=cada_linea.strip().split(",")
        if len(datos)==10:
            cupituber={"rank":int(datos[0]),
                       "cupituber":datos[1],
                       "subscribers":int(datos[2]),
                       "video_views":int(datos[3]),
                       "video_count":int(datos[4]),
                       "category":datos[5],
                       "started":datos[6],
                       "monetization_type":datos[8],
                       "description":datos[9]}  
            pais=datos[7].strip()
            if pais not in cupitubers:
               cupitubers[pais]=[]
            cupitubers[pais].append(cupituber)
    return cupitubers


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    cumple=[]
    for cupitubers in cupitube.values():
        for cada_cupituber in cupitubers:
            if categoria_buscada.lower() ==cada_cupituber["category"].lower() and suscriptores_min<=cada_cupituber["subscribers"] and suscriptores_max>=cada_cupituber["subscribers"]:
                cumple.append(cada_cupituber)
    return cumple
cupitube=cargar_cupitube("cupitube.csv")




# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cumple = []
    for pais in cupitube.keys():
        if pais.lower() == pais_buscado.lower():
            cupitubers = cupitube[pais]
            for cada_cupituber in cupitubers:
                if categoria_buscada.lower() == cada_cupituber["category"].lower() and monetizacion_buscada.lower() == cada_cupituber["monetization_type"].lower():
                    cumple.append(cada_cupituber) 
    return cumple
cupitube=cargar_cupitube("cupitube.csv")

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    cupituber_mas_antiguo = None
    año_mas_antiguo = 2025
    mes_mas_antiguo = 12
    dia_mas_antiguo = 31
    for cupitubers in cupitube.values():
        for cada_cupituber in cupitubers:
            fecha_inicio = cada_cupituber["started"]
            fecha_partes = fecha_inicio.split("-")
            año = int(fecha_partes[0])
            mes = int(fecha_partes[1])
            dia = int(fecha_partes[2])
            if año < año_mas_antiguo:
                año_mas_antiguo = año
                mes_mas_antiguo = mes   
                dia_mas_antiguo = dia
                cupituber_mas_antiguo = cada_cupituber
            elif año == año_mas_antiguo:
                if mes < mes_mas_antiguo:
                    mes_mas_antiguo = mes
                    dia_mas_antiguo = dia
                    cupituber_mas_antiguo = cada_cupituber
                elif mes == mes_mas_antiguo: 
                    if dia < dia_mas_antiguo:
                        dia_mas_antiguo = dia
                        cupituber_mas_antiguo = cada_cupituber
    
    return cupituber_mas_antiguo
cupitube=cargar_cupitube("cupitube.csv")

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total=0
    for cupitubers in cupitube.values():
        for cada_cupituber in cupitubers:
            if categoria_buscada.lower()==cada_cupituber["category"].lower():
                total+=cada_cupituber["video_views"]
                
    return total  
cupitube=cargar_cupitube("cupitube.csv")


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categorias_visitas = {}
    for cupitubers in cupitube.values():
        for cada_cupituber in cupitubers:
            categoria = cada_cupituber["category"]
            visitas = cada_cupituber["video_views"]
            if categoria in categorias_visitas:
                categorias_visitas[categoria] += visitas
            else:
                categorias_visitas[categoria] = visitas
    categoria_maxima = max(categorias_visitas, key=categorias_visitas.get)
    
    return {"categoria": categoria_maxima, "visitas": categorias_visitas[categoria_maxima]}
cupitube=cargar_cupitube("cupitube.csv")




# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    fin = "@cupitube.com"
    caracteres_especiales = [' ', '.', ',', '-', '_', '@', '!', '?', '(', ')', '[', ']', '{', '}', ':', ';', '%', '^', '&', '*', '+', '=', '#', '$', '"', "'", '\\', '/', '<', '>']
    
    for cupitubers in cupitube.values():
        for cada_cupituber in cupitubers:
            nombre = cada_cupituber["cupituber"]
            nombre_sin_nada= ""
            for letra in nombre:
                if letra not in caracteres_especiales:
                    nombre_sin_nada += letra
            nombre_sin_nada = nombre_sin_nada[:15]
            fecha_inicio = cada_cupituber["started"]
            año, mes, _ = fecha_inicio.split("-")
            año = año[2:]
            if len(mes) == 1:
                mes = "0" + mes
            correo = nombre_sin_nada + año + mes + fin
            cada_cupituber["correo"] = correo.lower()
    
    return cupitube
    
    #TODO 7: Implemente la función tal y como se describe en la documentación.


# Función 8:
'''
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:



    #TODO 8: Implemente la función tal y como se describe en la documentación.
    

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    #TODO 9: Implemente la función tal y como se describe en la documentación.
    pass
'''