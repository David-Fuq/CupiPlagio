#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
#Diccionario mayor
    diccionario_mayor_cupitubers = {}
    archivo = open(archivo, "r", encoding="utf-8")
    titulos = archivo.readline().split(",")
    
    linea = archivo.readline()
    while linea != "":
        datos = linea.split(",")       
#Llave:
        pais_cupituber = datos[7]       
    
#Diccionario menor
        info_cupitubers = {}
        info_cupitubers["rank"] = datos[0]
        info_cupitubers["cupituber"] = datos[1]
        info_cupitubers["subscribers"] = datos[2]
        info_cupitubers["video_views"] = datos[3]
        info_cupitubers["video_count"] = datos[4]
        info_cupitubers["category"] = datos[5]
        info_cupitubers["started"] = datos[6]
        info_cupitubers["country"] = datos[7]
        info_cupitubers["monetization_type"] = datos[8]
        info_cupitubers["description"] = datos[9]
        
#si el PAIS no está en DICCIONARIO MAYOR
#el PAIS se añade al diccionario con una LISTA vacía

        if pais_cupituber not in diccionario_mayor_cupitubers:
                diccionario_mayor_cupitubers[pais_cupituber] = []

#al DICCIONARIO MAYOR con la llave PAISa la LISTA vacía se .append el DICCIONARIO MENOR                               
        diccionario_mayor_cupitubers[pais_cupituber].append(info_cupitubers)
        
        linea = archivo.readline()
        
    archivo.close()
    return diccionario_mayor_cupitubers

diccionario_mayor_cupitubers = cargar_cupitube("cupitube.csv")

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    lista_cumplen = []
    
#Recorrer cada país en el diccionario
    for country in cupitube:

 #Recorrer cada Cupituber del país
        for cada_cupituber in cupitube[country]:
            
            suscriptores = int(cada_cupituber["subscribers"])
            menor_cantidad = suscriptores >= suscriptores_min
            mayor_cantidad = suscriptores <= suscriptores_max
            
            if cada_cupituber["category"] == categoria_buscada and menor_cantidad and mayor_cantidad:
                lista_cumplen.append(cada_cupituber)
                   
    return lista_cumplen


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    lista_cupitubers_por_pais_categoria_monetizacion = []
    
    for country in cupitube:

        for cada_cupituber in cupitube[country]:
            
            pais = cada_cupituber["country"].lower()
            categoria = cada_cupituber["category"]
            monetizacion = cada_cupituber["monetization_type"]
            
            if pais == pais_buscado and categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                lista_cupitubers_por_pais_categoria_monetizacion.append(cada_cupituber)
                  
    return lista_cupitubers_por_pais_categoria_monetizacion


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
 
    cupituber_mas_antiguo = ""
    
    for country in cupitube:
        
        for cada_cupituber in cupitube[country]:
  
            if cupituber_mas_antiguo == "":
                cupituber_mas_antiguo = cada_cupituber
                
            if cada_cupituber["started"] < cupituber_mas_antiguo["started"]:
                cupituber_mas_antiguo = cada_cupituber
                    

    return cupituber_mas_antiguo 
      

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total = 0
    
    for country in cupitube:
        
        for cada_cupituber in cupitube[country]:
            
            if cada_cupituber["category"] == categoria_buscada:
                visitas = int(cada_cupituber["video_views"])
                total += visitas
                
    return total


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    categoria_con_mas_visitas = {}
    categorias_revisadas = {}
    
    
    
    for country in cupitube:
#diccionario menor
        for cada_cupituber in cupitube[country]:
            
            categoria = cada_cupituber["category"]
            visitas = int(cada_cupituber["video_views"])
                      
            if categoria not in categorias_revisadas:
                categorias_revisadas[categoria] = visitas
                
            else:
                categorias_revisadas[categoria] += visitas
                
    mayor_visitas = 0
    mayor_categoria = ""

#diccionario mayor
#recorrer cada categoría en categorias_revisadas
    for categoria in categorias_revisadas:
            
            visitas = categorias_revisadas[categoria]
   
            if visitas > mayor_visitas:
                mayor_visitas = visitas
                mayor_categoria = categoria
                
                categoria_con_mas_visitas["categoria"] = mayor_categoria
                categoria_con_mas_visitas["visitas"] = mayor_visitas
                

    return categoria_con_mas_visitas
 

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
#[X].[Y][Z]@cupitube.com 

    for country in cupitube:
        
        for cada_cupituber in cupitube[country]:
            X = ""
            nombre_cupituber = cada_cupituber["cupituber"]

            for cada_caracter in nombre_cupituber:
                if cada_caracter.isalnum():
                    X += cada_caracter

            X = X[0:15]
            Y = cada_cupituber["started"][2:3 + 1]
            Z = cada_cupituber["started"][5:6 + 1]

            correo_armado = (str(X) + "." + str(Y) + str(Z) + "@cupitube.com").lower()

            cada_cupituber["correo"] = correo_armado  

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    categoria_mas_vistas = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    p_clave = palabra_clave.lower() 
    
    for country in cupitube:
        
        for cada_cupituber in cupitube[country]:
            
            cumple = True
            
            categoria = cada_cupituber["category"]
            suscriptores = int(cada_cupituber["subscribers"])
            cantidad_videos = int(cada_cupituber["video_count"])
            cupituber_descripcion = cada_cupituber["description"].lower()
            fecha = cada_cupituber["started"]       
    
            
            if categoria != categoria_mas_vistas:
                cumple = False
                
            if suscriptores < suscriptores_min or suscriptores > suscriptores_max:
                cumple = False
                
            if cantidad_videos < videos_minimos:
                cumple = False
                
            if fecha < fecha_minima or fecha > fecha_maxima:
                cumple = False
                
            if p_clave not in cupituber_descripcion:
                cumple = False
                
            if cumple == True:
                return cada_cupituber
            
            if cumple == False:
                return {}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    diccionario_paises = {}
    
#diccionario_paises ["llave"] = valor
#diccionario_paises ["category"] = paises
    
    for country in cupitube:
        
        for cada_cupituber in cupitube[country]:
            
            categoria = cada_cupituber["category"]
            pais = cada_cupituber["country"]
            
            if categoria not in diccionario_paises:
                diccionario_paises[categoria] = []
                
            if categoria in diccionario_paises and pais not in diccionario_paises[categoria]:
                diccionario_paises[categoria].append(pais)
                

    return diccionario_paises