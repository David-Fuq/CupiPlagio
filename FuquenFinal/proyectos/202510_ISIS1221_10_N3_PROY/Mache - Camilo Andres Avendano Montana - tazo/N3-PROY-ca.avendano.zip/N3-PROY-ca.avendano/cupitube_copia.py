#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    pais_cupitube = {}
    cargar_archivo = open(archivo, "r", encoding="utf-8")
    titulos = cargar_archivo.readline()
    print(titulos)

    
    linea = cargar_archivo.readline().strip()
    
    while len(linea) > 0:
        
        datos = linea.split(",")      
        pais_cupitube_llave = datos[7]
        
        diccionario_cupitube = {}
        diccionario_cupitube["cupituber"] = datos[1]
        diccionario_cupitube["rank"] = datos[0]
        diccionario_cupitube["subscribers"] = datos[2]
        diccionario_cupitube["video_views"] = datos[3]
        diccionario_cupitube["video_count"] = datos[4]
        diccionario_cupitube["category"] = datos[5]
        diccionario_cupitube["started"] = datos[6]
        diccionario_cupitube["monetization_type"] = datos[8]
        diccionario_cupitube["description"] = datos[9]
        
        linea = cargar_archivo.readline().strip()
               
        if pais_cupitube_llave in pais_cupitube:
           pais_cupitube[pais_cupitube_llave].append(diccionario_cupitube)
    
        else:
          pais_cupitube[pais_cupitube_llave] = [diccionario_cupitube]
            
    cargar_archivo.close()
            
    return pais_cupitube

cupitubers = cargar_cupitube("cupitube.csv")

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    
    lista_buscar_cupituber = []
    

    
    for i in cupitube:
        
        for cada_cupituber in cupitube[i]:
               
           if (categoria_buscada == cada_cupituber["category"]) and (int(cada_cupituber["subscribers"]) >= suscriptores_min) and (int(cada_cupituber["subscribers"]) <= suscriptores_max):
               lista_buscar_cupituber.append(cada_cupituber)
               
             
               
            
    return lista_buscar_cupituber



# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    lista_buscar_cupituber = []
    
    for pais in cupitube:
        
        if (pais_buscado == pais):
            
            for cada_cupituber in cupitube[pais]:
                
                if (categoria_buscada == cada_cupituber["category"]) and (monetizacion_buscada == cada_cupituber["monetization_type"]):
                    
                    lista_buscar_cupituber.append(cada_cupituber)
                    
    return lista_buscar_cupituber

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    antiguo = None
    
    fecha = "9999-12-31"
    
    for pais in cupitube:
        
        for cada_cupituber in cupitube[pais]:
            
            if (cada_cupituber["started"] < fecha):
                
                fecha = cada_cupituber["started"]
                
                antiguo = cada_cupituber
                
                
    return antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    suma = 0
    
    for pais in cupitube:
        
        for cada_cupituber in cupitube[pais]:
            
            if (categoria_buscada == cada_cupituber["category"]):
                
                suma += int(cada_cupituber["video_views"])
                
    return suma

    
# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    categoria_mayor = {}
    
    resultado = {}
    
    categoria_asignada = ""
    
    mas_vistas = 0
    
    for pais in cupitube:
        
        for cada_cupituber in cupitube[pais]:
            
            categoria = cada_cupituber["category"]
            
            if categoria not in categoria_mayor: 
                
                categoria_mayor[categoria] = obtener_visitas_por_categoria(cupitube, categoria)
                
    for categoria in categoria_mayor:
        
        if categoria_mayor[categoria] > mas_vistas:
            
            mas_vistas = categoria_mayor[categoria] 
            
            categoria_asignada = categoria
            
    resultado["categoria"] = categoria_asignada
    
    resultado["vistas"] = mas_vistas
            
    return resultado
    
# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    correo_cupituber = ""
    
    for pais in cupitube:
        
        for cada_cupituber in cupitube[pais]:
            
            nombre_cupituber = cada_cupituber["cupituber"][0:15].lower()
            
            anio_cupituber = cada_cupituber["started"][2:4]
            
            mes_cupituber = cada_cupituber["started"][5:7]
            
            nombre_sin_especiales = ""
           
            for cada_caracter in nombre_cupituber:
                
                if cada_caracter.isalnum():
                    
                    nombre_sin_especiales += cada_caracter
                    
            correo_cupituber = nombre_sin_especiales + "." + anio_cupituber + mes_cupituber + "@cupitube.com"
             
            cada_cupituber["correo"] = correo_cupituber
            
    print(crear_correo_para_cupitubers(cupitubers))
 
# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    cupituber_dic = {}
    
    categoria_mayor = obtener_categoria_con_mas_visitas(cupitube)
    
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:         
            if (palabra_clave.lower() in cada_cupituber["description"].lower()) and (int(cada_cupituber["subscribers"]) >= suscriptores_min) and (int(cada_cupituber["subscribers"]) <= suscriptores_max) and (cada_cupituber["started"] >= fecha_minima) and (cada_cupituber["started"] <= fecha_maxima) and (int(cada_cupituber["video_count"]) >= videos_minimos) and (cada_cupituber["category"] == categoria_mayor["categoria"]): 
                
                return cada_cupituber
                                          
    return cupituber_dic

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    dic_categoria = {}
    
    for pais in cupitube:
        
        for cada_cupituber in cupitube[pais]:
            
            categoria = cada_cupituber["category"]
            
            if categoria not in dic_categoria:
                
                dic_categoria[categoria] = [pais]
                
            elif pais not in dic_categoria[categoria]:
                dic_categoria[categoria].append(pais)
                
    return dic_categoria


            
