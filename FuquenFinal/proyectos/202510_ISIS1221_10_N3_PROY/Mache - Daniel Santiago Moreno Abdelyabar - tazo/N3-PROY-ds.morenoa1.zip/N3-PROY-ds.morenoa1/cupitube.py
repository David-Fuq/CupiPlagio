"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo:str)->dict:
    dic_cupitube={}
    archivo=open(archivo,"r",encoding="utf-8")
    archivo.readline()
    for linea in archivo:
        datos=linea.strip().split(",")
        cupituber={
                   "rank":int(datos[0]),
                   "cupituber":datos[1],
                   "subscribers":int(datos[2]),
                   "video_views":int(datos[3]),
                   "video_count":int(datos[4]),
                   "category":datos[5],
                   "started":datos[6],
                   "monetization_type":datos[8],
                   "description":datos[9]
                   }
        country=datos[7]
        if country not in dic_cupitube:
            dic_cupitube[country]=[]
        dic_cupitube[country].append(cupituber)
    archivo.close()
    return dic_cupitube    
            
    
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube:dict,suscriptores_min:int,suscriptores_max:int,categoria_buscada:str)->list:
    cupitubers_que_cumplen=[]
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            if cupituber["subscribers"]>=suscriptores_min and cupituber["subscribers"]<=suscriptores_max and cupituber["category"]==categoria_buscada:
                cupitubers_que_cumplen.append(cupituber)
    return cupitubers_que_cumplen
      
         
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube:dict,pais_buscado:str,categoria_buscada:str,monetizacion_buscada:str)->list:
    cupitubers_que_cumplen=[]
    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if categoria_buscada==cupituber["category"]:
                if monetizacion_buscada==cupituber["monetization_type"]:
                    cupitubers_que_cumplen.append(cupituber)
    return cupitubers_que_cumplen


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube:dict)->dict:
    cupituber_que_cumple={}
    fecha="2025-04-30"
    for lista in cupitube.values():
        for cupituber in lista:
            if cupituber["started"]<fecha:
                cupituber_que_cumple=cupituber
                fecha=cupituber["started"]
    return cupituber_que_cumple


# Función 5:
def obtener_visitas_por_categoria(cupitube:dict,categoria_buscada:str)->int:
    visitas_totales=0
    for lista in cupitube.values():
        for cupituber in lista:
            if categoria_buscada==cupituber["category"]:
                visitas_totales=visitas_totales+cupituber["video_views"]
    return visitas_totales
            

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube:dict)->dict:
    mayor_visitas=0
    categoria_mayor={}
    for lista in cupitube.values():
        for cupituber in lista:
            categoria=cupituber["category"]
            visitas=obtener_visitas_por_categoria(cupitube,categoria)
            if visitas>mayor_visitas:
                mayor_visitas=visitas
                categoria_mayor["categoria"]=categoria
                categoria_mayor["visitas"]=visitas                    
    return categoria_mayor
                

# Funcion 7:
def crear_correo_para_cupitubers(cupitube:dict)->None:
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            nombre=cupituber["cupituber"]
            x=""
            for letra in nombre:
                if letra.isalnum():
                    x+=letra.lower()
            x=x[0:15]
            fecha=cupituber["started"]
            y=fecha[2:4]
            z=fecha[5:7]
            correo=x+"."+y+z+"@cupitube.com"
            cupituber["correo"]=correo
        

# Función 8:
def recomendar_cupituber(cupitube:dict,suscriptores_min:int,suscriptores_max:int,fecha_minima:str,fecha_maxima:str,videos_minimos:int,palabra_clave:str)->dict:
    categoria_mas_visitas=obtener_categoria_con_mas_visitas(cupitube)
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if cupituber["category"]==categoria_mas_visitas["categoria"]: 
                if suscriptores_min<=cupituber["subscribers"]<=suscriptores_max:
                    if cupituber["video_count"]>=videos_minimos:
                        if fecha_minima<=cupituber["started"]<=fecha_maxima:
                            if palabra_clave.lower() in cupituber["description"].lower():
                                return cupituber
    return {}
                         
       
# Función 9:
def paises_por_categoria(cupitube:dict)->dict:
    dic_paises_por_categoria={}
    for pais,cupitubers in cupitube.items():
        for cupituber in cupitubers:
            categoria=cupituber["category"]
            if categoria not in dic_paises_por_categoria:
                dic_paises_por_categoria[categoria]=[]
            if pais not in dic_paises_por_categoria[categoria]:
                dic_paises_por_categoria[categoria].append(pais)
    return dic_paises_por_categoria
