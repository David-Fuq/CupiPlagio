#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube

"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitubers = {}
    data = open(archivo, "r", encoding="utf-8")
    titulos = data.readline().strip().split(",")
    print(titulos)
    
    linea = data.readline().strip()
    while linea != "":
        datos = linea.split(",")
        pais = {}
        for i in range(len(titulos)):
            pais[titulos[i]] = datos[i]
        if datos[7] not in cupitubers:
            cupitubers[datos[7]] = []
            cupitubers[datos[7]].append(pais)
        else:
            cupitubers[datos[7]].append(pais)
        linea = data.readline().strip()
    data.close()
    return cupitubers
     
    #TODO 1: Implemente la función tal y como se describe en la documentación.


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, subscriptores_min: int, subscriptores_max: int, categoria_buscada: str) -> list:
    cumple_respuesta = []
    for cada_pais in cupitube:
        for cada_cupituber in cupitube[cada_pais]:
            if int(subscriptores_min) <= int(cada_cupituber["subscribers"]) <= int(subscriptores_max) and cada_cupituber["category"] == categoria_buscada:
                cumple_respuesta.append(cada_cupituber)
    return cumple_respuesta
    
    #TODO 2: Implemente la función tal y como se describe en la documentación.


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cumple_criterio = []    
    for cada_cupituber in cupitube[pais_buscado]:
        if cada_cupituber["category"] == categoria_buscada and cada_cupituber["monetization_type"] == monetizacion_buscada:
            cumple_criterio.append(cada_cupituber)
    return cumple_criterio
        
    #TODO 3: Implemente la función tal y como se describe en la documentación.

    
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = []
    menor_fecha = 999999999999999999999999999999
    fecha_dias = ""
    fecha_dias1 = 0
    
    for cada_pais in cupitube:
        for cada_cupituber in cupitube[cada_pais]:
            fecha_dias = cada_cupituber["started"].split("-")
            fecha_dias1 = int(fecha_dias[0])*365 + int(fecha_dias[1])*30 + int(fecha_dias[2])
            if fecha_dias1 < menor_fecha:
                mas_antiguo = [cada_cupituber]
                menor_fecha = fecha_dias1
    return mas_antiguo

    #TODO 4: Implemente la función tal y como se describe en la documentación.
        

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    views_acum = 0
    for cada_pais in cupitube:
        for cada_cupituber in cupitube[cada_pais]:
               if cada_cupituber["category"] == categoria_buscada:
                   views_acum += int(cada_cupituber["video_views"]) 
    return views_acum

    #TODO 5: Implemente la función tal y como se describe en la documentación.


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mayorv_cup = 0
    respuesta = {}
    for cada_pais in cupitube:
        for cada_cupituber in cupitube[cada_pais]:
            if mayorv_cup < int(cada_cupituber["video_views"]):
                mayorv_cup = int(cada_cupituber["video_views"])
                respuesta = {"category": cada_cupituber["category"],
                             "video_views": obtener_visitas_por_categoria(cupitube, cada_cupituber["category"])}
    return respuesta

    #TODO 6: Implemente la función tal y como se describe en la documentación.


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for cada_pais in cupitube:
        for cada_cupituber in cupitube[cada_pais]:
            fecha_cupi = list(cada_cupituber["started"]) 
            x = list(cada_cupituber["cupituber"])
            for cada_caracter in x:
              if not cada_caracter.isalnum() or cada_caracter == " " or cada_caracter == "":
                  x.remove(cada_caracter)  
            if len(x) > 15:
                x = x[0:15]
            y = fecha_cupi[2:4]
            z = fecha_cupi[5:7]
                     
            cada_cupituber["correo"] = "".join(x).lower() +  "." + "".join(y) + "".join(z) + "@cupitube.com"
    return cupitube

    #TODO 7: Implemente la función tal y como se describe en la documentación.


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    no_encontrado = True
    while no_encontrado:
        for casa_pais in cupitube:
            for cada_cupituber in cupitube[casa_pais]:
                if suscriptores_min <= int(cada_cupituber["subscribers"]) <= suscriptores_max:
                    if fecha_minima <= cada_cupituber["started"] <= fecha_maxima:
                        if videos_minimos <= int(cada_cupituber["video_count"]):
                            if palabra_clave.lower() in ("".join(cada_cupituber["description"])).lower():
                                if no_encontrado:
                                    no_encontrado = False
                                    respuesta = cada_cupituber
    return respuesta
    
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    nuevo_dic = {}

    for cada_pais in cupitube:
        for cada_cupituber in cupitube[cada_pais]:
                if not cada_cupituber["category"] in nuevo_dic:
                    nuevo_dic[cada_cupituber["category"]] = []
                if cada_cupituber["country"] not in nuevo_dic[cada_cupituber["category"]]:
                    nuevo_dic[cada_cupituber["category"]].append(cada_cupituber["country"])

    return nuevo_dic

    #TODO 9: Implemente la función tal y como se describe en la documentación.

