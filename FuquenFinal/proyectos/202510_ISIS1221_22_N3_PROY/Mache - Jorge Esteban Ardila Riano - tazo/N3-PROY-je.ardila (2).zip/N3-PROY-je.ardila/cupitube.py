#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    cupitube = {}
    archivo = open(archivo,"r", encoding="utf-8")
    titulos = archivo.readline().strip()

    linea = archivo.readline().strip()
    
    while len(linea) > 0:
        datos = linea.split(",")
        pais = datos[7]
        
        info_cupitube = {}
        info_cupitube["rank"] = int(datos[0])
        info_cupitube["cupituber"] = str(datos[1])
        info_cupitube["subscribers"] = int(datos[2])
        info_cupitube["video_views"] = int(datos[3])
        info_cupitube["video_count"] = int(datos[4])
        info_cupitube["category"] = str(datos[5])
        info_cupitube["started"] =  str(datos[6])
        info_cupitube["monetization_type"] =  str(datos[8])
        info_cupitube["description"] =  str(datos[9])
        
        if pais not in cupitube:
            cupitube[pais] = []
        cupitube[pais].append(info_cupitube)
            
        linea = archivo.readline()

    archivo.close()
    return cupitube

cupitube = cargar_cupitube("cupitube.csv")



# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
   
    nl = []
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if suscriptores_min <= cupituber["subscribers"] <= suscriptores_max and cupituber["category"] == categoria_buscada:
                nl.append(cupituber)
                
    return nl
    
    

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    nl = []
    
    for cupituber in cupitube[pais_buscado]:
        if cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
           nl.append(cupituber)
    
    return nl



# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    cma = cupitube["Argentina"][0]["started"]
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["started"] < cma:
                cma = cupituber["started"]
                resp = cupituber
                
    return resp
            


# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
   
    resp = 0
    
    for pais in cupitube: 
        for cupituber in cupitube[pais]:
            if cupituber["category"] == categoria_buscada:
                resp += cupituber["video_views"]
                
    return resp
                


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
   
    d = {}
    visitas = 0
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if  visitas < cupituber["video_views"]:
                visitas = cupituber["video_views"]
                d[cupituber["category"]] = cupituber["video_views"]
            
    return d

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    #TODO 7: Implemente la función tal y como se describe en la documentación.
    


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    d = {}
    encontro = False    
    categoria = obtener_categoria_con_mas_visitas(cupitube)
    categoria_con_mas_visitas = list(categoria.keys())[0]
    
    while encontro == False: 
        for pais in cupitube:    
            for cupituber in cupitube[pais]: 
                if (cupituber["category"] == categoria_con_mas_visitas) and (suscriptores_min <= cupituber["subscribers"] <= suscriptores_max) and (fecha_minima <= cupituber["started"] <= fecha_maxima) and (cupituber["video_count"] >= videos_minimos) and (palabra_clave.lower() in cupituber["description"].lower()):  
                    d = cupituber
                    encontro = True
                    
    return d
                


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
   
    d = {}
    
    for pais in cupitube:  
        for cupituber in cupitube[pais]:
           categoria = cupituber["category"]
           if categoria not in d:
                d[categoria] = []
           if pais not in d[categoria]:
                d[categoria].append(pais)

    return d


