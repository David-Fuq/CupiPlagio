#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    
    Parámetros:
        archivo (str): Ruta del archivo CSV con la información de los CupiTubers, incluyendo la extensión.
                       Ejemplo: "./cupitube.csv" (si el archivo CSV está en el mismo directorio que este archivo).
    
    Retorno:
        dict: Diccionario estructurado de la siguiente manera:
            
            - Las llaves representan los países de donde provienen los CupiTubers.
              - El país de origen de un CupiTuber se encuentra en la columna "country" del archivo CSV.
              - El país es un string no vacío, sin espacios al inicio o al final.
                Ejemplo: "India"
            
            - Los valores son listas de diccionarios, donde cada diccionario representa un CupiTuber. 
              - Cada diccionario contiene los siguientes campos basados en las columnas del archivo CSV:
    
                "rank" (int): Ranking del CupiTuber en el mundo. Es un valor entero mayor a cero.
                              Ejemplo: 1
    
                "cupituber" (str): Nombre del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                   Ejemplo: "T-Series"
    
                "subscribers" (int): Cantidad de suscriptores del CupiTuber. Es un valor entero mayor a cero.
                                     Ejemplo: 222000000
    
                "video_views" (int): Cantidad de visitas de todos los videos del CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 198459090822
    
                "video_count" (int): Cantidad de videos publicados por el CupiTuber. Es un valor entero mayor o igual a cero.
                                     Ejemplo: 17317
    
                "category" (str): Categoría principal de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                  Ejemplo: "Music"
    
                "started" (str): Fecha en la que el CupiTuber empezó a publicar videos en formato YYYY-MM-DD.
                                Es un string no vacío, sin espacios al inicio o al final.
                                Ejemplo: "2006-11-15"
    
                "monetization_type" (str): Tipo de monetización de los videos del CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                           Ejemplo: "AdSense"
    
                "description" (str): Descripción del tipo de videos que publica el CupiTuber. Es un string no vacío, sin espacios al inicio o al final.
                                     Ejemplo: "Amazing travel vlogs worldwide!"
    
    Notas importantes:
        1. Al usar readline(), agregue strip() de esta forma: readline().strip() para garantizar que se eliminen los saltos de línea.
            Documentación de str.strip(): https://docs.python.org/es/3/library/stdtypes.html#str.strip
            Documentación de readline(): https://docs.python.org/es/3/tutorial/inputoutput.html#methods-of-file-objects
            
        2. Al usar open(), agregue la codificación "utf-8" de esta forma: open(archivo, "r", encoding="utf-8") para garantizar la lectura de caracteres especiales del archivo CSV.
    """
    cupitubers = {}
    archivo = open(archivo, "r", encoding="utf-8")
    archivo.readline()  

    linea = archivo.readline().strip() #lee linea por linea

    while len(linea) > 0:
        datos = linea.split(",")

        cupituber = {
            "rank": int(datos[0]),
            "cupituber": datos[1],
            "subscribers": int(datos[2]),  
            "video_views": int(datos[3]),
            "video_count": int(datos[4]),
            "category": datos[5],
            "started": datos[6],
            "country": datos[7],
            "monetization_type": datos[8],
            "description": datos[9].strip()
        }

        pais = datos[7]
        if pais not in cupitubers:
            cupitubers[pais] = []
        cupitubers[pais].append(cupituber)

        linea = archivo.readline().strip()  

    #TODO 1: Implemente la función tal y como se describe en la documentación.
    archivo.close()
    return cupitubers

cupitubers=cargar_cupitube("cupitube.csv")
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.
    
    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"
        
        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    #TODO 2: Implemente la función tal y como se describe en la documentación.
    cumplen =[] #creo la lista vacia q voy a retornar 
    for pais in cupitube: #accedo a cada pais (llave) en el diccionario grande
        for cupituber in cupitube[pais]: #accedo a la lista de diccionarios internos pertenecientes a cada pais// pongo la llave entr []sin comillas pq puede tomar el nombre de cuaquier pais 
            cat=cupituber["category"]#accedo a la categoria de cada dic interno / la llave va entre "" pq se cual es exactamente su nombre 
            if categoria_buscada==cat:#aplico el filtro
                subs=cupituber["subscribers"] #si supera el primer filtro accedo al valor de sus suscriptores /la llave va entre "" pq se exactamente cual es su nombre y este no cambia 
                if subs>=suscriptores_min and subs<=suscriptores_max: #aplico el filtro
                    cumplen.append(cupituber) #agrego el diccionario de cada cupituber q cumple con los filtros dados

    return cumplen
#print(buscar_por_categoria_y_rango_suscriptores(cupitubers, 1000000, 111000000, "Gaming" )) #faltan 2 cupitubers


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    #TODO 3: Implemente la función tal y como se describe en la documentación.
    cumplen =[] #creo una lista vacia q voy a retornar 
    for pais in cupitube:#accedo o recorro cada llave (el pais) del diccionario
        if pais_buscado==pais:#aplico el primer filtro para saber si el pais es el q busco
            for cupituber in cupitube[pais]:#si es el mismo pais q estoy buscando accedo a cada diccionario en este pais
                cat=cupituber["category"]#creo una variable con el valor de categoria de cada cupituber (dic interno por pais)
                if categoria_buscada==cat:#aplico el filtro para saber si la categoria q estoy buscando es la misma del cupituber 
                    mon=cupituber["monetization_type"]#si supera el filtro accedo a su valor de tipo de monetizacion y lo guardo en una variable
                    if monetizacion_buscada==mon:#creo el nuevo filtro para saber si es la misma monetizacion q estoy buscando 
                        cumplen.append(cupituber)#si cumple todos los filtros agrego el diccionario del cupituber a mi lista 
    return cumplen #retorno la lista con los diccionarios de aquellos que si cumplieron con todos los filtros
#print(buscar_cupitubers_por_pais_categoria_monetizacion(cupitubers, "UK","Gaming" ,"Crowdfunding" ))#funciona

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    viejo={}#creo el diccionario vacio a retornar
    primero=True #establezco un "centinela" para estabecer un dato como el primero
    for pais in cupitube:#accedo o recorro cada pais de mi diccionario
        for cupituber in cupitube[pais]:#cada dic de cada pais
            if primero:#pregunto si estoy en la primera posicion 
                fecha=cupituber["started"]#establezco la fecha de esa primera posicion como la mas antigua 
                primero=False #cambio el valor del centinela para que no vuelva a pasar por el if y así no me cambie el balor q ya estableci 
            elif cupituber["started"]<fecha:#uso elif para cuando ya no estoy en la primera posicion / comparo la fecha q estableci como la mayor con la fecha de cada cupituber 
                fecha=cupituber["started"] #actualizar la fecha para comparar // en caso de q la fecha de algun cupituber sea meor q la preestablecida
                viejo= cupituber#asigno eldiccionario del cupituber mas viejo a mi diccionario vacio para retornar este valor 
    return viejo #retorno el diccionario con la info del cupituber mas viejo 
#print(buscar_cupituber_mas_antiguo(cupitubers)) #funciona            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.
    
    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.
    
    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    #TODO 5: Implemente la función tal y como se describe en la documentación.
    views=0#establezco un valor inicial 
    for pais in cupitube:#accedo a cada pais del diccionario 
        for cupituber in cupitube[pais]: #recorro la lista de diccionarios por pais / va sin "" pq el nombre de la llave va a cambiar en cada iteracion 
            if categoria_buscada==cupituber["category"]:#aplico el filtor para saber si el cupituber pertenece a la misma categoria q estoy buscando
                views+=cupituber["video_views"]#si se cunole, accedo al valor de la llave video:views y voy sumando ese valor a mi valor inicial 
    return views #retorno la sumatoria de todas las vistas de los videos que pertenecen a esa categoria
#print(obtener_visitas_por_categoria(cupitubers, "Music"))#funciona

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    #TODO 6: Implemente la función tal y como se describe en la documentación.
    primero=True#creo un centinela para establecer un valor como el primero
    mas_vistas=0#creo una variable con un valor inicial 
    vistas_categoria={}#creo el diccionario vacio a retornar 
    for pais in cupitube:#recorro cada pais del diccionario 
        for cupituber in cupitube[pais]: #accedo a cada dic interno del diccionario original
            categoria=cupituber["category"]#creo una val¿riable con la categoria de cada cupituber
            vistas=obtener_visitas_por_categoria(cupitubers, categoria)#creo una variable donde guardo la info de la funcion anterior (las vistas para una categoria en especifico) y pongo categoria como la categoria buscada para q recorra cada categoria existente
            if vistas>mas_vistas: #creo un filtro para saber si la categoria tiene mas vistas q 0
                mas_vistas=vistas#actualizo cual es el numero mayor de vistas para seguir comparando
                if primero==True: #pregunto si estoy en el primer dato
                    categoria_mas_vista=categoria #establezco este dato (categoria) como el mayor 
                    primero=False#le informo q ya no esta en el primer dato para que no vuelva a pasar por ese if 
                elif categoria>categoria_mas_vista:#comparo cada categoria con la q estableci como la mayor
                    categoria_mas_vista=categoria#actualizo q categoria tiene mas vistas para seguir comparando
                vistas_categoria[categoria_mas_vista]=vistas#asigo en el diccionario la lleva categoria_mas_vista con el respectivo numero de vistas que tiene
                
    return vistas_categoria #retorno este nuevo diccionario con su respectiva llave y valor
#print (obtener_categoria_con_mas_visitas(cupitubers)) #creo q funciona


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None: #retorna None pq lo q hace es editar el diccionario (mas especificamente cada dic interno)
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:
    
    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.
    
    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.
        
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"
    
    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    #TODO 7: Implemente la función tal y como se describe en la documentación.
    for pais in cupitube:#recorro cada llave del diccionario original (es decir cada pais)
        for cupituber in cupitube[pais]:#recorro cada diccionario  (dic interno) en la lista de cada pais 
            x=cupituber["cupituber"].replace(" ", "") #asigono q x va a ser el nombre del cupituver (valor en la llave nombre) quitando los espacios 
            X=x.lower()#el valor anterior lo guardo en una nueva variable con .lower() para que me pase todos los caracteres a minuscula
            X_an=""#creo una nueva variable (str vacio) para quitar los valores especiales
            for caracter in X:#recorro cada caracter en el str original 
                if caracter.isalnum():#preguno si cada caracter es alfanumerico
                    X_an+=caracter #si si es alfanumerico lo agrego al str vacio 
                    if len(X_an)>=15: #pregunto si la longitud de este str es mayor o igual a 15 
                        X_an=X_an[0:16] #en caso de ser mas largo le pido que tome solo los 15 primeros digitos (pongo del 0 al 16 pq para uno antes)
            Y=cupituber["started"][2:4] #establezco Y como el valor en la llave started (fecha) el segundo y 3 digito (o sea los ultimos dos digitos del año)
            Z=cupituber["started"][5:7] #establezco Z como el valor en la llave started (fecha) el quinto y sexto digito (o sea el mes )
            nombre=X_an+"."+Y+Z+"@cupitube.com" #creo la variable con el nombre completo del correo 
            cupituber["correo"]=nombre#correcto para añadir el correo / añado la llave correo a cada dic interno con su respectivo valor (el nombre que asigne antes)
            #no hay return por lo q edito el diccionario original
#print (crear_correo_para_cupitubers(cupitubers))#funciona, solo falta quitar los c especiales

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.
    
    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).
    
    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.
           
    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.
    
    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    primero=True #establezco un centinela para saber si estoy en el primer lugar
    cupituber_ideal={} #creo el diccionario vacio a retornar 
    dic_categoria_mas_vista=obtener_categoria_con_mas_visitas(cupitube) #creo una variable con la categoria mas vista (gracias a la funcion anterior)
    categoria_mas_vista=list(dic_categoria_mas_vista.keys())[0] #establezco la categoria mas vista transformando las llaves del diccionario en una lista y diciendo q la mas vista es la q esta en primer lugar
    suscriptores=buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria_mas_vista) #creo la bariable suscriptores con la funcion anterior dicendo q la cantidad minima y maxima son las q diga el usuario 
    pc=palabra_clave.lower()#ceo una variable con la palabra clave que de el usuario pero en minusculas
    for cupituber in suscriptores: #recorro cada llave (cada cupituber) del diccionario de aquellos que cumplen con los parametros de suscriptores dados
        if primero==True: #pregunto si estoy en el primer cupituber pq me pide retornar al primero q cumpla con todos los criterios
            videos=int(cupituber["video_count"])#tomo el valor en la llave video_count transformado en entero y lo gusardo en una variable para saber cuantos videos tiene
            if videos>=videos_minimos:#pregunto si la cantidad de videos es mayor o igual a la cantidad minima q quiere el usuario
                if cupituber["started"]>=fecha_minima and cupituber["started"]<=fecha_maxima: #si cumple el filtro anterior le pregunto si la fecha en q empezo es mayor a la fecha minima q quiere el usuario y si es menor o igual a la fecha maxima q quiere el usuario
                    d_cupituber=cupituber["description"].lower() #creo una variable con el valor de la descripcion del cupituber pero en minusculas 
                    if pc in d_cupituber: #pregunto si la palabra clave esta el alguna parte de la descripcion del cupituver
                        cupituber_ideal=cupituber#si se cumplen todos los filtros asigna este cupituber como el ideal 
                        primero=False #se sale del primero para q así haya mas ya no los tome en cuenta

    return cupituber_ideal #me retorna el diccionario del cupituber q cumpla todos los parametros 
#print(recomendar_cupituber(cupitubers, 1000000,111000000, "2002-10-24", "2020-08-03", 3, "TrenDs"))#creo q funciona

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    #TODO 9: Implemente la función tal y como se describe en la documentación.
    categorias={} #creo un diccionario vacio para ir agregando las categorias
    for pais in cupitube: #recorro cada pais del diccionario original 
        for cupituber in cupitube[pais]: #recorro cada dic interno de cada pais
            if cupituber["category"] in categorias:#si la categoria si esta / pregunto si el valor de la llave categoria del cupituber esta en mi diccionario si ya estta pasa a preguntar si el pais esta 
                if cupituber["country"] not in categorias[cupituber["category"]]:#revisar si el pais esta y si no se añade
                    categorias[cupituber["category"]].append(cupituber["country"]) #en caso de q el pais no este lo creamos y lo metemos en la categoria
            else: #crear la categoria/ si cat no esta
                 categorias[cupituber["category"]]=[cupituber["country"]] #asigno en el valor la categoria como llave y el pais como valor 
    return categorias #retorno mi diccionario con las llaves y valores 
#print(paises_por_categoria(cupitubers)) #funciona

