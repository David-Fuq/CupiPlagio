
# Función 1: 
def cargar_cupitube(archivo: str)-> dict:
    datos = {}
    f = open(archivo, "r", encoding="utf-8")
    
    f.readline()
    for linea in f:
        linea = linea.strip()
        columnas = linea.split(",")

        rank = int(columnas[0])
        cupituber = str(columnas[1].strip())
        subscribers = int(columnas[2])
        video_views = int(columnas[3])
        video_count = int(columnas[4])
        category = str(columnas[5].strip())
        started = str(columnas[6].strip())
        country = str(columnas[7].strip())
        monetization_type = str(columnas[8].strip())
        description = str(columnas[9].strip())

        cupituber_info = {"rank": rank,"cupituber": cupituber,"subscribers": subscribers,"video_views": video_views,"video_count": video_count,"category": category,"started": started,"monetization_type": monetization_type,"description": description }

        if country not in datos:
            datos[country] = []
        datos[country].append(cupituber_info)

    f.close()  
    return datos

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str)-> list:

    resultado = []

    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            if (cupituber["category"] == categoria_buscada) and (suscriptores_min <= cupituber["subscribers"]) and  (cupituber["subscribers"] <= suscriptores_max):
                resultado.append(cupituber)

    return resultado

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str)-> list:

    resultado = []

    if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]

        for cupituber in lista_cupitubers:
            if (cupituber["category"] == categoria_buscada) and (cupituber["monetization_type"] == monetizacion_buscada):
                resultado.append(cupituber)

    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict)-> dict:

    mas_antiguo = None
    fecha_mas_antigua = None


    for lista_cupitubers in cupitube.values():

        for cupituber in lista_cupitubers:
            fecha_actual = cupituber["started"]


            if (fecha_mas_antigua == None): 
                mas_antiguo = cupituber
                fecha_mas_antigua = fecha_actual
            if (fecha_actual < fecha_mas_antigua):
                mas_antiguo = cupituber
                fecha_mas_antigua = fecha_actual

    return mas_antiguo            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str)-> int:

    total_visitas = 0

    for lista_cupitubers in cupitube.values():
        
        for cupituber in lista_cupitubers:
            
            if cupituber["category"] == categoria_buscada:
                total_visitas += cupituber["video_views"]

    return total_visitas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict)-> dict:
    visitas_por_categoria = {}


    for lista in cupitube.values():
        for cupituber in lista:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]

            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = visitas
            else:
                visitas_por_categoria[categoria] = visitas_por_categoria[categoria] + visitas

    
    categorias = list(visitas_por_categoria.keys())
    categoria_mas = categorias[0]
    visitas_mas = visitas_por_categoria[categoria_mas]

    for i in range(1, len(categorias)):
        categoria_actual = categorias[i]
        visitas_actual = visitas_por_categoria[categoria_actual]

        if visitas_actual > visitas_mas:
            categoria_mas = categoria_actual
            visitas_mas = visitas_actual


    resultado = {"categoria": categoria_mas, "visitas": visitas_mas}
    return resultado

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict)-> None:

    for lista_cupitubers in cupitube.values():

        for cupituber in lista_cupitubers:
            nombre_original = cupituber["cupituber"]  


            nombre_limpio = ""
            for c in nombre_original:
                if c.isalnum():  
                    nombre_limpio += c

            nombre_limpio = nombre_limpio.lower()  


            nombre_corto = nombre_limpio[:15]
            fecha = cupituber["started"] 
            anio = fecha[2:4]  
            mes = fecha[5:7]   


            correo = nombre_corto + "." + anio + mes + "@cupitube.com"


            cupituber["correo"] = correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str)-> dict:

    cupituber_recomendado = {}

    resultado_categoria = obtener_categoria_con_mas_visitas(cupitube)


    categoria_objetivo = resultado_categoria["categoria"]

    palabra_clave = palabra_clave.lower()

    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
           
            categoria = cupituber["category"]
            subs = cupituber["subscribers"]  
            videos = cupituber["video_count"]  
            fecha = cupituber["started"] 
            descripcion = cupituber["description"].lower() 

            
            if categoria == categoria_objetivo:
                cumple_categoria = True
            else:
                cumple_categoria = False

            if suscriptores_min <= subs <= suscriptores_max:
                cumple_suscriptores = True
            else:
                cumple_suscriptores = False

            if videos >= videos_minimos:
                cumple_videos = True
            else:
                cumple_videos = False

            if fecha_minima <= fecha <= fecha_maxima:
                cumple_fecha = True
            else:
                cumple_fecha = False

            if palabra_clave in descripcion:
                cumple_palabra_clave = True
            else:
                cumple_palabra_clave = False

            
            if (cumple_categoria and cumple_suscriptores and cumple_videos and cumple_fecha and cumple_palabra_clave):
                cupituber_recomendado = cupituber
                break
        if cupituber_recomendado:
            break

   
    return cupituber_recomendado



# Función 9:
def paises_por_categoria(cupitube: dict)-> dict:
    categorias_paises = {}

    paises = list(cupitube.keys())

    for i in range(len(paises)):
        pais = paises[i]
        lista_cupitubers = cupitube[pais]

        for j in range(len(lista_cupitubers)):
            cupituber = lista_cupitubers[j]
            categoria = cupituber["category"]

            if categoria not in categorias_paises:
                categorias_paises[categoria] = []

            if pais not in categorias_paises[categoria]:
                categorias_paises[categoria].append(pais)

    return categorias_paises
