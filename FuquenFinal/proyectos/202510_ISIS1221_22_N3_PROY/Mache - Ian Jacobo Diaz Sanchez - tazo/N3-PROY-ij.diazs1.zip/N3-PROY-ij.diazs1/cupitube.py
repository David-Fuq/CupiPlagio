
"""
CupiTube
"""
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitubers_por_pais = {}
    archivo = open(archivo, "r", encoding="utf-8")
    titulos = archivo.readline().strip()    
    linea = archivo.readline().strip()
    while len(linea) > 0:
        datos = linea.split(",")
        cupi = {}
        country = datos[0]
        cupi["rank"] = int(datos[1])
        cupi["cupituber"] = datos[2]
        cupi["subscribers"] = int(datos[3])
        cupi["video_views"] = int(datos[4])
        cupi["video_count"] = int(datos[5])
        cupi["category"] = datos[6]
        cupi["started"] = datos[7]
        cupi["monetization_type"] = datos[8]
        cupi["description"] = datos[9]
        
        if country not in cupitubers_por_pais:
            cupitubers_por_pais[country] = []
            
        cupitubers_por_pais[country] += [cupi]
        linea = archivo.readline().strip()
        
    archivo.close()
    return cupitubers_por_pais

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
   rango = [] 
   for i in cupitube:
      if cupitube[i]["category"] == categoria_buscada and suscriptores_min <= cupitube[i]["subscribers"] <= suscriptores_max:
          rango.append(i)
   return rango

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultados = []
    for i in cupitube[pais_buscado]:
        if i["category"] == categoria_buscada and i["monetization_type"] == monetizacion_buscada:
            resultados.append(i)
    if pais_buscado not in cupitube:
        resultados = []
    return resultados
   
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = {}
    for i in cupitube:
        if mas_antiguo == {} or cupitube[i]["started"] < mas_antiguo["started"]:
            mas_antiguo = i
    return mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total_v = 0
    for i in cupitube:
        if cupitube[i]["category"] == categoria_buscada:
            total_v += cupitube[i]["video_views"]
    return total_v

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mayor = 0
    tube = None
    for i in cupitube:
        if mayor < cupitube[i]["video_views"]:
            mayor = cupitube[i]["video_views"]
            tube = i
    return tube

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for i in cupitube:

        if "cupituber" in cupitube[i]:
            nombre = cupitube[i]["cupituber"]
        else:
            nombre = ""
        nombre_saneado = nombre
        if len(nombre_saneado) > 15:
            nombre_saneado = nombre_saneado[15]
        nombre_saneado.lower()

        if "started" in cupitube[i]:
            fecha = cupitube[i]["started"]
        else:
            fecha = ""
        partes = fecha.split("-")
        if len(partes) >= 2:
            año = partes[0]
            mes = partes[1]
        else:
            año = "0000"
            mes = "00"
        año2 = año[2] if len(año) >= 2 else año
        if len(mes) == 1:
            mes2 = "0" + mes
        elif len(mes) >= 2:
            mes2 = mes[2]
        else:
            mes2 = "00"
        cupitube[i]["correo"] = (nombre_saneado + '.' + año2 + mes2 + "@cupitube.com")

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    resultado = {}
    visitas_por_categoria = {}
    
    for i in cupitube:
        if "category" in cupitube[i]:
            b = cupitube[i]["category"]
        else:
            b = ""
            
        if "video_views" in cupitube[i]:
            visitas = cupitube[i]["video_views"]
        else:
            visitas = 0
            
        if b in visitas_por_categoria:
            visitas_por_categoria[b] += visitas
        else:
            visitas_por_categoria[b] = visitas
            
    if visitas_por_categoria:
        clave_palabra = palabra_clave.lower()
        for i in cupitube:
            
            if "category" in cupitube[i]:
                b = cupitube[i]["category"]
            else:
                b = ""
            if "subscribers" in cupitube[i]:
                subs = cupitube[i]["subscribers"]
            else:
                subs = 0
            if "video_count" in cupitube[i]:
                videos = cupitube[i]["video_count"]
            else:
                videos = 0
            if "started" in cupitube[i]:
                started = cupitube[i]["started"]
            else:
                started = ""
            if "description" in cupitube[i]:
                descripcion = cupitube[i]["description"].lower()
            else:
                descripcion = ""

            if (resultado == {} and suscriptores_min <= subs <= suscriptores_max and videos >= videos_minimos and fecha_minima <= started <= fecha_maxima and clave_palabra in descripcion):
                resultado = i
    return resultado

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias_paises = {}

    for pais in cupitube:

        i = 0
        while i < len(cupitube[pais]):
            tuber = cupitube[pais][i]

            existe_categoria = False
            for b in categorias_paises:
                if b == tuber["category"]:
                    existe_categoria = True

            if existe_categoria == False:
                categorias_paises[tuber["categoty"]] = []

            ya_esta = False
            lista_paises = categorias_paises[tuber["category"]]
            c = 0
            while c < len(lista_paises):
                if lista_paises[c] == pais:
                    ya_esta = True
                c += 1

            if ya_esta == False:
                categorias_paises[tuber["category"]].append(pais)

            i += 1

    return categorias_paises
