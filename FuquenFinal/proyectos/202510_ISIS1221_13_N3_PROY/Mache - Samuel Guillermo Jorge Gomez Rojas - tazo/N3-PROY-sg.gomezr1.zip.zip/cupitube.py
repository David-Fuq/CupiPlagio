#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
import csv as archivo

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    cupidict = {}
    file = open(archivo, "r", encoding="utf-8") 
    
    file.readline()

    for line in file:
        
        line = line.strip()
        #splitline para dividir los datos
        splitline = line.split(",")

        #cupituber es una linea de la lista, y for se usa para cada recorrer por cada linea de la lista
        cupituber = {
        "rank": int(splitline[0]),
        "cupituber": str(splitline[1]),
        "subscribers": int(splitline[2]),
        "video_views": int(splitline[3]),
        "video_count": int(splitline[4]),
        "category": str(splitline[5]),
        "started": str(splitline[6]),       
        "monetization_type": str(splitline[8]),
        "description": str(splitline[9])
        }

        country  = splitline[7]
        if country in cupidict:
            lista = cupidict[country]
            lista.append(cupituber)
        else:
            cupidict[country] = []
            cupidict[country].append(cupituber)

    file.close()

    return cupidict
    


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
   
    resultado = []
    for country in cupitube:
        cupitube_list = cupitube[country] 

        for cupituber in cupitube_list:
         if cupituber["subscribers"] >= suscriptores_min and cupituber["subscribers"] <= suscriptores_max and cupituber["category"] == categoria_buscada:
            resultado.append(cupituber)

    return resultado




# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    resultado = []
    for country in cupitube:
        cupituber_list = cupitube[country] 

        for cupituber in cupituber_list:
                if country == pais_buscado and cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
                    resultado.append(cupituber)
    
    return resultado


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    cupituber_mas_antiguo = {}
    fecha_mas_reciente = "9999-99-99"
    
    for country in cupitube:
        cupituber_list = cupitube[country] 
        
        for cupituber in cupituber_list: 
         if cupituber["started"] < fecha_mas_reciente:
            fecha_mas_reciente = cupituber["started"]
            cupituber_mas_antiguo = cupituber

    return cupituber_mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total_visitas = 0

    for country in cupitube:
        cupituber_list = cupitube[country] 
        
        for cupituber in cupituber_list:
            if cupituber["category"] == categoria_buscada:
                total_visitas += (cupituber["video_views"])

    return total_visitas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    contador_por_categoria = {}
    for country in cupitube:
        cupituber_list = cupitube[country] 

        for cupituber in cupituber_list:
            categoria = cupituber["category"]
            if categoria in contador_por_categoria:
                contador_por_categoria[categoria] += cupituber["video_views"] 
            else:
                contador_por_categoria[categoria] = cupituber["video_views"]

    categoria_con_mas_visitas = {}
    mayores_vistas = -1
    for categoria in contador_por_categoria:
        if contador_por_categoria[categoria] > mayores_vistas:
            mayores_vistas = contador_por_categoria
            categoria_con_mas_visitas = categoria

    return categoria_con_mas_visitas
            


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for country in cupitube:
        cupituber_list = cupitube[country] 
        
        for cupituber in cupituber_list:
            nombre = cupituber["cupitube"][:15]
            anio = cupituber["started"][2:4]
            mes = cupituber["started"][5:7]

            email = nombre.lower() + "." + anio + mes + "@cupitube.com"
            cupituber["email"] = email
              

        


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    cupituber_recomendado = {}

    for country in cupitube:
        cupituber_list = cupitube[country] 
        
        for cupituber in cupituber_list:
            categoria_mas_alta = obtener_categoria_con_mas_visitas(cupitube)
            
            if cupituber["category"] == categoria_mas_alta:
             
             if cupituber["subscribers"] >= suscriptores_min and cupituber["subscribers"] <= suscriptores_max and cupituber["started"] >= fecha_minima and cupituber["started"] <= fecha_maxima and cupituber["video_count"] >= videos_minimos and cupituber["description"].lower() in (palabra_clave).lower():
                    cupituber_recomendado = cupituber
                    
                    return cupituber_recomendado
        

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    paises_por_categoria = {}

    for country in cupitube:
        cupituber_list = cupitube[country] 
        
        for cupituber in cupituber_list:
         categoria = cupituber["category"]

         if categoria not in paises_por_categoria:
             paises_por_categoria[categoria] = []

        if country not in paises_por_categoria[categoria]:
            paises_por_categoria[categoria].append(country)


    return paises_por_categoria