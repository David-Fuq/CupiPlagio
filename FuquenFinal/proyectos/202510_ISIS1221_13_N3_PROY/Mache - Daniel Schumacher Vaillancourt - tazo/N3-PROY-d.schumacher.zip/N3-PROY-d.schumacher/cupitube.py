def cargar_cupitube(archivo: str) -> dict:
    creadores = {}
    archivo = open(archivo, "r", encoding="utf-8")
    archivo.readline()
    linea = archivo.readline()
    while len(linea) > 0:
        datos = linea.strip().split(",")
        country = datos[7]
        creador = {"rank": int(datos[0]),"cupituber": datos[1],"subscribers": int(datos[2]),"video_views": int(datos[3]),"video_count": int(datos[4]),"category": datos[5],"started": datos[6],"monetization_type": datos[8],"description": datos[9]}
        if country not in creadores:
            creadores[country] = []
        creadores[country].append(creador)
        linea = archivo.readline()
    archivo.close()
    return creadores



def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resp = []
    for country, creadores in cupitube.items():
        for creador in creadores:
            if suscriptores_min <= creador["subscribers"] <= suscriptores_max and creador["category"] == categoria_buscada:
                resp.append(creador)
    return resp
    


def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resp = []
    if pais_buscado in cupitube:
        for creador in cupitube[pais_buscado]:
            if creador["category"] == categoria_buscada and creador["monetization_type"] == monetizacion_buscada:
                resp.append(creador)  
    return resp



def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    resp = {} 
    for creadores in cupitube.values(): 
        for creador in creadores: 
            if not resp or creador["started"] < resp["started"]: 
                resp = creador 
    return resp
            


def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total_visitas = 0 
    for creadores in cupitube.values():
        for creador in creadores:
            if creador["category"] == categoria_buscada:
                total_visitas += creador["video_views"]
    return total_visitas



def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {}
    for creadores in cupitube.values():
        for creador in creadores:
            categoria = creador["category"]
            video_views = creador["video_views"]
            if categoria in visitas_por_categoria:
                visitas_por_categoria[categoria] += video_views
            else:
                visitas_por_categoria[categoria] = video_views
    categoria_maxima = None
    max_visitas = 0
    for categoria, total_visitas in visitas_por_categoria.items():
        if total_visitas > max_visitas:
            max_visitas = total_visitas
            categoria_maxima = categoria
    return {"categoria": categoria_maxima,"visitas": max_visitas}




def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for creadores in cupitube.values():
        for creador in creadores:
            nombre_limpio = ""
            for letra in creador["cupituber"]:
                if ("a" <= letra <= "z") or ("A" <= letra <= "Z") or ("0" <= letra <= "9"):
                    nombre_limpio += letra
            nombre_limpio = nombre_limpio[:15].lower()
            año = int(creador["started"][:4])
            mes = int(creador["started"][5:7])
            correo = f"{nombre_limpio}.{año % 100:02}{mes:02}@cupitube.com"
            creador["correo"] = correo

def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    categoria_mas_visitas = None
    max_visitas = 0
    for categoria, creadores in cupitube.items():
        total_visitas = sum(creador["views"] for creador in creadores)
        if total_visitas > max_visitas:
            max_visitas = total_visitas
            categoria_mas_visitas = categoria
    resultado = {}
    if categoria_mas_visitas is not None:
        for creador in cupitube[categoria_mas_visitas]:
            suscriptores = creador["subscribers"]
            fecha_inicio = creador["started"]
            videos = creador["videos"]
            descripcion = creador["description"].lower()
            if (suscriptores_min <= suscriptores <= suscriptores_max and
                fecha_minima <= fecha_inicio <= fecha_maxima and
                videos >= videos_minimos and
                palabra_clave.lower() in descripcion):
                resultado = creador
    return resultado

def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}
    
    for categoria, creadores in cupitube.items():
        paises = []
        for creador in creadores:
            pais = creador["country"]
            if pais not in paises:
                paises.append(pais)
        resultado[categoria] = paises
    return resultado
