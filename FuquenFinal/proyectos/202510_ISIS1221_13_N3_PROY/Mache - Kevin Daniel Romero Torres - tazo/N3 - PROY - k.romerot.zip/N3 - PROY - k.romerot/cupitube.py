
def cargar_cupitube(archivo: str) -> dict:
    cupitubers = {}
    
    archivo = open(archivo, "r", encoding="utf-8") 
    titulos = archivo.readline().strip()
    print (titulos)
    
    linea = archivo.readline().strip()
    
    while len(linea) > 0:
        datos = linea.split(",")
        pais = datos[7]
        cupituber = {}
        cupituber['rank'] = datos[0]
        cupituber['cupituber'] = datos[1]
        cupituber['subscribers'] = int(datos[2])
        cupituber['video_views'] = int(datos[3])
        cupituber['video_count'] = int(datos [4])
        cupituber['category'] = datos[5]
        cupituber['started'] = datos[6]
        cupituber['monetization_type'] = datos[8]
        cupituber['description'] = datos[9]
        if pais not in cupitubers:
           cupitubers[pais] = []
        cupitubers[pais].append(cupituber)
        linea = archivo.readline().strip()
        
        
    archivo.close()
    return cupitubers


def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    lista = []
    
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:
            subs = cada_cupituber['subscribers']
            categoria = cada_cupituber['category']
            if categoria == categoria_buscada and subs < suscriptores_max and subs > suscriptores_min:
                lista.append(cada_cupituber)
    return lista   

        
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    lista = []
    
    for pais in cupitube:
        if pais == pais_buscado:
            for cada_cupituber in cupitube[pais]:
                categoria = cada_cupituber['category']
                monetizacion = cada_cupituber['monetization_type']
                if categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                    lista.append(cada_cupituber)
    return lista
        
         
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = ""
    dic = {}
    
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:
            comienzo = cada_cupituber['started']
            if mas_antiguo == "":
                mas_antiguo = comienzo
                dic["Mayor antiguedad"] = cada_cupituber
            elif mas_antiguo > comienzo:
                dic.clear()
                mas_antiguo = comienzo
                dic["Mayor antiguedad"] = cada_cupituber  
    return dic
          
    
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    vistas = 0
    
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:
            vistas_cada_cupituber = cada_cupituber['video_views']
            if cada_cupituber['category'] == categoria_buscada:
                vistas += vistas_cada_cupituber
    return vistas
    
   
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mayor_vistas = 0
    vistas_categorias = {}
    dic = {}
    
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:
            vistas_cupituber = cada_cupituber['video_views']
            categoria = cada_cupituber['category']
            if categoria not in vistas_categorias:
                vistas_categorias[categoria] = vistas_cupituber
            elif categoria in vistas_categorias:
                vistas_categorias[categoria] += vistas_cupituber
    for vistas in vistas_categorias:
        if vistas_categorias[vistas] > mayor_vistas:
            mayor_vistas = vistas_categorias[vistas]
            dic.clear()
            dic["categoria"] = vistas 
    dic["visitas"] = mayor_vistas
    return dic
       
    
def crear_correo_para_cupitubers(cupitube: dict) -> None: 
    eliminar = ['\n', ' ', '!', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/',
              ':', ';', '<', '=', '>', '?', '@', '[', ']', '^', '_', '{', '|', '}', '~',
              'ُ', 'ِ', 'ं', 'ि', 'ी', '्', 'ิ', 'ี', '่', '์', '\u200b', '–', '™', '►', '★', '♡', '・']
        
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:
            fecha_comienzo = cada_cupituber["started"]
            nombre = cada_cupituber["cupituber"]
            for c in eliminar:        
                nombre = nombre.replace(c, "")
            if len(nombre) > 15:
                X = nombre[:15]
            else:
                X = nombre
            Y = fecha_comienzo[2:4]
            Z = fecha_comienzo[5:7]
            correo = (X) + "."+ (Y) + (Z) + "@cupitube.com"
            cada_cupituber["correo"] = correo
        
        
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    recomendacion = {}
    categoria_mas_vistas = obtener_categoria_con_mas_visitas(cupitube)
    
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:
            categoria = cada_cupituber["category"]
            descripcion = cada_cupituber["description"]
            subs = cada_cupituber["subscribers"]
            videos = cada_cupituber["video_count"]
            comienzo = cada_cupituber["started"]
            cuenta = 0
            if categoria == categoria_mas_vistas["categoria"]:
                cuenta += 1
            if palabra_clave.lower() in descripcion.lower():
                cuenta += 1
            if suscriptores_min < subs < suscriptores_max:
                cuenta += 1
            if videos > videos_minimos:
                cuenta += 1
            if fecha_minima < comienzo < fecha_maxima:
                cuenta += 1
            if cuenta == 5:
                recomendacion = cada_cupituber
    return recomendacion
        

def paises_por_categoria(cupitube: dict) -> dict:
    dic = {}
    
    for pais in cupitube:
        for cada_cupituber in cupitube[pais]:
            categoria = cada_cupituber["category"]
            if categoria not in dic:
                dic[categoria] = [pais]
            elif pais not in dic[categoria]:
                dic[categoria].append(pais)
    return dic
            
        



        
   
           
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   