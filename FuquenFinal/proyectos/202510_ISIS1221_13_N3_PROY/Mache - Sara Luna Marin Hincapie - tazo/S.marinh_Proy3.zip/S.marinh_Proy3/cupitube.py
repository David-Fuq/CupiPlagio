#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    

    dict_paises = {}

    archivo = open(archivo, "r", encoding="utf-8")
    archivo.readline()  

    linea = archivo.readline().strip()

    while len(linea) > 0:
        datos = linea.split(",")

        dict_cupituber = {}
        dict_cupituber["rank"] = int(datos[0])
        dict_cupituber["cupituber"] = datos[1].strip()
        dict_cupituber["subscribers"] = int(datos[2])
        dict_cupituber["video_views"] = int(datos[3])
        dict_cupituber["video_count"] = int(datos[4])
        dict_cupituber["category"] = datos[5].strip()
        dict_cupituber["started"] = datos[6].strip()
        dict_cupituber["country"] = datos[7].strip()
        dict_cupituber["monetization_type"] = datos[8].strip()
        dict_cupituber["description"] = datos[9].strip()

        pais = dict_cupituber["country"]

        if pais in dict_paises:
            dict_paises[pais].append(dict_cupituber)
        else:
            lista = []
            lista.append(dict_cupituber)
            dict_paises[pais] = lista

        linea = archivo.readline().strip()

    archivo.close()
    return dict_paises
  

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
   resultado = []

   for pais in cupitube:
        lista_cupitubers = cupitube[pais]

        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]

            if categoria == categoria_buscada and suscriptores_min <= suscriptores <= suscriptores_max:
                resultado.append(cupituber)

   return resultado


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
   resultado = []

   if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]

        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            monetizacion = cupituber["monetization_type"]

            if categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                resultado.append(cupituber)

   return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:

    mas_antiguo = None

    for pais in cupitube:
        lista = cupitube[pais]

        for cupituber in lista:
            if mas_antiguo is None:
                mas_antiguo = cupituber
            elif cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber

    return mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
     
    total_visitas = 0

    for pais in cupitube:
      lista = cupitube[pais]

      for cupituber in lista:
          if cupituber["category"] == categoria_buscada:
              total_visitas += cupituber["video_views"]

    return total_visitas
   

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
   visitas_por_categoria = {}

   for pais in cupitube:
        lista = cupitube[pais]

        for cupituber in lista:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]

            if categoria in visitas_por_categoria:
                visitas_por_categoria[categoria] += visitas
            else:
                visitas_por_categoria[categoria] = visitas

    
   categoria_max = None
   max_visitas = 0
   
   for categoria in visitas_por_categoria:
        if visitas_por_categoria[categoria] > max_visitas:
            max_visitas = visitas_por_categoria[categoria]
            categoria_max = categoria

   return {"categoria": categoria_max,"visitas": max_visitas}

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        lista = cupitube[pais]

        for cupituber in lista:
            nombre = cupituber["cupituber"]

           
            nombre_limpio = ""
            for letra in nombre:
                if letra.isalnum():
                    nombre_limpio += letra

            nombre_limpio = nombre_limpio[:15]

            fecha = cupituber["started"]  
            partes = fecha.split("-")
            anio = partes[0][-2:]  
            mes = partes[1]

           
            correo = (nombre + "." + anio + mes + "@cupituber.com")
            correo = correo.lower()

           
            cupituber["correo"] = correo

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
   

    categoria_maxima = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    
    palabra_clave = palabra_clave.lower()
   
    for pais in cupitube:
        lista = cupitube[pais]

        for cupituber in lista:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            videos = cupituber["video_count"]
            fecha = cupituber["started"]
            descripcion = cupituber["description"].lower() 

            if (categoria == categoria_maxima and suscriptores_min <= suscriptores <= suscriptores_max and videos >= videos_minimos and fecha_minima <= fecha <= fecha_maxima and palabra_clave in descripcion):
                return cupituber 

    return {}  


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}

    for pais in cupitube:
        lista = cupitube[pais]

        for cupituber in lista:
            categoria = cupituber["category"]

            if categoria in resultado:
                if pais not in resultado[categoria]:
                    resultado[categoria].append(pais)
            else:
                resultado[categoria] = [pais]

    return resultado