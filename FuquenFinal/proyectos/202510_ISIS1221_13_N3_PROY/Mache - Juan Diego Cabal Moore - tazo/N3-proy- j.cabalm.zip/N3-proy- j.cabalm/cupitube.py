#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
  

    
  




   

    cupitube = {}

    archivo = open(archivo, encoding="utf-8")
    titulos = archivo.readline().split(",")

    linea = archivo.readline()
    while len(linea) > 0:
        datos = linea.strip().split(",")

        nombre = datos[1]
        cupitube[nombre] = {
            "rank": int(datos[0]),
            "cupituber":(datos[1]),
            "subscribers": int(datos[2]),
            "video_views": int(datos[3]),
            "video_count": int(datos[4]),
            "category": datos[5],
            "started": datos[6],
            "country": datos[7],
            "monetization_type": datos[8],
            "description": datos[9]
        }

        linea = archivo.readline()

    archivo.close()
    return cupitube


        
        
    
    
    


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:

    resultado = []

  

    for categoria in cupitube:
            suscriptores =int( cupitube[categoria]["subscribers"])
            categoria1=cupitube[categoria]["category"].lower()

            if suscriptores_min <= suscriptores and suscriptores<=suscriptores_max and categoria1==categoria_buscada:
                resultado.append(cupitube[categoria])
                

    return resultado








   
  
   
    
   


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
 resultado = []
 for cupituber in cupitube.values():
    if (cupituber.get("country", "").lower() == pais_buscado.lower() and
        cupituber.get("category", "").lower() == categoria_buscada.lower() and
        cupituber.get("monetization_type", "").lower() == monetizacion_buscada.lower()):
        resultado.append(cupituber)
 return resultado



   
    
   
    
  


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo=None
    
    for cupituber in cupitube.values():
        if mas_antiguo is None:
            mas_antiguo=cupituber
            
        elif str(cupituber["started"]) < str(mas_antiguo["started"]) :
            mas_antiguo==cupituber
            
    return mas_antiguo
            
    
    
    

            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
   
    total_visitas = 0

    for lista_cupitubers in cupitube:
      
      categoria = cupitube[lista_cupitubers]["category"]
      vistas = cupitube[lista_cupitubers]["video_views"]

      if categoria.lower() == categoria_buscada.lower():
                total_visitas += vistas

    return total_visitas


    
    
   
    
   
  


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
   

    categorias = []

 
    for cupituber in cupitube.values():
        categoria =cupituber["category"]
        if categoria not in categorias:
            categorias.append(categoria)

    max_categoria = ""
    max_visitas = 0

   
    for categoria in categorias:
        visitas = obtener_visitas_por_categoria(cupitube, categoria)
        if visitas > max_visitas:
            max_visitas = visitas
            max_categoria = categoria

    return {"categoria": max_categoria, "visitas": max_visitas}

                
            
            
    
    
   
    
   

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:

    canales = list(cupitube.keys())
    
    for nombre in canales:
        nombre_sin_espacios = ""
        for letra in nombre:
            if letra != " ":
                nombre_sin_espacios += letra.lower()
        
        nombre_corto = ""
        for k in range(min(len(nombre_sin_espacios), 15)):
            nombre_corto += nombre_sin_espacios[k]
        
        correo = nombre_corto + "@cupitube.com"
        cupitube[nombre]["correo"] = correo


    
    
    
    
    
    
    
 
  


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
   
   
    categoria_info = obtener_categoria_con_mas_visitas(cupitube)
    categoria_top = categoria_info["categoria"]

    for canal in cupitube:
        datos = cupitube[canal]
        suscriptores = int(datos["subscribers"])
        videos = int(datos["video_count"])
        fecha = datos["started"]
        descripcion = datos["description"].lower()
        palabra = palabra_clave.lower()
        x={}
        if datos["category"] == categoria_top and suscriptores_min <= suscriptores and suscriptores <= suscriptores_max and  fecha_minima <= fecha <= fecha_maxima and videos >= videos_minimos and palabra in descripcion:
             x={canal: datos}
             
        else :
            x={}
    
    return x

    
   
    
   
    
  


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
  
   
    paises_categoria = {}

    for canal in cupitube:
        datos = cupitube[canal]
        categoria = datos["category"]
        pais = datos["country"]

        if categoria not in paises_categoria:
            paises_categoria[categoria] = []

        if pais not in paises_categoria[categoria]:
            paises_categoria[categoria].append(pais)

    return paises_categoria

  
    
  
    