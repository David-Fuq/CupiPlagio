# -*- coding: utf-8 -*-
"""
Created on Mon Apr 28 11:34:43 2025

@author: USER
"""

import csv

# Función cargar los datos del archivo 
def cargar_cupitube(archivo: str) -> dict:
    cupitube_por_pais = {}
    with open(archivo, "r", encoding="utf-8") as f:
        lector = csv.DictReader(f)
        for fila in lector:
            try:
                pais = fila["country"].strip()
                cupitube_info = {
                    "rank": int(fila["rank"].strip()),
                    "cupitube": fila["cupituber"].strip(),
                    "subscribers": int(fila["subscribers"].strip()),
                    "video_views": int(fila["video_views"].strip()),
                    "video_count": int(fila["video_count"].strip()),
                    "category": fila["category"].strip(),
                    "started": fila["started"].strip(),
                    "monetization_type": fila["monetization_type"].strip(),
                    "description": fila["description"].strip()
                }

                if pais not in cupitube_por_pais:
                    cupitube_por_pais[pais] = []
                cupitube_por_pais[pais].append(cupitube_info)

            except (KeyError, ValueError, AttributeError):
                continue
    return cupitube_por_pais

# Función para buscar un Cupitube por nombre
def buscar_por_nombre(cupitube: dict, nombre: str) -> dict:
    for pais, lista in cupitube.items():
        for canal in lista:
            if canal["cupitube"].lower() == nombre.lower():
                return canal
    return {}

# Función para buscar por categoría y rango de suscriptores
def buscar_por_categoria_y_suscriptores(cupitube: dict, categoria: str, min_subs: int, max_subs: int) -> list:
    resultados = []
    for pais, lista in cupitube.items():
        for canal in lista:
            if (canal["category"].lower() == categoria.lower() and
                min_subs <= canal["subscribers"] <= max_subs):
                resultados.append(canal)
    return resultados

# Función para encontrar el país con más Cupitubers
def pais_con_mas_cupitubes(cupitube: dict) -> str:
    max_pais = ""
    max_cantidad = 0
    for pais, lista in cupitube.items():
        if len(lista) > max_cantidad:
            max_cantidad = len(lista)
            max_pais = pais
    return max_pais

# Función principal
def main():
    archivo = "cupitube.csv"  # Nombre del archivo
    cupitube = cargar_cupitube(archivo)

    while True:
        print("\n--- MENÚ ---")
        print("1. Buscar Cupitube por nombre")
        print("2. Buscar Cupitubes por categoría y rango de suscriptores")
        print("3. Mostrar país con más Cupitubes")
        print("4. Salir")

        opcion = input("Selecciona una opción: ")

        if opcion == "1":
            nombre = input("Escribe el nombre del Cupitube: ")
            resultado = buscar_por_nombre(cupitube, nombre)
            if resultado:
                print("\nInformación encontrada:")
                for clave, valor in resultado.items():
                    print(f"{clave.capitalize()}: {valor}")
            else:
                print("\nNo se encontró el Cupitube.")

        elif opcion == "2":
            categoria = input("Escribe la categoría: ")
            min_subs = int(input("Número mínimo de suscriptores: "))
            max_subs = int(input("Número máximo de suscriptores: "))
            resultados = buscar_por_categoria_y_suscriptores(cupitube, categoria, min_subs, max_subs)
            if resultados:
                print("\nCupitubes encontrados:")
                for canal in resultados:
                    print(f"- {canal['cupitube']} ({canal['subscribers']} suscriptores)")
            else:
                print("\nNo se encontraron Cupitubes en ese rango y categoría.")

        elif opcion == "3":
            pais = pais_con_mas_cupitubes(cupitube)
            print(f"\nEl país con más Cupitubes es: {pais}")

        elif opcion == "4":
            print("¡Hasta luego!")
            break

        else:
            print("Opción no válida. Intenta de nuevo.")


if __name__ == "__main__":
    main()
