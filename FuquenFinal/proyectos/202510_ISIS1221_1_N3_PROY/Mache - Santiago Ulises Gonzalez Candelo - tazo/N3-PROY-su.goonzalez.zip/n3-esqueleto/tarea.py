def notacion_polaca(expresion: str)->int:
    """ Notación polaca
    Parámetros:
      expresion (str): Una cadena de texto que contiene una expresión en notación polaca, formada por
                       operadores +, -, *, / y números del 0 al 9.
    Retorno:
      int: Un número entero que representa el resultado de evaluar la expresión.
    """
    pass