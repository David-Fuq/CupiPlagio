#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 28 12:13:13 2025

@author: martina
"""

def cargar_cupitube(csv: str) -> dict:
    """
    Carga un archivo CSV con la información de los CupiTubers y los organiza
    en un diccionario donde la llave es el país de origen.
    """
    archivo = open(csv, "r", encoding="utf-8")
    resultado = {}
    linea = archivo.readline()

    while linea:
        datos = linea.strip().split(",")
        # Saltar encabezado y líneas mal formadas
        if datos and datos[0].lower() != "rank" and len(datos) >= 10:
            # Parseo de valores
            rank         = int(datos[0])
            cupituber    = datos[1].strip()
            subscribers  = int(datos[2])
            video_views  = int(datos[3])
            video_count  = int(datos[4])
            category     = datos[5].strip()
            started      = datos[6].strip()
            country      = datos[7].strip()
            monetization = datos[8].strip()
            description  = datos[9].strip()

            registro = {
                "rank": rank,
                "cupituber": cupituber,
                "subscribers": subscribers,
                "video_views": video_views,
                "video_count": video_count,
                "category": category,
                "started": started,
                "monetization_type": monetization,
                "description": description
            }

            # Agregar al país correspondiente
            if country in resultado:
                resultado[country].append(registro)
            else:
                resultado[country] = [registro]

        # Leer siguiente línea
        linea = archivo.readline()

    archivo.close()
    return resultado

d = cargar_cupitube('cupitube.csv')

#funcion 2
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict,
                                               suscriptores_min: int,
                                               suscriptores_max: int,
                                               categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores
    esté dentro del rango especificado. Toda comparación de categorías es en minúsculas.
    """
    resultados = []
    categoria_buscada = categoria_buscada.lower().strip()

    for pais in cupitube:
        registros = cupitube[pais]
        # asumimos que 'registros' es lista de dicts correctos
        for registro in registros:
            cat = registro["category"].lower().strip()
            subs = registro["subscribers"]
            if cat == categoria_buscada and suscriptores_min <= subs <= suscriptores_max:
                resultados.append(registro)
    return resultados


c = buscar_por_categoria_y_rango_suscriptores(d,1000000,111000000,"Gaming")

#funcion 3 
def buscar_cupitubers_por_pais_categoria_monetizacion(
    cupitube: dict,
    pais_buscado: str,
    categoria_buscada: str,
    monetizacion_buscada: str
) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados,
    sin importar mayúsculas o minúsculas.
    """
    resultados = []
    # Normalizar criterios de búsqueda
    pais_norm = pais_buscado.strip().lower()
    cat_norm = categoria_buscada.strip().lower()
    mon_norm = monetizacion_buscada.strip().lower()

    for pais, registros in cupitube.items():
        if pais.strip().lower() == pais_norm:
            for registro in registros:
                if (
                    registro["category"].strip().lower() == cat_norm and
                    registro["monetization_type"].strip().lower() == mon_norm
                ):
                    resultados.append(registro)
    return resultados

e = buscar_cupitubers_por_pais_categoria_monetizacion(d, "UK", "Gaming", "Crowdfunding")

#funcion 4 
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
            Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    """
    cupituber_antiguo = {}
    fecha_antigua = None

    for lista in cupitube.values():
        for i in lista:
            fecha = i["started"]
            if fecha_antigua is None or fecha < fecha_antigua:
                fecha_antigua = fecha
                cupituber_antiguo = i

    return cupituber_antiguo

f = buscar_cupituber_mas_antiguo(d)

#funcion 5
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers,
    sin importar mayúsculas o minúsculas.
    """
    total = 0
    cat_norm = categoria_buscada.strip().lower()

    for lista in cupitube.values():
        for i in lista:
            if i["category"].strip().lower() == cat_norm:
                total += i["video_views"]

    return total


g = obtener_visitas_por_categoria(d, "Gaming")

#funcion 6 
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    """
    # 1) Acumular vistas por categoría
    vistas_por_categoria = {}
    for lista in cupitube.values():
        for i in lista:
            cat = i["category"]
            #Revisar que esa categoria no tenga vistas 
            vistas_por_categoria[cat] = vistas_por_categoria.get(cat, 0) + i["video_views"]

    # 2) Si no hay datos, retornar vacío
    if not vistas_por_categoria:
        return {}

    # 3) Encontrar manualmente la categoría con más visitas
    categoria_max = None
    visitas_max = None
    for cat, vistas in vistas_por_categoria.items():
        if categoria_max is None or vistas > visitas_max:
            categoria_max = cat
            visitas_max = vistas

    return {"categoria": categoria_max, "visitas": visitas_max}

h = obtener_categoria_con_mas_visitas(d)


#Revisar en Cupitaller que si sirva y como revisalro 
#Funcion 7
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico
    y la añade al diccionario bajo la clave "correo".
    """
    for lista in cupitube.values():
        for i in lista:
            # 1) Limpiar el nombre: conservar solo caracteres alfanuméricos, en minúsculas
            limpio = "".join(ch for ch in i["cupituber"] if ch.isalnum()).lower()
            # Truncar a 15 caracteres si excede
            if len(limpio) > 15:
                limpio = limpio[:15]

            # 2) Extraer año y mes usando split
            partes = i["started"].split("-")
            anio_digitos_finales = partes[0][-2:]  # últimos 2 dígitos del año
            mes_digitos = partes[1]               # dos dígitos del mes

            # 3) Construir el correo y asignarlo
            correo = f"{limpio}.{anio_digitos_finales}{mes_digitos}@cupitube.com"
            i["correo"] = correo


#Funcion 8 
def recomendar_cupituber(cupitube: dict,
                         suscriptores_min: int,
                         suscriptores_max: int,
                         fecha_minima: str,
                         fecha_maxima: str,
                         videos_minimos: int,
                         palabra_clave: str) -> dict:
    """
    Recomienda al primer CupiTuber que cumpla con todos los criterios:
      - Pertenece a la categoría con más visitas acumuladas.
      - Tiene suscriptores dentro del rango [suscriptores_min, suscriptores_max].
      - Ha publicado al menos videos_minimos.
      - Empezó dentro de [fecha_minima, fecha_maxima].
      - Su descripción contiene palabra_clave (case-insensitive).
    """
    # Inicializamos el dict de retorno
    recomendado = {}

    # 1) Determinar la categoría top
    top = obtener_categoria_con_mas_visitas(cupitube)
    categoria_top = top.get("categoria", "").strip().lower()
    clave = palabra_clave.strip().lower()

    # 2) Recorrer todos los cupitubers
    for lista in cupitube.values():
        for i in lista:
            # Normalizar campos
            cat   = i["category"].strip().lower()
            desc  = i["description"].strip().lower()
            subs  = i["subscribers"]
            vids  = i["video_count"]
            start = i["started"]

            # Chequear todos los criterios
            if (cat == categoria_top
                and suscriptores_min <= subs <= suscriptores_max
                and vids >= videos_minimos
                and fecha_minima <= start <= fecha_maxima
                and clave in desc):
                recomendado = i
                return recomendado

    # Si no hay ninguno que cumpla, devolvemos el dict vacío
    return recomendado
i = recomendar_cupituber(d, 0, 500000000, "2005-10-02", "2015-06-04", 5 , "videos")



# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    Construye un dict que mapea cada categoría (en minúsculas) a la lista de países
    (sin duplicados) que tienen al menos un CupiTuber en esa categoría.
    """
    resultado = {}
    for pais, lista in cupitube.items():
        pais = pais.strip()
        for i in lista:
            # Normalizar la categoría a minúsculas para evitar problemas de mayúsculas/minúsculas
            cat_norm = i["category"].strip().lower()
            if cat_norm not in resultado:
                resultado[cat_norm] = []
            if pais not in resultado[cat_norm]:
                resultado[cat_norm].append(pais)
    return resultado


j = paises_por_categoria(d)