#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(ruta_archivo: str) -> dict:
    cupitube={}
   
    archivo=open(ruta_archivo, "r", encoding="utf-8")
    linea= archivo.readline().strip()
    linea= archivo.readline().strip()
        
    while len(linea)>0:
        oli=linea.split(",")
        cupituber={}
        cupituber["rank"]= int(oli[0])
        cupituber["cupituber"]=oli[1]
        cupituber["subscribers"]= int(oli[2])
        cupituber["video_views"]=int(oli[3])
        cupituber["video_count"]=int(oli[4])
        cupituber["category"]=oli[5]
        cupituber["started"]=oli[6]
        cupituber["monetization_type"]=oli[8]
        cupituber["description"]=oli[9]
        
        country=oli[7]
        
        if country not in cupitube:
           cupitube[country] =[]   
        cupitube[country].append(cupituber)   
        linea= archivo.readline() 
    archivo.close()    
    return cupitube   



# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    encontrado=[]
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (cupituber["category"]== categoria_buscada) and (suscriptores_max>=cupituber["subscribers"]>=suscriptores_min):
                encontrado.append(cupituber) 
    return encontrado       


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    encontrado=[]
    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado] :
          if (cupituber["category"]== categoria_buscada) and (cupituber["monetization_type"]== monetizacion_buscada):
                    encontrado.append(cupituber)
    return encontrado                
          

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    antiguo=None
    fecha_antigua=None
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            fecha= cupituber["started"]
            if antiguo==None or fecha<fecha_antigua:
               antiguo= cupituber
               fecha_antigua=fecha
    return antiguo           

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    vistas=0
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if cupituber["category"]== categoria_buscada:
                vistas+= cupituber["video_views"]
    return vistas            


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categorias=[]
    mas_visitas={}
    maximo=0
    categoria_max=0
    
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if cupituber["category"] not in categorias:
               categorias.append(cupituber["category"]) 
    
    for categoria in categorias:
        views= obtener_visitas_por_categoria(cupitube, categoria)       
        if maximo<views:
           maximo= views 
           categoria_max=categoria
           
    mas_visitas["categoria"]= categoria_max
    mas_visitas["visitas"]= maximo
    
    return mas_visitas


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for ola in cupitube.values():
        for persona in ola:
            nombre = persona["cupituber"]
            nombrecito = []
            for letra in nombre:
                if (letra.isalnum()) and (len(nombrecito) < 15):
                    miniletra= letra.lower()
                    nombrecito.append(miniletra)
    
            supernombre= "".join(nombrecito)               
            año = persona["started"][2:4]
            mes = persona["started"][5:7]
            correito = supernombre + "." + año + mes + "@cupitube.com"
            persona["correo"] = correito


def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
 
    cupi= obtener_categoria_con_mas_visitas(cupitube)
    categoria_max = cupi["categoria"]
    clave = palabra_clave.lower()
    cupi_recomendado = {}
    encontrado = False

    for pais in cupitube:
        cupitubers = cupitube[pais]
        i = 0
        while i < len(cupitubers) and encontrado==False:
            que = cupitubers[i]
            if (que["category"] == categoria_max) and (suscriptores_min <= que["subscribers"] <= suscriptores_max) and (que["video_count"] >= videos_minimos) and (fecha_minima <= que["started"] <= fecha_maxima)and(clave in que["description"].lower()):
                cupi_recomendado = que
                encontrado = True
            i += 1
    return cupi_recomendado
      


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    ok= {}
    for pais in cupitube:
        for personitas in cupitube[pais]:
            categoria= personitas["category"]
            if categoria not in ok: 
               ok[categoria]=[]
            if pais not in ok[categoria]:
               ok[categoria].append(pais)
    return ok           
                