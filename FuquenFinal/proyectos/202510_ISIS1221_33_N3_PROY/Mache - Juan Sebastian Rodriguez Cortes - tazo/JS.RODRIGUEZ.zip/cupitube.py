#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1:


def cargar_cupitube(archivo: str) -> dict:

    dic_paises = {}
    archivo_cupitubers = open(archivo, "r", encoding="utf-8")
    titulos = archivo_cupitubers.readline().split(",")
   

    linea = archivo_cupitubers.readline().strip()
    while len(linea) > 0:
        datos = linea.split(",")
        pais = datos[7]
        datos_cupituber = {}
        datos_cupituber["rank"] = datos[0]
        datos_cupituber["cupituber"] = datos[1]
        datos_cupituber["suscriptores"] = datos[2]
        datos_cupituber["visualizaciones"] = int(datos[3])
        datos_cupituber["video_count"] = datos[4]
        datos_cupituber["categoria"] = datos[5]
        datos_cupituber["fecha_inicio"] = datos[6]
        datos_cupituber["tipo_monetizacion"] = datos[8]
        datos_cupituber["descripcion"] = datos[9]
        if dic_paises.get(pais) is None:
            dic_paises[pais] = [datos_cupituber]
        else:
            dic_paises[pais].append(datos_cupituber)
        linea = archivo_cupitubers.readline()

    archivo_cupitubers.close()
    return dic_paises


archivo = cargar_cupitube("cupitube.csv")


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    Busca los CupiTubers que pertenecen a la categoría dada y cuyo número de suscriptores esté dentro del rango especificado.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
        suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
        categoria_buscada (str): Categoría de los videos del CupiTuber que se busca.

    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que cumplen con todos los criterios de búsqueda.
              Si no se encuentra ningún CupiTuber, retorna una lista vacía.

    Ejemplo:
        Para los siguientes valores:
        - suscriptores_min = 1000000
        - suscriptores_max = 111000000
        - categoria_buscada = "Gaming"

        Hay exactamente 102 cupitubers que cumplen con los criterios de búsqueda y que deben ser reportados en la lista retornada.
        ATENCIÓN: Este solo es un ejemplo de consulta exitosa en el dataset. Su función debe ser implementada para cualquier valor dado de: suscriptores_min, suscriptores_max y categoria_buscada.
    """
    filtrado = []
    for i in cupitube:
        cupitubers = cupitube[i]
        for cupituber in cupitubers:

            if suscriptores_max >= int(cupituber["suscriptores"]) >= suscriptores_min and categoria_buscada == cupituber["categoria"]:
                filtrado.append(cupituber)

    return filtrado



# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.

    Parámetros:
        cupitube (dict): Diccionario de países con la información de los CupiTubers.
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).

    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada

    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """
    filtrado = []
    for i in cupitube:
        cupitubers = cupitube[i]
        if i == pais_buscado:
            for cupituber in cupitubers:
                if cupituber["tipo_monetizacion"] == monetizacion_buscada and cupituber["categoria"] == categoria_buscada:
                    filtrado.append(cupituber)
    return filtrado





# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.

    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.

        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
    filtrado = {}
    fechagrande = ""
    for i in cupitube:

        cupitubers = cupitube[i]
        for cupituber in cupitubers:
            if fechagrande == "":
                fechagrande = cupituber["fecha_inicio"]
            if cupituber["fecha_inicio"] < fechagrande:
                filtrado = (cupituber)
                fechagrande = cupituber["fecha_inicio"]
    return filtrado





# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    Obtiene el número total de visitas (video_views) acumuladas para una categoría dada de CupiTubers.

    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       categoria_buscada (str): Nombre de la categoría de interés.

    Retorno:
       int: Número total de visitas para la categoría especificada.
           - Si la categoría aparece en múltiples CupiTubers, sus visitas se suman.
           - Si la categoría no está presente en los datos, el resultado a retornar será 0.

    Ejemplo:
       Dada la categoría "Music", hay un total de 2906210355935 vistas.
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: categoria_busqueda.
    """
    visitas_contador = 0
    for i in cupitube:
        
        cupitubers = cupitube[i]
        for cupituber in cupitubers:
            if cupituber["categoria"]==categoria_buscada:
                
                visitas_contador += int(cupituber["visualizaciones"])
    return visitas_contador
    



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
    """
    

    
    categoriavisitas={}
    
    for i in cupitube : 
        cupitubers= cupitube[i]
        
        for cupituber in cupitubers: 
            if cupituber["categoria"] not in categoriavisitas.keys(): 
                
            
             visitasx= obtener_visitas_por_categoria(archivo,cupituber["categoria"]) 
             categoriavisitas[cupituber["categoria"]]=visitasx
            
    conteo=0 
    categoriamasvisitas={
        "categoria":""
         ,"visitas": 0}
    for i in categoriavisitas: 
        
        if categoriavisitas[i]>conteo:
            conteo = categoriavisitas[i]
            x= i 
            categoriamasvisitas["categoria"]= x
            categoriamasvisitas["visitas"]= conteo
    return categoriamasvisitas




            
            
            
            
            
            
            
   
                
                
   
            

   


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea una dirección de correo electrónico para cada CupiTuber siguiendo un formato específico y la añade al diccionario.
    Esta función modifica de forma permanente el diccionario recibido como parámetro, añadiendo una nueva llave "correo" con el valor asociado: [X].[Y][Z]@cupitube.com
    Nota: Aquí, los corchetes se usan para indicar la ubicación para la información definida a continuación:

    Donde:
        - [X]: Nombre del CupiTuber sin espacios y sin caracteres especiales.
        - [Y]: Últimos dos dígitos del año de inicio del CupiTuber.
        - [Z]: Los dos dígitos del mes de inicio del CupiTuber.

    Reglas de formato:
        - El nombre del CupiTuber debe estar libre de espacios y caracteres especiales.
              - Un carácter es especial si no es alfanumérico.
        - La longitud máxima del nombre debe ser de 15 caracteres. Si se excede este límite, se toman solo los primeros 15 caracteres.
        - Se debe añadir un punto (.) inmediatamente después del nombre.
        - A continuación, se agregan los últimos dos dígitos del año de inicio.
        - Luego, se añaden los dos dígitos del mes de inicio (sin guión o separador entre año y mes).
        - El correo generado debe estar siempre en minúsculas.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Ejemplo:
        Para un CupiTuber con nombre "@PewDiePie" y fecha de inicio "2010-06-15",
        el correo generado sería: "pewdiepie.1006@cupitube.com"

    Nota:
        La función str.isalnum() permite verificar si una cadena es alfanumérica:
        https://docs.python.org/es/3/library/stdtypes.html#str.isalnum
    """
    for i in cupitube: 
        cupitubers= cupitube[i]
        for cupituber in cupitubers: 
            nombre=cupituber["cupituber"]
            nombre= nombre.lower()
            for letra in nombre: 
                if letra.isalnum()==False:
                   nombre= nombre.replace(letra,"")
            if len(nombre)> 15: 
                nombre=nombre[0:15]
            correo= nombre+"."+cupituber["fecha_inicio"][2:4] + \
                cupituber["fecha_inicio"][5:7]+"@cupitube.com"
            cupituber["correo"]=correo
            



# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    """
    Recomienda al primer (uno solo) CupiTuber que cumpla con todos los criterios de búsqueda especificados.

    La función busca un CupiTuber que:
       - Pertenece a la categoría con más visitas totales.
       - Tiene un número de suscriptores dentro del rango especificado.
       - Ha publicado al menos la cantidad mínima de videos indicada.
       - Ha comenzado a publicar dentro del rango de fechas especificado.
       - Contiene la palabra clave dada como parte de su descripción (sin distinguir entre mayúsculas/minúsculas).

    Parámetros:
       cupitube (dict): Diccionario con la información de los CupiTubers.
       suscriptores_min (int): Cantidad mínima de suscriptores requerida (inclusiva).
       suscriptores_max (int): Cantidad máxima de suscriptores permitida (inclusiva).
       fecha_minima (str): Fecha mínima en formato YYYY-MM-DD (inclusiva).
       fecha_maxima (str): Fecha máxima en formato YYYY-MM-DD (inclusiva).
       videos_minimos (int): Cantidad mínima de videos requerida.
       palabra_clave (str): Palabra clave que debe estar presente como parte de la descripción.

    Retorno:
       dict: Información del primer CupiTuber que cumpla con todos los criterios.
             Si no se encuentra ningún CupiTuber que cumpla, retorna un diccionario vacío.

    Notas:
       - La búsqueda de la palabra clave no distingue entre mayúsculas y minúsculas.
         Por ejemplo, si la palabra clave es "gAMer" y la descripción contiene "Gamer ingenioso", el criterio de palabra clave se cumple para ese CupiTuber.
       - Por simplicidad, la búsqueda de la palabra clave se realiza también en subcadenas. 
         Por ejemplo, si la palabra clave es "car", el criterio de palabra clave se cumpliría para descripciones que contengan palabras como: "car", "card", "scarce", o "carpet", etc.
    """
    recomendado={}
    
    for i in cupitube:
        cupitubers=cupitube[i]
        for cupituber in cupitubers:
          categoriagrande= obtener_categoria_con_mas_visitas(archivo)  
          descripcion= cupituber["descripcion"].lower().replace(" ","")
          
          if cupituber["categoria"]== categoriagrande["categoria"]:
              if int(cupituber["suscriptores"])>=suscriptores_min and int(cupituber["suscriptores"])<= suscriptores_max:
                  if int(cupituber["video_count"])>=videos_minimos:
                      if cupituber["fecha_inicio"]>= fecha_minima and cupituber["fecha_inicio"]<= fecha_maxima:
                          if palabra_clave.lower() in descripcion:
                              recomendado= cupituber
                             
    return recomendado


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    """
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"

    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
    """
    categoria_de_paises = {}

    for pais in cupitube:
        paises = cupitube[pais]

        for cupituber in paises:
            categoria = cupituber["categoria"]
            
            if categoria not in categoria_de_paises:
                categoria_de_paises[categoria] = []
            
            if pais not in categoria_de_paises[categoria]:
                categoria_de_paises[categoria].append(pais)

    return categoria_de_paises

   

