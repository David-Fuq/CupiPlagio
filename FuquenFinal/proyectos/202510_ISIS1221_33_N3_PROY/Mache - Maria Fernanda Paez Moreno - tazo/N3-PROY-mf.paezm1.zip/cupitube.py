#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitube = {}
    
    file = open(archivo, "r", encoding="utf-8")
    linea = file.readline().strip("\n")
    linea = file.readline().strip("\n")
    
    while len(linea) > 0:
        info = linea.split(",")
        
        cupituber = {}
        #preparo llave país que va a ir en dict cupitube
        #cómo saco esto para que siga teniedno al país como variable y no me 'resetee' la lista cada vez que entra en el bucleSOLVEEED
        country = info[7]
        
        
        #creo dict cupituber
        cupituber["rank"] = int(info[0])
        cupituber["cupituber"] = info[1]
        cupituber["subscribers"] = int(info[2])
        cupituber["video_views"] = int(info[3])
        cupituber["video_count"] = int(info[4])
        cupituber["category"] = info[5]
        cupituber["started"] = info[6]
        cupituber["monetization_type"] = info[8]
        cupituber["description"] = info[9]
        
        #añado cupituber a lista de su respectivo país en cupitube
        if country in cupitube:
            cupitube[country].append(cupituber)
        else:
            cupitube[country] = [cupituber]
            
        
        linea = file.readline().strip("\n")
    file.close()
    return cupitube





# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    ans = []
    
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if cupituber["subscribers"] >= suscriptores_min and cupituber["subscribers"] <= suscriptores_max and cupituber["category"] == categoria_buscada:
                ans.append(cupituber)
    return ans



# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    ans = []
    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
                    ans.append(cupituber)
    return ans




# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    oldest = {'rank': 51, 'cupituber': 'Katy Pe(rry', 'subscribers': 43200000, 'video_views': 23966278157, 'video_count': 118, 'category': 'Music', 'started': '2008-12-05', 'monetization_type': 'Merchandising', 'description': 'wEird fActs aND ExPERiments!'}
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if cupituber["started"] < oldest["started"]:
                oldest = cupituber
    return oldest

   
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    suma_visitas = 0
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if cupituber["category"] == categoria_buscada:
                suma_visitas += cupituber["video_views"]
    return suma_visitas



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    cat_most_views = {}
    cat_max = ""
    max_views = 0
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            categoria = cupituber["category"]
            views = obtener_visitas_por_categoria(cupitube, categoria)
            if views > max_views:
                max_views = views
                cat_max = categoria
    
    cat_most_views = {"categoria": cat_max, "visitas": max_views}       
    return cat_most_views





# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:          
            nombre = cupituber["cupituber"]
            name = ""
            i = 0
            while len(name) < 15 and i < len(nombre):
                if nombre[i].isalnum() == True:
                    name += nombre[i].lower()
                i += 1 
                numbers = cupituber["started"][2:4] + cupituber["started"][5:7]
                mail = f"{name}.{numbers}@cupitube.com"
                cupituber["correo"] = mail




# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    recomendado = {}
    
    cat_ideal = obtener_categoria_con_mas_visitas(cupitube)
    cat_y_rangosubs = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, cat_ideal["categoria"])#lista
    key_word = palabra_clave.lower()
    
    for cupitubers in cupitube.values():
        i = 0
        while i < len(cupitubers) and recomendado == {}:
            cat_ran = False
            e = 0
            description = cupitubers[i]["description"].lower()
            fecha = cupitubers[i]["started"] >= fecha_minima and cupitubers[i]["started"] <= fecha_maxima
            while e < len(cat_y_rangosubs):
                if cat_y_rangosubs[e]["cupituber"] == cupitubers[i]["cupituber"]:
                    cat_ran = True
                e += 1
            if cat_ran == True and cupitubers[i]["video_count"] >= videos_minimos and key_word in description and fecha == True:
                recomendado = cupitubers[i]
            i += 1
    return recomendado
                


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    rta = {}
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for cupituber in cupitubers:
            categoria = cupituber["category"]
            if categoria in rta:
                if pais not in rta[categoria]:
                    rta[categoria].append(pais)
            else:
                rta[cupituber["category"]] = [pais]
    return rta