#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

def cargar_cupitube(archivo: str) -> dict:
    cupitubers = {}
    archivo = open("./cupitube.csv", "r", encoding="utf-8")
    archivo.readline()
    linea = archivo.readline()
    while linea != "" :
        lectura_separada = linea.strip().split(",")
        rank = int(lectura_separada[0])
        cupituber = lectura_separada[1].strip()
        subscribers = int(lectura_separada[2])
        video_views = int(lectura_separada[3])
        video_count = int(lectura_separada[4])
        category = lectura_separada[5].strip()
        started = lectura_separada[6].strip()
        country = lectura_separada[7].strip()
        monetization_type = lectura_separada[8].strip()
        description = lectura_separada[9].strip()
        
        diccionario = {
            "rank": rank,
            "cupituber": cupituber,
            "subscribers": subscribers,
            "video_views": video_views,
            "video_count": video_count,
            "category": category,
            "country": country,
            "started": started,
            "monetization_type": monetization_type,
            "description": description
            }
        if country in cupitubers:
            cupitubers[country].append(diccionario)
        else:
            cupitubers[country] = []
            cupitubers[country].append(diccionario)
        linea = archivo.readline()
    archivo.close()
    return cupitubers

    #TODO 1: Implemente la función tal y como se describe en la documentación.


def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    busqueda = []
    for pais in cupitube.values():
        for user in pais:
            if (suscriptores_min <= user["subscribers"] <= suscriptores_max ) and user["category"].lower() == categoria_buscada.lower():
                busqueda.append(user)
    return busqueda
    #TODO 2: Implemente la función tal y como se describe en la documentación.

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    busqueda = []
    for pais in cupitube:
        users = cupitube[pais]
        if pais.lower() == pais_buscado.lower():
            for cupituber in users:
                if cupituber["category"].lower() == categoria_buscada.lower() and cupituber["monetization_type"].lower() == monetizacion_buscada.lower():
                    busqueda.append(cupituber)
    return busqueda
                    
    #TODO 3: Implemente la función tal y como se describe en la documentación.

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    antiguo = None
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if antiguo ==  None:
                antiguo = cupituber
            else: 
                if cupituber["started"] < antiguo["started"]:
                    antiguo = cupituber
    
    return antiguo
    #TODO 4: Implemente la función tal y como se describe en la documentación.
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    contador = 0 
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if cupituber["category"].lower() == categoria_buscada.lower():
                contador += cupituber["video_views"]
    return contador

    #TODO 5: Implemente la función tal y como se describe en la documentación.
# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {}

    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = visitas
            else:
                visitas_por_categoria[categoria] += visitas
                
    categoria_max = None
    visitas_max = -1
    for categoria in visitas_por_categoria:
        if visitas_por_categoria[categoria] > visitas_max:
            visitas_max = visitas_por_categoria[categoria]
            categoria_max = categoria

    return {
        "categoria": categoria_max,
        "visitas": visitas_max
    }

    #TODO 6: Implemente la función tal y como se describe en la documentación.


# Funcion 7:
def generar_correos_cupitubers(cupitube: dict) -> None:
    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            nombre_original = cupituber["cupituber"]
            nombre_limpio = ""
            for caracter in nombre_original:
                if caracter.isalnum() == True:
                    nombre_limpio += caracter
                    if len(nombre_limpio) == 15:
                        break
                    
            nombre_limpio = nombre_limpio.lower()

            fecha_inicio = cupituber["started"]
            anio = fecha_inicio[:4]
            mes = fecha_inicio[5:7]
            ultimos_dos_anio = anio[-2:]

            correo = nombre_limpio + "." + ultimos_dos_anio + mes + "@cupitube.com"
            cupituber["correo"] = correo

    #TODO 7: Implemente la función tal y como se describe en la documentación.

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    diccionario_categoria = obtener_categoria_con_mas_visitas(cupitube)
    categoria_objetivo = diccionario_categoria["categoria"]        

    for cupitubers in cupitube.values():
        for cupituber in cupitubers:
            if categoria_objetivo and cupituber["category"].lower() == categoria_objetivo.lower():
                if suscriptores_min <= cupituber["subscribers"] <= suscriptores_max:
                    if cupituber["video_count"] >= videos_minimos:
                        if fecha_minima <= cupituber["started"] <= fecha_maxima:
                            if palabra_clave.lower() in cupituber["description"].lower():
                                return cupituber
    return {}
    #TODO 8: Implemente la función tal y como se describe en la documentación.
# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    resultado = {}
    
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for cupituber in cupitubers:
            categoria = cupituber["category"]
            if categoria not in resultado:
                resultado[categoria] = []
            if pais not in resultado[categoria]:
                resultado[categoria].append(pais)
        
    return resultado
    #TODO 9: Implemente la función tal y como se describe en la documentación.
