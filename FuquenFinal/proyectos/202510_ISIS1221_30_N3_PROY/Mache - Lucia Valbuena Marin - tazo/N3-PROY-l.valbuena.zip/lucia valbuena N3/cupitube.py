def cargar_cupitube (archivo: str) -> dict: 
    

    archivo = open( 'cupitube.csv', 'r', encoding = "utf-8")
    archivo.readline()
    linea = archivo.readline().strip()
    
    cupitube = {} 
    
    while linea != "":
      
        titulos = linea.split(",")
        
        if len(titulos) >= 10:
        
            rank = int(titulos[0].strip())
            cupituber = titulos[1].strip()
            subscribers = int(titulos[2].strip())
            video_views = int(titulos[3].strip())
            video_count = int(titulos[4].strip())
            category = titulos[5].strip()
            started = titulos[6].strip()
            pais = titulos[7].strip()
            monetization_type = titulos[8].strip()
            description = titulos[9].strip()
            
            print(video_views)
        
            cupituber = { 
           "cupituber": cupituber,
            
           "rank": rank,
           
           "subscribers": subscribers,
          
           "video_views": video_views,
          
           "video_count": video_count,
          
           "category": category,
          
           "started": started,
          
           "country": pais,
          
           "monetization_type": monetization_type,
          
           "description": description
          
           }
       
        
            pais = cupituber["country"]
        
            if pais not in cupitube:
            
              cupitube[pais] = []
            
            cupitube[pais].append(cupituber)
        
        linea = archivo.readline().strip()
            
    archivo.close()
    return cupitube 

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:

    resultado = []
    
    for pais in cupitube: 
        
        for cupituber in cupitube[pais]: 
            
            if cupituber["category"] == categoria_buscada and suscriptores_min <= int(cupituber["subscribers"]) <= suscriptores_max: 
                    
                    resultado.append(cupituber)
                    
    return resultado 

def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:

  
   resultado = [] 
   
   
   if pais_buscado in cupitube: 
       
       lista_cupitubers = cupitube[pais_buscado]
       
              
       for cupituber in lista_cupitubers: 
           
           if(cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada):
               
               resultado.append(cupituber)
           
         
           return resultado

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
 
   mas_antiguo = None 
   
   for pais in cupitube: 
       
       for cupituber in cupitube[pais]: 
           
           if mas_antiguo == None: 
               
               mas_antiguo = cupituber 
              
               
           elif cupituber["started"] < mas_antiguo["started"]: 
              
               mas_antiguo = cupituber
              
              
   return mas_antiguo

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
   
    total_vistas = 0
    
    for pais in cupitube:
        
        for cupituber in cupitube[pais]: 
            
            
            if cupituber["category"] == categoria_buscada: 
                
                 total_vistas += int(cupituber["video_views"])
                
    return total_vistas 

def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    
    vistas_por_categoria = {}
    
    for pais in cupitube: 
        
        for cupituber in cupitube[pais]: 
        
            
            categoria = cupituber["category"]
            vistas = cupituber["video_views"]
            
            if categoria not in vistas_por_categoria: 
                
                vistas_por_categoria[categoria] = vistas
                
                
            else:
                vistas_por_categoria[categoria] += vistas
                
                
    return vistas_por_categoria

def crear_correos (cupitube: dict) ->  None: 

    
    for pais in cupitube: 
        
        for cupituber in cupitube[pais]:
            
            
            nombre = cupituber["cupituber"] 
            
            nombre_limpio = ""
                               
            for caracter in nombre: 
                               
                if ((caracter >= "a" and caracter <= "z") #Si el caracter esta entre a y z incluyendo a y z (minusculas)
                or (caracter >= "A" and caracter <= "Z") #O esta entre A y Z incluyendo A y Z (mayusculas)
                or (caracter >= "0" and caracter <= "9")): #O sigue un rango de 0 a 9 incluyendo 0 y 9
                
                    
                    nombre_limpio += caracter
                    
            nombre_limpio = nombre_limpio[:15].lower() 
                                                       
            fecha = cupituber["started"] 
            
            lista_fecha = fecha.split("-")
            
            if len(lista_fecha)>=2:
            
                año = str(lista_fecha[0][2:])
        
                mes = lista_fecha[1]
            
                correo = nombre_limpio + "." + año + mes + "@cupitube.com"
        
                cupituber["correo"] = correo 
            
       
            
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:

    
        vistas_totales_por_categoria = {} 

        for pais in cupitube:
        
            for cupituber in cupitube[pais]:
            
                categoria = cupituber["category"]
                vistas = cupituber["video_views"]
              
                if categoria not in vistas_totales_por_categoria: 
                
                    vistas_totales_por_categoria[categoria] = vistas
                    
                
                else: 
                
                    vistas_totales_por_categoria[categoria] += vistas
                
                

            categoria_mas_vista = None 
            vistas_maximas = 0
            
        for categoria in vistas_totales_por_categoria:
            
            total_vistas = vistas_totales_por_categoria[categoria]
            total_vistas = int(total_vistas)
            
            if total_vistas > vistas_maximas:
                    
                categoria_mas_vista = categoria
                    
                vistas_maximas = vistas_totales_por_categoria[categoria]
            
            
        palabra = palabra_clave.lower()   
        
        for pais in cupitube: 
        
            for cupituber in cupitube[pais]: 
            
            
                suscriptores = int(cupituber["subscribers"])
                fecha = cupituber["started"]
                videos = int(cupituber["video_count"])
                descripcion = cupituber["description"]
                
            
            
                if (cupituber["category"] == categoria_mas_vista and  
                    
                    suscriptores_min <= suscriptores <= suscriptores_max and
                    
                    fecha_minima <= fecha <= fecha_maxima and 
                    
                    videos >= videos_minimos 
                    
                    and palabra in descripcion.lower()):
                
                    
    
                    return cupituber 
        
            return {} 
        
        
        
            
def paises_por_categoria(cupitube: dict) -> dict:
    

    paises_por_categoria = {} #Diccionario que va a almacenar la info
    
    for pais in cupitube: 
        
        for cupituber in cupitube[pais]:
            
            categoria = cupituber["category"] #definimos la variable categoria
            
            
            if categoria not in paises_por_categoria:
                
                paises_por_categoria[categoria] = []

                
            if pais not in paises_por_categoria[categoria]:

                
                paises_por_categoria[categoria].append(pais)
                
    return paises_por_categoria
            
            