#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    resultado = {}

    f = open("cupitube.csv", "r", encoding="utf-8")
    primera_linea = f.readline()

    linea = f.readline()

    while linea:
        datos = linea.strip().split(",")
    
        cupituber = {
            "rank": int(datos[0]),
            "cupituber": str(datos[1]),
            "subscribers": int(datos[2]),
            "video_views": int(datos[3]),
            "video_count": int(datos[4]),
            "category": str(datos[5]),
            "started": str(datos[6]),
            "monetization_type": str(datos[8]),
            "description": str(datos[9])
            }

        pais = datos[7].strip()

        if pais not in resultado:
            resultado[pais] = []
            resultado[pais].append(cupituber)
    
        linea = f.readline()
    
    return resultado
    

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    respuesta = []
    
    for pais in cupitube:
        lista_de_todos_cupitubers = cupitube[pais]
        for cupituber in lista_de_todos_cupitubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            
            if categoria == categoria_buscada and suscriptores_min <= suscriptores <= suscriptores_max:
                respuesta.append(cupituber)
            
    return respuesta
    


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    
    for pais in cupitube:
        lista_todos_paises_cupitubers = cupitube[pais]
        
        if pais == pais_buscado:
            for cupituber in lista_todos_paises_cupitubers:
                categoria = cupituber["category"]
                monetizacion = cupituber["monetization_type"]
                
                if categoria == categoria_buscada and monetizacion == monetizacion_buscada:
                    resultado.append(cupituber)
        
    return resultado


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    contador = 0
    mas_antiguo = None
    fecha_mas_antigua = "9999-12-31"  
        
    for pais in cupitube:
            lista_pais = cupitube[pais]
            for cupituber in lista_pais:
                fecha_inicio = cupituber["started"]
                contador += 1
                
                if fecha_inicio < fecha_mas_antigua:
                    fecha_mas_antigua = fecha_inicio
                    mas_antiguo = cupituber
        

    return mas_antiguo            
                
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    suma_visitas = 0
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for cupituber in lista_pais:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            if categoria == categoria_buscada:
                suma_visitas = suma_visitas + visitas
            
    return suma_visitas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    resultado = {}
        
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for cupituber in lista_pais:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            if categoria not in resultado:
                resultado[categoria] = 0
                    
            resultado[categoria] += visitas
                    
            visitas_max = 0
            categoria_max = ""
                
    for categoria, suma_total_visitas in resultado.items():
        if suma_total_visitas > visitas_max:
            visitas_max = suma_total_visitas
            categoria_max = categoria
                
            
    return {"categoria": categoria_max, "visitas": visitas_max}



# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        lista_pais = cupitube[pais]
        for cupituber in lista_pais:
            nombre_cupituber = cupituber["cupituber"]
            fecha_inicio = cupituber["started"]

            nombre_editado = "".join(c for c in nombre_cupituber if c.isalnum())[:15]

            
            anio = fecha_inicio[2:4]  
            mes = fecha_inicio[5:7]   

            correo = f"{nombre_editado}.{anio}{mes}@cupitube.com".lower()

            cupituber["correo"] = correo


# Función 8:
def recomendar_cupituberr(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    
    categoria_mas_vistas = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    palabra_clave = palabra_clave.lower()

    for pais in cupitube:
        lista_pais = cupitube[pais]
        for cupituber in lista_pais:
            categoria = cupituber["category"]
            subs = cupituber["subscribers"]
            fecha = cupituber["started"]
            num_videos = cupituber["video_count"]
            descripcion = cupituber["description"].lower()

            if (
                categoria == categoria_mas_vistas and
                suscriptores_min <= subs <= suscriptores_max and
                fecha_minima <= fecha <= fecha_maxima and
                num_videos >= videos_minimos and
                palabra_clave in descripcion
            ):
                return cupituber  
    else:
        return {} 
    


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resultado = {}

    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]

           
            if categoria not in resultado:
                resultado[categoria] = []

            
            if pais not in resultado[categoria]:
                resultado[categoria].append(pais)

    return resultado


