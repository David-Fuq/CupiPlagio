#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    """
    Carga un archivo en formato CSV (Comma-Separated Values) con la información de los CupiTubers y 
    los organiza en un diccionario donde la llave es el país de origen.
    ...
    """
    cupitube = {}

    try:
        with open(archivo, "r", encoding="utf-8") as f:
            f.readline()  # Encabezado

            for linea in f:
                linea = linea.strip()
                partes = linea.split(",")

                if len(partes) < 10:
                    continue

                datos = {
                    "rank": int(partes[0].strip()),
                    "cupituber": partes[1].strip(),
                    "subscribers": int(partes[2].strip()),
                    "video_views": int(partes[3].strip()),
                    "video_count": int(partes[4].strip()),
                    "category": partes[5].strip(),
                    "started": partes[6].strip(),
                    "monetization_type": partes[8].strip(),
                    "description": partes[9].strip()
                }

                pais = partes[7].strip()

                if pais not in cupitube:
                    cupitube[pais] = []

                cupitube[pais].append(datos)

        return cupitube
    except:
        return {}

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    """
    ...
    """
    resultado = []

    for lista in cupitube.values():
        for cupituber in lista:
            if (cupituber["category"] == categoria_buscada and
                suscriptores_min <= cupituber["subscribers"] <= suscriptores_max):
                resultado.append(cupituber)

    return resultado

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    """
    ...
    """
    resultado = []

    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if (cupituber["category"] == categoria_buscada and
                cupituber["monetization_type"] == monetizacion_buscada):
                resultado.append(cupituber)

    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    """
    ...
    """
    mas_antiguo = None

    for lista in cupitube.values():
        for cupituber in lista:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber

    return mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    """
    ...
    """
    total = 0

    for lista in cupitube.values():
        for cupituber in lista:
            if cupituber["category"] == categoria_buscada:
                total += cupituber["video_views"]

    return total

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    """
    ...
    """
    visitas = {}

    for lista in cupitube.values():
        for c in lista:
            categoria = c["category"]
            visitas[categoria] = visitas.get(categoria, 0) + c["video_views"]

    categoria_max = None
    visitas_max = -1

    for cat, total in visitas.items():
        if total > visitas_max:
            categoria_max = cat
            visitas_max = total

    return {"categoria": categoria_max, "visitas": visitas_max}

# Función 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    ...
    """
    for lista in cupitube.values():
        for c in lista:
            nombre = ''.join([ch for ch in c["cupituber"] if ch.isalnum()])[:15]
            año = c["started"].split("-")[0][-2:]
            mes = c["started"].split("-")[1]
            c["correo"] = f"{nombre.lower()}.{año}{mes}@cupitube.com"

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    """
    ...
    """
    if palabra_clave.strip() == "":
        return {}

    categoria_objetivo = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    palabra_clave = palabra_clave.lower()

    for lista in cupitube.values():
        for c in lista:
            if (c["category"] == categoria_objetivo and
                suscriptores_min <= c["subscribers"] <= suscriptores_max and
                fecha_minima <= c["started"] <= fecha_maxima and
                c["video_count"] >= videos_minimos and
                palabra_clave in c["description"].lower()):
                return c

    return {}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    """
    ...
    """
    resultado = {}

    for pais, lista in cupitube.items():
        for c in lista:
            cat = c["category"]
            if cat not in resultado:
                resultado[cat] = []
            if pais not in resultado[cat]:
                resultado[cat].append(pais)

    return resultado
