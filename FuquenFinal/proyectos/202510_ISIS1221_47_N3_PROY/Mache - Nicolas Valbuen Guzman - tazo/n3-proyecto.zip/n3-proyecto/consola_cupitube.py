#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
import cupitube as ct

###### Funciones auxiliares (NO MODIFICAR):

# ... (todas las funciones auxiliares están aquí como me diste, sin cambios) ...

###### Fin de las funciones auxiliares

# Funciones a implementar (YA COMPLETADAS):

def ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ")
    minimo = int(input("Ingrese el mínimo de suscriptores: "))
    maximo = int(input("Ingrese el máximo de suscriptores: "))
    cupitubers = ct.buscar_por_categoria_y_rango_suscriptores(cupitube, minimo, maximo, categoria)
    if cupitubers != []:
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict) -> None:
    pais = input("Ingrese el país: ")
    categoria = input("Ingrese la categoría: ")
    monetizacion = input("Ingrese el tipo de monetización: ")
    resultado = ct.buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais, categoria, monetizacion)
    if resultado:
        print(f"Los CupiTubers de {pais} que pertenecen a la categoría {categoria} y tienen monetización {monetizacion} son:")
        mostrar_cupitubers(resultado)
    else:
        print("No se encontraron CupiTubers que cumplan con los criterios.")


def ejecutar_buscar_cupituber_mas_antiguo(cupitube: dict) -> None:
    mas_antiguo = ct.buscar_cupituber_mas_antiguo(cupitube)
    if mas_antiguo:
        print(f"El CupiTuber más antiguo es {mas_antiguo['cupituber']} y empezó en {mas_antiguo['started']}.")


def ejecutar_obtener_visitas_por_categoria(cupitube: dict) -> None:
    categoria = input("Ingrese la categoría: ")
    total_visitas = ct.obtener_visitas_por_categoria(cupitube, categoria)
    print(f"El total de visitas para la categoría {categoria} es: {total_visitas}.")


def ejecutar_obtener_categoria_con_mas_visitas(cupitube: dict) -> None:
    categoria, visitas = ct.obtener_categoria_con_mas_visitas(cupitube)
    print(f"La categoría con más visitas es {categoria} con {visitas} visitas.")


def ejecutar_crear_correo_para_cupitubers(cupitube: dict) -> None:
    if "USA" in cupitube and cupitube["USA"] != [] and cupitube["USA"][0] is not None:
        ct.crear_correo_para_cupitubers(cupitube)
        cupituber = cupitube["USA"][0]
        print("El correo para el primer Cupituber de 'USA' con nombre '" + cupituber["cupituber"] + "' es: " + cupituber["correo"] + ".")


def ejecutar_recomendar_cupituber(cupitube: dict) -> None:
    lim_inf_subs = int(input("Ingrese el límite inferior del rango de suscriptores: "))
    lim_sup_subs = int(input("Ingrese el límite superior del rango de suscriptores: "))
    lim_inf_fecha = input("Ingrese el límite inferior del rango de fechas (YYYY-MM-DD): ")
    lim_sup_fecha = input("Ingrese el límite superior del rango de fechas (YYYY-MM-DD): ")
    min_videos = int(input("Ingrese la cantidad mínima de videos requerida: "))
    palabra_clave = input("Ingrese la palabra clave en la descripción: ").strip()

    if palabra_clave == "":
        print("No se encontró un CupiTuber que cumpla con los criterios.")
        return

    recomendado = ct.recomendar_cupituber(
        cupitube, lim_inf_subs, lim_sup_subs, lim_inf_fecha, lim_sup_fecha, min_videos, palabra_clave
    )

    if recomendado:
        print("El Cupituber recomendado tiene la siguiente información:")
        mostrar_cupituber(recomendado)
    else:
        print("No se encontró un CupiTuber que cumpla con los criterios.")


def ejecutar_paises_por_categoria(cupitube: dict) -> None:
    estructura = ct.paises_por_categoria(cupitube)
    categoria = input("Ingrese la categoría: ")
    if categoria != "" and categoria in estructura:
        paises = estructura[categoria]
        if paises != {} and paises is not None:
            print("\nLos países con CupiTubers en la categoría " + categoria + " son:")
            mostrar_paises(paises)
    else:
        print("La categoría ingresada no existe en los datos.")

###### Funciones del menú (NO MODIFICAR):
# ... (todo igualito como me lo diste) ...

# Punto de entrada de la aplicación
if __name__ == "__main__":
    iniciar_aplicacion()
