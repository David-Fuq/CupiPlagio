#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def cargar_cupitube(archivo: str) -> dict:
   arch=open(archivo, "r", encoding="utf-8")
   a=0
   diccionario={}
   arch.readline()
   while a<973 :
       lineaenlista=((arch.readline().strip()).split(","))
       paissolo=(lineaenlista[7])
       diccionariopersona={
           "rank":(lineaenlista[0]), 
           "cupituber":(lineaenlista[1]),
           "subscribers":(lineaenlista[2]), 
           "video_views":(lineaenlista[3]), 
           "video_count":(lineaenlista[4]), 
           "category":(lineaenlista[5]),
           "started":(lineaenlista[6]),
           "monetization_type":(lineaenlista[8]), 
           "description":(lineaenlista[9]) }
       listaprimigenia=[diccionariopersona]
       if a==0:
           diccionario[paissolo]=listaprimigenia
           a+=1
       elif diccionario.get(paissolo)==None:
           diccionario[paissolo]=listaprimigenia
           a+=1
       else: 
           diccionario.get(paissolo).append(diccionariopersona)
           a+=1
       
   arch.close()
  
       
   return diccionario



def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    lista2=[]
    for j in cupitube.values():
        for i in j:
            if (str(categoria_buscada)).lower()==(str(i.get("category"))).lower() and int(suscriptores_min)<=int(i.get("subscribers"))<=int(suscriptores_max):
                lista2.append(i)
                
             
    return lista2

def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    lista3=[]
    
    for h in cupitube.get(pais_buscado):
        if (str(categoria_buscada)).lower()==(str(h.get("category"))).lower() and (str(monetizacion_buscada)).lower()==(str(h.get("monetization_type"))).lower():
                lista3.append(h)
    return lista3


def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    fecha="9999-99-99"
    masold={}
    for o in cupitube.values():
        for q in o:
            if q.get("started")<fecha:
                fecha=q.get("started")
                masold=q
    return masold  

def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    totalvistas=0
    for w in cupitube.values():
        for t in w:
            if str(t.get("category"))==str(categoria_buscada):
                totalvistas += int(t.get("video_views"))
    return totalvistas

def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:   
    diccionariocategorias={}
    a=0
    catmayor=""
    for w in cupitube.values():
        for t in w:
            valorvistas=int(t.get("video_views"))
            categori=str(t.get("category"))
            if diccionariocategorias.get(categori)==None:
                diccionariocategorias[categori]=valorvistas
            else:
                valordecatg=int(diccionariocategorias.get(categori))
                diccionariocategorias[categori]=(valordecatg+valorvistas)
    for m in diccionariocategorias:
        if diccionariocategorias.get(m)>a:
            a=int(diccionariocategorias.get(m))
            catmayor=m
            
    dictcategoriaconmasvistias={
    "categoria":catmayor,
     "visitas":a
     }
    return dictcategoriaconmasvistias


def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for w in cupitube.values():
        for t in w:
            nombre=str(t.get("cupituber"))
            nombrelista=list(nombre)
            while " " in "".join(nombrelista):
                nombrelista.remove(" ")
            while "_" in "".join(nombrelista):
                nombrelista.remove("_")
            while "-" in "".join(nombrelista):
                nombrelista.remove("-")
            while "{" in "".join(nombrelista):
                nombrelista.remove("{")
            while "}" in "".join(nombrelista):
                nombrelista.remove("}")
            while "[" in "".join(nombrelista):
                nombrelista.remove("[")
            while "+" in "".join(nombrelista):
                nombrelista.remove("+")
            while "*"  in "".join(nombrelista):
                nombrelista.remove("*")
            while "~"  in "".join(nombrelista):
                nombrelista.remove("~")
            while "|" in "".join(nombrelista):
                nombrelista.remove("|")
            while "!"  in "".join(nombrelista):
                nombrelista.remove("!")
            while "#" in "".join(nombrelista):
                nombrelista.remove("#")
            while "$"  in "".join(nombrelista):
                nombrelista.remove("$")
            while "%"  in "".join(nombrelista):
                nombrelista.remove("%")
            while "&"  in "".join(nombrelista):
                nombrelista.remove("&")
            while "&"  in "".join(nombrelista):
                nombrelista.remove("&")
            while "/"  in "".join(nombrelista):
                nombrelista.remove("/")
            while "("  in "".join(nombrelista):
                nombrelista.remove("(")
            while ")"  in "".join(nombrelista):
                nombrelista.remove(")")
            while "="  in "".join(nombrelista):
                nombrelista.remove("=")
            while "?"  in "".join(nombrelista):
                nombrelista.remove("?")
            while "'"  in "".join(nombrelista):
                nombrelista.remove("'")
            while "¿"  in "".join(nombrelista):
                nombrelista.remove("¿")
            while "¡"  in "".join(nombrelista):
                nombrelista.remove("¡")
            while "¨"  in "".join(nombrelista):
                nombrelista.remove("¨")
            while "´" in "".join(nombrelista):
                nombrelista.remove("´")
            while "."  in "".join(nombrelista):
                nombrelista.remove(".")
            while ":" in "".join(nombrelista):
                nombrelista.remove(":")
            while "," in "".join(nombrelista):
                nombrelista.remove(",")
            while ";"  in "".join(nombrelista):
                nombrelista.remove(";")
            while "@"  in "".join(nombrelista):
                nombrelista.remove("@")
            while ">"  in "".join(nombrelista):
                nombrelista.remove(">")
            while "<" in "".join(nombrelista):
                nombrelista.remove("<")
            while "¬" in "".join(nombrelista):
                nombrelista.remove("¬")
            
            
            nombrefinal="".join(nombrelista)
            x=nombrefinal[:15]
            X=str(x)+"."
            año=str(t.get("started"))
            Y=año[2:4]
            Z=año[5:7]
            correo=str(X)+str(Y)+str(Z)+"@cupitube.com"
            correofinal=correo.lower()
            t["correo"]=correofinal


def recomendar_cupituber(cupitube, suscriptores_min, suscriptores_max, fecha_minima, fecha_maxima, videos_minimos, palabra_clave) -> dict:
    
    centinela=False
    dictx={}
    
    while centinela==False:
        for w in cupitube.values():
            for t in w:
                if int(suscriptores_min)<=int(t.get("subscribers"))<=int(suscriptores_max) and int(t.get("video_count"))>int(videos_minimos) and str(fecha_minima)<=str(t.get("started"))<=str(fecha_maxima) and palabra_clave.lower() in (str(t.get("description"))).lower():
                    dictx=t
                    centinela=True
    return dictx


def paises_por_categoria(cupitube: dict) -> dict:
    dictpaises={}
    for w in cupitube.keys():
        pais=w
        for z in cupitube.values():
            for t in z:
                categoriapais=t.get("category")
                paisenlista=[pais]
                if dictpaises.get(categoriapais)==None:
                    dictpaises[categoriapais]=paisenlista
             
                elif str(pais) not in str(dictpaises.get(categoriapais)): 
                    dictpaises.get(categoriapais).append(pais)
    return dictpaises
                
