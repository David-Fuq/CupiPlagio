#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

import cupitube as ct


def mostrar_cupituber(cupituber: dict) -> None:
    print("\n")
    print("-" * 30)
    
    print(
        f"Nombre: {cupituber['cupituber']}\n"
        f"Ranking: {cupituber['rank']}\n"
        f"Suscriptores: {cupituber['subscribers']}\n"
        f"Visitas: {cupituber['video_views']}\n"
        f"Videos: {cupituber['video_count']}\n"
        f"Categoría: {cupituber['category']}\n"
        f"Inicio: {cupituber['started']}\n"
        f"Monetización: {cupituber['monetization_type']}\n"
        f"Descripción: {cupituber['description']}"
    )
    
    print("-" * 30)

def mostrar_cupitubers(cupitubers: list) -> None:
    print("\nCupiTubers encontrados:")
    
    for cupituber in cupitubers:
        mostrar_cupituber(cupituber)

def mostrar_paises(paises: list) -> None:
    for pais in paises:
        print(pais)


def ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube: dict) -> None:
    categoria = input("Categoría: ")
    minimo = int(input("Mínimo de suscriptores: "))
    maximo = int(input("Máximo de suscriptores: "))
    
    cupitubers = ct.buscar_por_categoria_y_rango_suscriptores(cupitube, minimo, maximo, categoria)
    
    if cupitubers != []:
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers.")


def ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict) -> None:
    pais = input("País: ")
    categoria = input("Categoría: ")
    monetizacion = input("Tipo de monetización: ")
    
    cupitubers = ct.buscar_cupitubers_por_pais_categoria_monetizacion(cupitube, pais, categoria, monetizacion)
    
    if cupitubers != []:
        print(f"\nCupiTubers de {pais} en {categoria} con monetización {monetizacion}:")
        mostrar_cupitubers(cupitubers)
    else:
        print("No se encontraron CupiTubers.")


def ejecutar_buscar_cupituber_mas_antiguo(cupitube: dict) -> None:
    cupituber_antiguo = ct.buscar_cupituber_mas_antiguo(cupitube)
    
    if cupituber_antiguo is not None:
        print(f"El CupiTuber más antiguo es {cupituber_antiguo['cupituber']} y empezó en {cupituber_antiguo['started']}.")


def ejecutar_obtener_visitas_por_categoria(cupitube: dict) -> None:
    categoria = input("Categoría: ")
    
    total_visitas = ct.obtener_visitas_por_categoria(cupitube, categoria)
    
    print(f"Total de visitas para {categoria}: {total_visitas}")


def ejecutar_obtener_categoria_con_mas_visitas(cupitube: dict) -> None:
    resultado = ct.obtener_categoria_con_mas_visitas(cupitube)
    
    print(f"Categoría con más visitas: {resultado['categoria']} con {resultado['visitas']} visitas.")


def ejecutar_crear_correo_para_cupitubers(cupitube: dict) -> None:
    if "USA" in cupitube and cupitube["USA"] != [] and cupitube["USA"][0] is not None:
        ct.crear_correo_para_cupitubers(cupitube)
        cupituber = cupitube["USA"][0]
        print(f"Correo para {cupituber['cupituber']}: {cupituber['correo']}")
        

def ejecutar_recomendar_cupituber(cupitube: dict) -> None:
    suscriptores_min = int(input("Mínimo de suscriptores: "))
    suscriptores_max = int(input("Máximo de suscriptores: "))
    fecha_minima = input("Fecha mínima (YYYY-MM-DD): ")
    fecha_maxima = input("Fecha máxima (YYYY-MM-DD): ")
    videos_minimos = int(input("Mínimo de videos: "))
    palabra_clave = input("Palabra clave: ")
    
    if palabra_clave == "":
        print("No se encontró un CupiTuber.")
        return
    
    cupituber_recomendado = ct.recomendar_cupituber(cupitube, suscriptores_min, suscriptores_max, 
                                                  fecha_minima, fecha_maxima, videos_minimos, palabra_clave)
    
    if cupituber_recomendado != {}:
        print("CupiTuber recomendado:")
        mostrar_cupituber(cupituber_recomendado)
    else:
        print("No se encontró un CupiTuber.")


def ejecutar_paises_por_categoria(cupitube: dict) -> None:
    estructura = ct.paises_por_categoria(cupitube)
    
    categoria = input("Categoría: ")
    
    if categoria != "" and categoria in estructura:
        paises = estructura[categoria]
        if paises != {} and paises is not None:
            print(f"\nPaíses con CupiTubers en {categoria}:")
            mostrar_paises(paises)
    else:
        print("Categoría no existe.")


def iniciar_aplicacion() -> None:
    archivo = "cupitube.csv"
        
    estados = ct.cargar_cupitube(archivo)
    if estados != {} and estados is not None:
        print("Bienvenido a CupiTube")
    
        ejecutando = True
        while ejecutando:
            ejecutando = mostrar_menu_aplicacion(estados)
            if ejecutando:
                input("Presione Enter para continuar...")
    else:
        print("Error al cargar el archivo.")
      
            
def mostrar_menu_aplicacion(cupitube: dict) -> bool:
    print("\nOpciones:")
    print("1. Buscar por categoría y suscriptores")
    print("2. Buscar por país, categoría y monetización")
    print("3. Buscar más antiguo")
    print("4. Visitas por categoría")
    print("5. Categoría con más visitas")
    print("6. Crear correos")
    print("7. Recomendar CupiTuber")
    print("8. Países por categoría")
    print("9. Salir")

    opcion = input("Opción: ").strip()

    continuar = True

    if opcion == "1":
        ejecutar_buscar_por_categoria_y_rango_suscriptores(cupitube)
    elif opcion == "2":
        ejecutar_buscar_cupitubers_por_pais_categoria_monetizacion(cupitube)
    elif opcion == "3":
        ejecutar_buscar_cupituber_mas_antiguo(cupitube)
    elif opcion == "4":
        ejecutar_obtener_visitas_por_categoria(cupitube)
    elif opcion == "5":
        ejecutar_obtener_categoria_con_mas_visitas(cupitube)
    elif opcion == "6":
        ejecutar_crear_correo_para_cupitubers(cupitube)
    elif opcion == "7":
        ejecutar_recomendar_cupituber(cupitube)
    elif opcion == "8":
        ejecutar_paises_por_categoria(cupitube)
    elif opcion == "9":
        print("Gracias por usar CupiTube")
        continuar = False
    else:
        print("Opción inválida")

    return continuar


if __name__ == "__main__":
    iniciar_aplicacion()