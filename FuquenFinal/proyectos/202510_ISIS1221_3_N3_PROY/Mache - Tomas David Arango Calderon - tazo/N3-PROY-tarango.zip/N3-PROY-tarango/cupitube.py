#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    archivos = open("cupitube.csv", encoding='utf-8')
    
    linea = archivos.readline()
    linea = archivos.readline()
    
    cupitubers = {}
    
    while linea != "":
        datos = linea.strip().split(",")
        
        rank = int(datos[0])
        cupituber = str(datos[1].strip())
        subscribers = int(datos[2])
        video_views = int(datos[3])
        video_count = int(datos[4])
        category = str(datos[5].strip())
        started = str(datos[6].strip())
        country = str(datos[7].strip())
        monetization_type = str(datos[8].strip())
        description = str(datos[9].strip())
        
        info = {"rank": rank,"cupituber": cupituber,"subscribers": subscribers,"video_views": video_views,"video_count": video_count,"category": category, "started": started, "monetization_type": monetization_type, "description": description}
        
        if country not in cupitubers:
            cupitubers[country] = []
        
        cupitubers[country].append(info)
        
        linea = archivos.readline()
    

    
    return cupitubers
archivo= "cupitube.csv"
cupitube= "cupitube.csv"

    #TODO 1: Implemente la función tal y como se describe en la documentación.


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    cupitube = cargar_cupitube("cupitube.csv") 
    resultado = []
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        
        for cupi in lista_cupitubers:
            if (cupi["category"] == categoria_buscada and suscriptores_min <= cupi["subscribers"] <= suscriptores_max):
                resultado.append(cupi)
 
    return resultado

    
    #TODO 2: Implemente la función tal y como se describe en la documentación.




# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cupitube = cargar_cupitube("cupitube.csv") 
    resultado = []
    if pais_buscado in cupitube:
        lista = cupitube[pais_buscado]
        
        for cupi in lista:
            if (cupi["category"] == categoria_buscada and cupi["monetization_type"] == monetizacion_buscada):
                resultado.append(cupi)

    return resultado   
    
    #TODO 3: Implemente la función tal y como se describe en la documentación.



         
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    cupitube = cargar_cupitube("cupitube.csv") 
    mas_antiguo = None


    for pais in cupitube:
        lista = cupitube[pais]
        
        for cupi in lista:
            if mas_antiguo is None or cupi["started"] < mas_antiguo["started"]:
                mas_antiguo = cupi

    return mas_antiguo    
    
    #TODO 4: Implemente la función tal y como se describe en la documentación.



#Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    cupitube = cargar_cupitube("cupitube.csv") 
    total_visitas = 0
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber['category'] == categoria_buscada:

                total_visitas += cupituber['video_views']

    return total_visitas


    #TODO 5: Implemente la función tal y como se describe en la documentación.



# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    cupitube = cargar_cupitube("cupitube.csv") 
    visitas_por_categoria = {}
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber['category']
            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = 0
            visitas_por_categoria[categoria] += cupituber['video_views']
    
    categoria_max = max(visitas_por_categoria, key=visitas_por_categoria.get)
    return {"categoria": categoria_max, "visitas": visitas_por_categoria[categoria_max]}


    #TODO 6: Implemente la función tal y como se describe en la documentación.



# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> dict:
    cupitube = cargar_cupitube("cupitube.csv") 
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombrechar = []
            for e in cupituber['cupituber']:
                if ('a' <= e <= 'z') or ('A' <= e <= 'Z') or ('0' <= e <= '9'):
                    nombrechar.append(e)
                if len(nombrechar) == 15:
                    break
            nombre = ''.join(nombrechar)            
            año = cupituber['started'][0:4]
            mes = cupituber['started'][5:7]
            cupituber['correo'] = f"{nombre}.{año[-2:]}{mes}@cupitube.com"
    return cupitube

    #TODO 7: Implemente la función tal y como se describe en la documentación.

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:

    categoria_mas_visitas = obtener_categoria_con_mas_visitas(cupitube)['categoria']
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:

            if (cupituber['category'] == categoria_mas_visitas and suscriptores_min <= cupituber['subscribers'] <= suscriptores_max and cupituber['video_count'] >= videos_minimos and fecha_minima <= cupituber['started'] <= fecha_maxima):

                descripcion = cupituber['description']
                palabra_clave_encontrada = True
                for letra in palabra_clave:
                    if letra not in descripcion:
                        palabra_clave_encontrada = False
                        break
                if palabra_clave_encontrada:
                    return cupituber
    return {}


    #TODO 8: Implemente la función tal y como se describe en la documentación.



# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    cupitube = cargar_cupitube("cupitube.csv") 
    categorias = {}
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber['category']
            if categoria not in categorias:
                categorias[categoria] = set()
            categorias[categoria].add(pais)
    return {categoria: list(paises) for categoria, paises in categorias.items()}

    #TODO 9: Implemente la función tal y como se describe en la documentación.
