def cargar_datos(nombre_archivo:str):
    archivo = open(nombre_archivo, "r", encoding="utf-8")
    cabecera = archivo.readline()
    linea = archivo.readline().strip()
    datos = {}

    while len(linea) > 0:
        partes = linea.split(",")
        cupi = {
            "rank": int(partes[0]),
            "cupituber": partes[1],
            "subscribers": int(partes[2]),
            "video_views": int(partes[3]),
            "video_count": int(partes[4]),
            "category": partes[5],
            "started": partes[6],
            "country": partes[7],
            "monetization_type": partes[8],
            "description": partes[9]
        }

        pais = partes[7]
        if pais not in datos:
            datos[pais] = []
        datos[pais].append(cupi)

        linea = archivo.readline().strip()

    archivo.close()
    return datos
cupitube = cargar_datos("cupitube.csv")

def buscar_por_categoria_y_rango_suscriptores(cupitube:dict, minimo:int, maximo:int, categoria:str):
    
    lista = []
    
    for pais in cupitube:
        for c in cupitube[pais]:
            if categoria == c["category"] and c["subscribers"] >= minimo and c["subscribers"] <= maximo :
                lista.append(c)
    return lista
        
        
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube:dict, pais_buscado:str, categoria_buscada:str, monetizacion_buscada:str):
    lista = []
    for pais in cupitube:
        for c in cupitube[pais]:
            if pais == pais_buscado and categoria_buscada== c["category"] and monetizacion_buscada == c["monetization_type"]:
                lista.append(c)
    return lista



def buscar_cupituber_mas_antiguo(diccionario):
   
    mas_viejo = diccionario["Argentina"][0]
   
    for pais in diccionario:
        for c in diccionario[pais]:
            if c["started"] < mas_viejo["started"]:
                mas_viejo = c
               
    return mas_viejo



def obtener_visitas_por_categoria(diccionario, categoria):
    resultado = 0
    for pais in diccionario:
        for c in diccionario[pais]:
            if c["category"] == categoria:
                resultado += c["video_views"]
               
    return resultado

def obtener_categoria_con_mas_visitas(diccionario):
   dicc  = {}
   dicc ["categoria"] = ""
   dicc ["vistas"] = 0
   
   for pais in diccionario:
       for c in diccionario[pais]:
          categoria = c["category"]
          vistas = obtener_visitas_por_categoria(diccionario, categoria)
          if vistas > dicc["vistas"]:
              dicc["vistas"] = vistas
              dicc ["categoria"] = categoria
             
   return dicc
             
         

def modificar_nombre(nombre):
    nombre_sin_especiales = ""
    for caracter in nombre:
        if caracter.isalnum():
            nombre_sin_especiales += caracter
    return nombre_sin_especiales

def crear_correo_para_cupitubers(diccionario):
    for pais in diccionario:
        for c in diccionario[pais]:
            nombre = modificar_nombre(c["cupituber"].lower())
            if len(nombre) > 15:
                nombre = nombre[:15]
            anio = c["started"][2:4]
            mes = c["started"][5:7]
            correo = f"{nombre}.{anio}{mes}@cupitube.com"
            c["correo"] = correo

def recomendar_cupituber(cupitube:dict,suscriptores_min:int,suscriptores_max:int,fecha_minima:str,fecha_maxima:str,videos_minimos:int, palabra_clave:str):
    
    categoria_mas_visitada = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    paises = list(cupitube.keys())
    i = 0
    encontrado = False
    ganador = {}

    while encontrado == False and i < len(paises):
        lista_cupitubers = cupitube[paises[i]]
        j = 0
        while encontrado == False and j < len(lista_cupitubers):
            cupituber = lista_cupitubers[j]
            if cupituber["category"] == categoria_mas_visitada:
                if suscriptores_min <= cupituber["subscribers"] <= suscriptores_max:
                    if fecha_minima <= cupituber["started"] <= fecha_maxima:
                        if cupituber["video_count"] >= videos_minimos:
                            descripcion = cupituber["description"].lower()
                            if palabra_clave.lower() in descripcion:
                                encontrado = True
                                ganador = cupituber
            j += 1
        i += 1

    return ganador

    def paises_por_categoria(cupitube: dict) -> dict:
    dicc = {}
    for pais in cupitube:
        for c in cupitube[pais]:
            categoria = c["category"]
            if categoria not in dicc:
                dicc[categoria] = []
            if pais not in dicc[categoria]:
                dicc[categoria].append(pais)
    return dicc
