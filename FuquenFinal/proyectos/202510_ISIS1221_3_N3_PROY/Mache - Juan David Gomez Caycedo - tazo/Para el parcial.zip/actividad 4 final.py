def buscar_contrato_por_identificador(contratos: list, id_contrato: str) -> dict:
    contrato = None
    for contrato_temp in contratos:
        if contrato_temp["id_contrato"] == id_contrato:
            contrato = contrato_temp
    return contrato



def leer_archivo(nombre_archivo: str) -> list:
    contratos = []
    
    archivo = open(nombre_archivo, "r", encoding="utf8")
    archivo.readline()
    
    linea = archivo.readline()
    while linea != "":
        campos = linea.split(";")
        
        diccionario = {}
        diccionario["plataforma"] = campos[0]
        diccionario["nombre_entidad"] = campos[1]
        diccionario["nit_entidad"] = campos[2]
        diccionario["id_contrato"] = campos[3]
        diccionario["documento_proveedor"] = campos[4]
        diccionario["proveedor_adjudicado"] = campos[5]
        
        valor = campos[6].replace(',', '.').strip()
        try:
            diccionario["valor_del_contrato"] = float(valor)
        except ValueError:
            diccionario["valor_del_contrato"] = 0.0
            
        diccionario["fecha"] = campos[7]
        diccionario["departamento"] = campos[8]
        diccionario["referentes"] = campos[9]
        contratos.append(diccionario)
        linea = archivo.readline()
    archivo.close()
    return contratos

contratos = leer_archivo("MuestreoContrato (2).csv")
print("Total de contratos leídos: " + str(len(contratos)))
contrato = buscar_contrato_por_identificador(contratos, "CO1.PCCNTR.4363163")
print(contrato)




def sumatoria_contratos_mes(contratos: list, numero_mes: int) -> float:
    sumatoria = 0
    for contrato in contratos:
        fecha = contrato["fecha"]
        campos_fecha = fecha.split("/")
        mes = int(campos_fecha[1])
        if numero_mes == mes:
            sumatoria += contrato["valor_del_contrato"]
    return sumatoria
contratos = leer_archivo("MuestreoContrato (2).csv")
mes_a_consultar = 1
funcion_sumatoria_contratos_mes = sumatoria_contratos_mes(contratos, mes_a_consultar)
print("La sumatoria de contratos del mes " + str(mes_a_consultar) + " es: " + str(funcion_sumatoria_contratos_mes))




def cantidad_contratos_mes(contratos: list, numero_mes: int) -> int:
    sumatoria = 0
    for contrato in contratos:
        fecha = contrato["fecha"]
        campos_fecha = fecha.split("/")
        mes = int(campos_fecha[1])
        if numero_mes == mes:
            sumatoria += 1
    return sumatoria
contratos = leer_archivo("MuestreoContrato (2).csv")
mes_a_consultar = 1
funcion_cantidad_contratos_mes = cantidad_contratos_mes(contratos, mes_a_consultar)
print("La cantidad de contratos del mes " + str(mes_a_consultar) + " es: " + str(funcion_cantidad_contratos_mes))   
    


def armar_contratos_mes(contratos: list) -> dict:
    resultado = {}
    meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
    for i in range(0, 12):
        nombre_mes = meses[i]
        valor_total = sumatoria_contratos_mes(contratos, i)
        cantidad = cantidad_contratos_mes(contratos, i)
        resultado[nombre_mes] = {}
        resultado[nombre_mes]["total"] = valor_total
        resultado[nombre_mes]["cantidad_contratos"] = cantidad
    return resultado
contratos_por_mes = armar_contratos_mes(contratos)
print(contratos_por_mes)



def contrato_mayor_valor(contratos: list) -> dict:
    if not contratos:
        return None
    contrato_max = contratos[0]
    for contrato in contratos:
        if contrato["valor_del_contrato"] > contrato_max["valor_del_contrato"]:
            contrato_max = contrato
    return contrato_max
contratos = leer_archivo("MuestreoContrato (2).csv")
contrato_max = contrato_mayor_valor(contratos)
print(contrato_max)



def armar_contratos_plataforma(contratos: list) -> dict:
    resultado = {}
    for contrato in contratos:
        plataforma = contrato["plataforma"]
        if plataforma not in resultado:
            resultado[plataforma] = []
        resultado[plataforma].append(contrato)
    return resultado
contratos = leer_archivo("MuestreoContrato (2).csv")
contratos_por_plataforma = armar_contratos_plataforma(contratos)
print(contratos_por_plataforma)





def buscar_contrato_por_identificador(contratos: list, id_contrato: str) -> dict:  # Define la función que busca un contrato por su ID
    contrato = None  # Inicializa la variable contrato como None para almacenar el resultado
    for contrato_temp in contratos:  # Recorre cada contrato de la lista
        if contrato_temp["id_contrato"] == id_contrato:  # Compara el ID del contrato actual con el buscado
            contrato = contrato_temp  # Si coincide, guarda el contrato encontrado
    return contrato  # Retorna el contrato encontrado o None si no se encontró


def leer_archivo(nombre_archivo: str) -> list:  # Define la función que lee el archivo de contratos
    contratos = []  # Inicializa una lista vacía para almacenar los contratos
    
    archivo = open(nombre_archivo, "r", encoding="utf8")  # Abre el archivo en modo lectura con codificación UTF-8
    archivo.readline()  # Lee y descarta la primera línea (cabecera) del archivo
    
    linea = archivo.readline()  # Lee la segunda línea (primer registro de datos)
    while linea != "":  # Inicia un bucle que se ejecuta mientras haya líneas por leer
        campos = linea.split(";")  # Divide la línea por punto y coma para obtener cada campo
        
        diccionario = {}  # Inicializa un diccionario para el contrato actual
        diccionario["plataforma"] = campos[0]  # Asigna el primer campo como plataforma
        diccionario["nombre_entidad"] = campos[1]  # Asigna el segundo campo como nombre de entidad
        diccionario["nit_entidad"] = campos[2]  # Asigna el tercer campo como NIT de entidad
        diccionario["id_contrato"] = campos[3]  # Asigna el cuarto campo como ID del contrato
        diccionario["documento_proveedor"] = campos[4]  # Asigna el quinto campo como documento del proveedor
        diccionario["proveedor_adjudicado"] = campos[5]  # Asigna el sexto campo como proveedor adjudicado
        
        valor = campos[6].replace(',', '.').strip()  # Prepara el valor del contrato reemplazando comas por puntos y eliminando espacios
        # Versión modificada sin try-except
        if valor.replace('.', '', 1).isdigit():  # Verifica si es un número válido después de eliminar un punto decimal
            diccionario["valor_del_contrato"] = float(valor)  # Convierte el valor a número decimal
        else:
            diccionario["valor_del_contrato"] = 0.0  # Si no es un número válido, asigna 0.0 como valor del contrato
            
        diccionario["fecha"] = campos[7]  # Asigna el octavo campo como fecha
        diccionario["departamento"] = campos[8]  # Asigna el noveno campo como departamento
        diccionario["referentes"] = campos[9]  # Asigna el décimo campo como referentes
        contratos.append(diccionario)  # Añade el diccionario del contrato a la lista de contratos
        linea = archivo.readline()  # Lee la siguiente línea
    archivo.close()  # Cierra el archivo
    return contratos  # Retorna la lista de contratos


def sumatoria_contratos_mes(contratos: list, numero_mes: int) -> float:  # Define la función que calcula la suma de valores de contratos para un mes específico
    sumatoria = 0  # Inicializa la sumatoria en cero
    for contrato in contratos:  # Recorre cada contrato de la lista
        fecha = contrato["fecha"]  # Obtiene la fecha del contrato
        campos_fecha = fecha.split("/")  # Divide la fecha por barras para obtener día, mes y año
        mes = int(campos_fecha[1])  # Convierte el mes a entero (asume formato DD/MM/AAAA)
        if numero_mes == mes:  # Compara si el mes del contrato coincide con el mes buscado
            sumatoria += contrato["valor_del_contrato"]  # Si coincide, suma el valor del contrato a la sumatoria
    return sumatoria  # Retorna la sumatoria total


def cantidad_contratos_mes(contratos: list, numero_mes: int) -> int:  # Define una función que cuenta la cantidad de contratos para un mes específico
    sumatoria = 0  # Inicializa el contador en cero
    for contrato in contratos:  # Recorre cada contrato de la lista
        fecha = contrato["fecha"]  # Obtiene la fecha del contrato
        campos_fecha = fecha.split("/")  # Divide la fecha por barras para obtener día, mes y año
        mes = int(campos_fecha[1])  # Convierte el mes a entero (asume formato DD/MM/AAAA)
        if numero_mes == mes:  # Compara si el mes del contrato coincide con el mes buscado
            sumatoria += 1  # Si coincide, incrementa el contador en 1
    return sumatoria  # Retorna la cantidad total


def armar_contratos_mes(contratos: list) -> dict:  # Define una función que organiza contratos por mes con total y cantidad
    resultado = {}  # Inicializa un diccionario para almacenar los resultados
    meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]  # Define una lista con los nombres de los meses
    for i in range(0, 12):  # Recorre los índices de 0 a 11 (12 meses)
        nombre_mes = meses[i]  # Obtiene el nombre del mes actual
        valor_total = sumatoria_contratos_mes(contratos, i+1)  # Calcula el valor total de contratos para el mes actual (usando i+1 para que coincida con el formato de mes 1-12)
        cantidad = cantidad_contratos_mes(contratos, i+1)  # Calcula la cantidad de contratos para el mes actual (usando i+1 para que coincida con el formato de mes 1-12)
        resultado[nombre_mes] = {}  # Crea un diccionario para el mes actual dentro del resultado
        resultado[nombre_mes]["total"] = valor_total  # Asigna el valor total al diccionario del mes
        resultado[nombre_mes]["cantidad_contratos"] = cantidad  # Asigna la cantidad al diccionario del mes
    return resultado  # Retorna el diccionario completo


def contrato_mayor_valor(contratos: list) -> dict:  # Define una función que encuentra el contrato de mayor valor
    if not contratos:  # Verifica si la lista está vacía
        return None  # Si la lista está vacía, retorna None
    contrato_max = contratos[0]  # Inicializa con el primer contrato de la lista
    for contrato in contratos:  # Recorre cada contrato de la lista
        if contrato["valor_del_contrato"] > contrato_max["valor_del_contrato"]:  # Compara si el valor del contrato actual es mayor que el máximo encontrado
            contrato_max = contrato  # Si es mayor, actualiza el contrato máximo
    return contrato_max  # Retorna el contrato de mayor valor


def armar_contratos_plataforma(contratos: list) -> dict:  # Define una función que organiza contratos por plataforma
    resultado = {}  # Inicializa un diccionario para almacenar los resultados
    for contrato in contratos:  # Recorre cada contrato de la lista
        plataforma = contrato["plataforma"]  # Obtiene la plataforma del contrato
        if plataforma not in resultado:  # Verifica si la plataforma no existe en el resultado
            resultado[plataforma] = []  # Si no existe, crea una lista vacía para esa plataforma
        resultado[plataforma].append(contrato)  # Añade el contrato a la lista de la plataforma correspondiente
    return resultado  # Retorna el diccionario completo
