# -*- coding: utf-8 -*-
"""
Created on Mon Apr  7 06:37:14 2025

@author: Admin
"""


def leer_archivo(nombre_archivo: str) -> list:
    peliculas = []
    archivo = open(nombre_archivo, "r", encoding="utf8")
    archivo.readline()
    linea = archivo.readline()
    while linea != "":
        campos = linea.strip().split(",")
        diccionario = {}
        diccionario["titulo"] = campos[0]
        diccionario["año"] = campos[1]
        diccionario["genero"] = campos[2]
        diccionario["director"] = campos[3]
        diccionario["actor"] = campos[4]
        diccionario["duracion"] = campos[5]
        diccionario["presupuesto"] = campos[6]
        diccionario["recaudacion"] = campos[7]
        diccionario["puntuacion"] = campos[8]
        diccionario["premios"] = campos[9]
        peliculas.append(diccionario)
        linea = archivo.readline()
    archivo.close()
    return peliculas
print(leer_archivo("peliculas_hollywood_1980_2024.csv"))

peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")
print(peliculas)



def leer_peliculas_director(peliculas: list) -> dict:
    resultado = {}
    for pelicula in peliculas:
        director = pelicula["director"]
        if director not in resultado:
            resultado[director] = []
            resultado[director].append(pelicula)
        return resultado
peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")
directores_peliculas = leer_peliculas_director(peliculas)
print(directores_peliculas)




def leer_peliculas_director(nombre_archivo: str) -> dict:
    peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")
    directores_peliculas = {}
    for pelicula in peliculas:
        director = pelicula.get("director", "")
        if director not in directores_peliculas:
            directores_peliculas[director] = []
        directores_peliculas[director].append(pelicula)
    return directores_peliculas
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")
print(directores_peliculas)


def leer_peliculas_genero(nombre_archivo: str) -> dict:
    peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")
    generos_peliculas = {}
    for pelicula in peliculas:
        genero = pelicula.get("genero", "")
        if genero not in generos_peliculas:
            generos_peliculas[genero] = []
        generos_peliculas[genero].append(pelicula)
    return generos_peliculas

generos_peliculas = leer_peliculas_genero("peliculas_hollywood_1980_2024.csv")
print(generos_peliculas)



def pelicula_por_nombre(peliculas_director: dict, nombre_pelicula: str)-> dict:
    peliculas_por_nombres = []
    for director, peliculas in peliculas_director.items():
        for pelicula in peliculas:
            if pelicula["titulo"].lower() == nombre_pelicula.lower():
                peliculas_por_nombres.append(pelicula)
    return peliculas_por_nombres
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")
resultado = pelicula_por_nombre(directores_peliculas, "Forrest Gump")
print(resultado)


def promedio_calificacion_peliculas_genero(genero: str, peliculas_genero: dict) -> float:
    if genero not in peliculas_genero: #Aqui Verifico si el género especificado existe como clave en el diccionario
        return 0 #Si el género no existe, retorna 0 inmediatamente y termina la función
    peliculas = peliculas_genero[genero] #Si el género existe, obtiene la lista de películas asociadas a ese género del diccionario
    if len(peliculas) == 0: #Verifica si la lista de películas está vacía (tiene longitud 0)
        return 0
    total = 0 #Aqui inicializo las variables
    cantidad = 0
    for pelicula in peliculas: #Aqui inicio un bucle que recorrerá cada película en la lista de películas del género
        if pelicula["puntuacion"] != "": #Si la puntuacion no esta vacia"
            total = total + float(pelicula["puntuacion"]) #Se añade al total acumulado
            cantidad = cantidad + 1 #añado la pelicula a la cantidad
    if cantidad == 0:
        return 0
    return total / cantidad #hago la operacion
generos_peliculas = leer_peliculas_genero("peliculas_hollywood_1980_2024.csv")
promedio = promedio_calificacion_peliculas_genero("Drama", generos_peliculas)
promedio_redondeado = round(promedio, 2)
print("El promedio de calificación para películas de Drama es de " + str(promedio_redondeado) + " estrellas")




def promedio_calificacion_peliculas_actor(peliculas_director: dict, nombre_actor: str) -> float:

    total = 0.0
    cantidad = 0
    
    for director in peliculas_director:
        peliculas = peliculas_director[director]
        for pelicula in peliculas:
            if pelicula["actor"].lower() == nombre_actor.lower():
                if pelicula["puntuacion"] != "":
                    total = total + float(pelicula["puntuacion"])
                    cantidad = cantidad + 1
    if cantidad == 0:
        return 0.0
    return total / cantidad
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")
promedio = promedio_calificacion_peliculas_actor(directores_peliculas, "Tom Hanks")
print("Promedio de calificación para películas de Tom Hanks es " + str(promedio))



def pelicula_con_mayor_presupuesto(peliculas_genero: dict) -> dict:

    mayor = -1
    pelicula_mayor = {}
    
    for genero in peliculas_genero:
        peliculas = peliculas_genero[genero]
        for pelicula in peliculas:
            if pelicula["presupuesto"] != "":
                presupuesto = float(pelicula["presupuesto"])
                if presupuesto > mayor:
                    mayor = presupuesto
                    pelicula_mayor = pelicula    
    return pelicula_mayor
generos_peliculas = leer_peliculas_genero("peliculas_hollywood_1980_2024.csv")
pelicula_mayor = pelicula_con_mayor_presupuesto(generos_peliculas)
print("La peli con mayor presupuesto es" + str(pelicula_mayor))



def contar_peliculas_calificacion_anio_lanzamiento(peliculas_director: dict, anio: int) -> int:
    contador = 0
    anio_str = str(anio)
    for director in peliculas_director:
        peliculas = peliculas_director[director]
        for pelicula in peliculas:
            if pelicula["año"] == anio_str:
                contador = contador + 1
    return contador
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")
cantidad = contar_peliculas_calificacion_anio_lanzamiento(directores_peliculas, 2020)
print("La cantidad de películas en 2020 es de " + str(cantidad) + " puntos.")



def director_mas_premiado(peliculas_director: dict) -> str:
    premios_directores = {} #almancenar premios de cada director
    for director in peliculas_director: #recorrer cada director en el diccionario
        total_premios = 0 
        peliculas = peliculas_director[director] #obtener la listao de pelis
        for pelicula in peliculas: #recorre cada peliculña del direcrtor
            if pelicula["premios"] != "": #si tiene premios
                premios = int(pelicula["premios"]) #conviert a int
                total_premios = total_premios + premios #añadir
        premios_directores[director] = total_premios # Después de revisar pelis, guarda el total de premios en el diccionario usando el nombre del director como clave
    director_max = "" #inicuializar
    max_premios = 0
    for director in premios_directores: #recorrer
        premios = premios_directores[director] #total premios
        if premios > max_premios:
            max_premios = premios
            director_max = director
    return director_max
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")
director = director_mas_premiado(directores_peliculas)
print("El director más premiado es " + str(director))



def leer_archivo(nombre_archivo: str) -> list:  # Define una función que lee un archivo de películas y retorna una lista
    peliculas = []  # Inicializa una lista vacía para almacenar las películas
    archivo = open(nombre_archivo, "r", encoding="utf8")  # Abre el archivo en modo lectura con codificación UTF-8
    archivo.readline()  # Lee y descarta la primera línea (cabecera) del archivo
    linea = archivo.readline()  # Lee la segunda línea (primer registro de datos)
    while linea != "":  # Inicia un bucle que se ejecuta mientras haya líneas por leer
        campos = linea.strip().split(",")  # Elimina espacios y divide la línea por comas para obtener cada campo
        diccionario = {}  # Inicializa un diccionario para la película actual
        diccionario["titulo"] = campos[0]  # Asigna el primer campo como título
        diccionario["año"] = campos[1]  # Asigna el segundo campo como año
        diccionario["genero"] = campos[2]  # Asigna el tercer campo como género
        diccionario["director"] = campos[3]  # Asigna el cuarto campo como director
        diccionario["actor"] = campos[4]  # Asigna el quinto campo como actor principal
        diccionario["duracion"] = campos[5]  # Asigna el sexto campo como duración
        diccionario["presupuesto"] = campos[6]  # Asigna el séptimo campo como presupuesto
        diccionario["recaudacion"] = campos[7]  # Asigna el octavo campo como recaudación
        diccionario["puntuacion"] = campos[8]  # Asigna el noveno campo como puntuación
        diccionario["premios"] = campos[9]  # Asigna el décimo campo como premios
        peliculas.append(diccionario)  # Añade el diccionario de la película a la lista de películas
        linea = archivo.readline()  # Lee la siguiente línea
    archivo.close()  # Cierra el archivo
    return peliculas  # Retorna la lista de películas
print(leer_archivo("peliculas_hollywood_1980_2024.csv"))  # Imprime el resultado de leer el archivo de películas

peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")  # Llama a la función para leer el archivo y guarda el resultado
print(peliculas)  # Imprime la lista de películas



def leer_peliculas_director(peliculas: list) -> dict:  # Define una función que organiza películas por director (esta versión tiene un error)
    resultado = {}  # Inicializa un diccionario para almacenar los resultados
    for pelicula in peliculas:  # Recorre cada película de la lista
        director = pelicula["director"]  # Obtiene el director de la película usando acceso directo al diccionario, que fallará si la clave no existe
        if director not in resultado:  # Verifica si el director no existe en el resultado
            resultado[director] = []  # Si no existe, crea una lista vacía para ese director
            resultado[director].append(pelicula)  # Añade la película a la lista del director
        return resultado  # NOTA: Este return está mal indentado y causará que la función salga del bucle después de la primera película
peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")  # Llama a la función para leer el archivo
directores_peliculas = leer_peliculas_director(peliculas)  # Llama a la función con error para organizar películas por director
print(directores_peliculas)  # Imprime el resultado (incompleto debido al error)




def leer_peliculas_director(nombre_archivo: str) -> dict:  # Define una versión corregida de la función que organiza películas por director
    peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")  # Llama a la función para leer el archivo
    directores_peliculas = {}  # Inicializa un diccionario para almacenar los resultados
    for pelicula in peliculas:  # Recorre cada película de la lista
        director = pelicula.get("director", "")  # Usa get() para obtener el director, que devuelve "" si la clave no existe, evitando errores
        if director not in directores_peliculas:  # Verifica si el director no existe en el resultado
            directores_peliculas[director] = []  # Si no existe, crea una lista vacía para ese director
        directores_peliculas[director].append(pelicula)  # Añade la película a la lista del director (fuera del if, para todas las películas)
    return directores_peliculas  # Retorna el diccionario completo
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")  # Llama a la función corregida
print(directores_peliculas)  # Imprime el resultado completo


def leer_peliculas_genero(nombre_archivo: str) -> dict:  # Define una función que organiza películas por género
    peliculas = leer_archivo("peliculas_hollywood_1980_2024.csv")  # Llama a la función para leer el archivo
    generos_peliculas = {}  # Inicializa un diccionario para almacenar los resultados
    for pelicula in peliculas:  # Recorre cada película de la lista
        genero = pelicula.get("genero", "")  # Usa get() para obtener el género, que devuelve "" si la clave no existe, evitando errores
        if genero not in generos_peliculas:  # Verifica si el género no existe en el resultado
            generos_peliculas[genero] = []  # Si no existe, crea una lista vacía para ese género
        generos_peliculas[genero].append(pelicula)  # Añade la película a la lista del género
    return generos_peliculas  # Retorna el diccionario completo

generos_peliculas = leer_peliculas_genero("peliculas_hollywood_1980_2024.csv")  # Llama a la función para organizar películas por género
print(generos_peliculas)  # Imprime el resultado



def pelicula_por_nombre(peliculas_director: dict, nombre_pelicula: str)-> dict:  # Define una función que busca películas por nombre
    peliculas_por_nombres = []  # Inicializa una lista para almacenar las películas encontradas
    for director, peliculas in peliculas_director.items():  # Usa items() para recorrer tanto claves (directores) como valores (listas de películas) simultáneamente
        for pelicula in peliculas:  # Recorre cada película del director
            if pelicula["titulo"].lower() == nombre_pelicula.lower():  # Compara el título en minúsculas con el nombre buscado
                peliculas_por_nombres.append(pelicula)  # Si coincide, añade la película a la lista de resultados
    return peliculas_por_nombres  # Retorna la lista de películas encontradas
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")  # Organiza películas por director
resultado = pelicula_por_nombre(directores_peliculas, "Forrest Gump")  # Busca la película "Forrest Gump"
print(resultado)  # Imprime el resultado


def promedio_calificacion_peliculas_genero(genero: str, peliculas_genero: dict) -> float:  # Define una función que calcula el promedio de calificación para un género
    if genero not in peliculas_genero:  # Verifica si el género especificado existe como clave en el diccionario
        return 0  # Si el género no existe, retorna 0 inmediatamente
    peliculas = peliculas_genero[genero]  # Obtiene la lista de películas del género
    if len(peliculas) == 0:  # Verifica si la lista de películas está vacía
        return 0  # Si está vacía, retorna 0
    total = 0  # Inicializa el total acumulado de puntuaciones
    cantidad = 0  # Inicializa el contador de películas con puntuación
    for pelicula in peliculas:  # Recorre cada película del género
        if pelicula["puntuacion"] != "":  # Verifica si la película tiene puntuación
            total = total + float(pelicula["puntuacion"])  # Suma la puntuación al total
            cantidad = cantidad + 1  # Incrementa el contador
    if cantidad == 0:  # Verifica si no se encontraron películas con puntuación
        return 0  # Si no hay películas con puntuación, retorna 0
    return total / cantidad  # Calcula y retorna el promedio
generos_peliculas = leer_peliculas_genero("peliculas_hollywood_1980_2024.csv")  # Organiza películas por género
promedio = promedio_calificacion_peliculas_genero("Drama", generos_peliculas)  # Calcula el promedio para el género Drama
promedio_redondeado = round(promedio, 2)  # Redondea el promedio a 2 decimales
print("El promedio de calificación para películas de Drama es de " + str(promedio_redondeado) + " estrellas")  # Imprime el resultado




def promedio_calificacion_peliculas_actor(peliculas_director: dict, nombre_actor: str) -> float:  # Define una función que calcula el promedio de calificación para un actor

    total = 0.0  # Inicializa el total acumulado de puntuaciones
    cantidad = 0  # Inicializa el contador de películas con puntuación
    
    for director in peliculas_director:  # Recorre cada director en el diccionario (usando solo las claves, no usa items())
        peliculas = peliculas_director[director]  # Obtiene la lista de películas del director mediante acceso directo al diccionario
        for pelicula in peliculas:  # Recorre cada película del director
            if pelicula["actor"].lower() == nombre_actor.lower():  # Compara el actor en minúsculas con el nombre buscado
                if pelicula["puntuacion"] != "":  # Verifica si la película tiene puntuación
                    total = total + float(pelicula["puntuacion"])  # Suma la puntuación al total
                    cantidad = cantidad + 1  # Incrementa el contador
    if cantidad == 0:  # Verifica si no se encontraron películas con puntuación
        return 0.0  # Si no hay películas con puntuación, retorna 0.0
    return total / cantidad  # Calcula y retorna el promedio
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")  # Organiza películas por director
promedio = promedio_calificacion_peliculas_actor(directores_peliculas, "Tom Hanks")  # Calcula el promedio para Tom Hanks
print("Promedio de calificación para películas de Tom Hanks es " + str(promedio))  # Imprime el resultado



def pelicula_con_mayor_presupuesto(peliculas_genero: dict) -> dict:  # Define una función que encuentra la película con mayor presupuesto

    mayor = -1  # Inicializa el mayor presupuesto encontrado con -1
    pelicula_mayor = {}  # Inicializa un diccionario vacío para la película con mayor presupuesto
    
    for genero in peliculas_genero:  # Recorre cada género en el diccionario (usando solo las claves, no usa items())
        peliculas = peliculas_genero[genero]  # Obtiene la lista de películas del género mediante acceso directo al diccionario
        for pelicula in peliculas:  # Recorre cada película del género
            if pelicula["presupuesto"] != "":  # Verifica si la película tiene presupuesto
                presupuesto = float(pelicula["presupuesto"])  # Convierte el presupuesto a número decimal
                if presupuesto > mayor:  # Compara si el presupuesto es mayor que el máximo encontrado
                    mayor = presupuesto  # Actualiza el mayor presupuesto
                    pelicula_mayor = pelicula  # Actualiza la película con mayor presupuesto
    return pelicula_mayor  # Retorna la película con mayor presupuesto
generos_peliculas = leer_peliculas_genero("peliculas_hollywood_1980_2024.csv")  # Organiza películas por género
pelicula_mayor = pelicula_con_mayor_presupuesto(generos_peliculas)  # Encuentra la película con mayor presupuesto
print("La peli con mayor presupuesto es" + str(pelicula_mayor))  # Imprime el resultado



def contar_peliculas_calificacion_anio_lanzamiento(peliculas_director: dict, anio: int) -> int:  # Define una función que cuenta películas de un año específico
    contador = 0  # Inicializa el contador de películas
    anio_str = str(anio)  # Convierte el año a string para comparar con el campo en los datos
    for director in peliculas_director:  # Recorre cada director en el diccionario (usando solo las claves, no usa items())
        peliculas = peliculas_director[director]  # Obtiene la lista de películas del director mediante acceso directo al diccionario
        for pelicula in peliculas:  # Recorre cada película del director
            if pelicula["año"] == anio_str:  # Compara el año de la película con el año buscado
                contador = contador + 1  # Si coincide, incrementa el contador
    return contador  # Retorna el total de películas encontradas
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")  # Organiza películas por director
cantidad = contar_peliculas_calificacion_anio_lanzamiento(directores_peliculas, 2020)  # Cuenta películas del año 2020
print("La cantidad de películas en 2020 es de " + str(cantidad) + " puntos.")  # Imprime el resultado



def director_mas_premiado(peliculas_director: dict) -> str:  # Define una función que encuentra el director con más premios
    premios_directores = {}  # Inicializa un diccionario para almacenar los premios de cada director
    for director in peliculas_director:  # Recorre cada director en el diccionario (usando solo las claves, no usa items())
        total_premios = 0  # Inicializa el total de premios para el director actual
        peliculas = peliculas_director[director]  # Obtiene la lista de películas del director mediante acceso directo al diccionario
        for pelicula in peliculas:  # Recorre cada película del director
            if pelicula["premios"] != "":  # Verifica si la película tiene premios
                premios = int(pelicula["premios"])  # Convierte los premios a entero
                total_premios = total_premios + premios  # Suma los premios al total
        premios_directores[director] = total_premios  # Guarda el total de premios del director
    director_max = ""  # Inicializa el director con más premios
    max_premios = 0  # Inicializa el máximo de premios encontrado
    for director in premios_directores:  # Recorre cada director y sus premios (usando solo las claves, no usa items())
        premios = premios_directores[director]  # Obtiene el total de premios del director mediante acceso directo al diccionario
        if premios > max_premios:  # Compara si los premios son más que el máximo encontrado
            max_premios = premios  # Actualiza el máximo de premios
            director_max = director  # Actualiza el director con más premios
    return director_max  # Retorna el director con más premios
directores_peliculas = leer_peliculas_director("peliculas_hollywood_1980_2024.csv")  # Organiza películas por director
director = director_mas_premiado(directores_peliculas)  # Encuentra el director con más premios
print("El director más premiado es " + str(director))  # Imprime el resultado