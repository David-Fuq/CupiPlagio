#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    
    with open(archivo, "r", encoding="utf-8") as f:
        encabezado = f.readline().strip()
        
        datos = {}
        
        for linea in f:
            linea = linea.strip()
            partes = linea.split(",")
            
            rank = int(partes[0])
            cupituber = partes[1].strip()
            subscribers = int(partes[2])
            video_views = int(partes[3])
            video_count = int(partes[4])
            category = partes[5].strip()
            started = partes[6].strip()
            country = partes[7].strip()
            monetization_type = partes[8].strip()
            description = partes[9].strip()
            
            info = {
                "rank": rank,
                "cupituber": cupituber,
                "subscribers": subscribers,
                "video_views": video_views,
                "video_count": video_count,
                "category": category,
                "started": started,
                "monetization_type": monetization_type,
                "description": description
            }
            
            if country not in datos:
                datos[country] = []
            datos[country].append(info)
            
        return datos

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    resultado = []
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            
            if categoria == categoria_buscada :
                if suscriptores_min <= suscriptores <= suscriptores_max:
                    resultado.append(cupituber)
                    
    return resultado


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            monetizacion = cupituber["monetization_type"]
            
            if categoria == categoria_buscada:
                if monetizacion == monetizacion_buscada:
                    resultado.append(cupituber)
    else: pass
    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    cupituber_mas_antiguo = None
    fecha_mas_antigua = None
    
    for pais in cupitube: 
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            fecha_inicio = cupituber["started"]
            
            
            if fecha_mas_antigua is None:
                fecha_mas_antigua = fecha_inicio
                cupituber_mas_antiguo = cupituber
                
                
            else:
                if fecha_inicio < fecha_mas_antigua:
                    fecha_mas_antigua = fecha_inicio
                    cupituber_mas_antiguo = cupituber
                    
    return cupituber_mas_antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total_visitas = 0
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            if categoria == categoria_buscada:
                visitas = cupituber["video_views"]
                total_visitas = total_visitas + visitas
                
    return total_visitas
        

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {}
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            
            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = visitas
            else:
                visitas_por_categoria[categoria] += visitas
                
    categoria_mas_visitas = None
    max_visitas = -1
    
    for categoria in visitas_por_categoria:
        if visitas_por_categoria[categoria] > max_visitas:
          max_visitas = visitas_por_categoria[categoria]
          categoria_mas_visitas = categoria
        
    resultado = {
        "categoria": categoria_mas_visitas,
        "visitas": max_visitas
    }
    return resultado


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        
        for cupituber in lista_cupitubers:
            nombre = cupituber["cupituber"]
            
            nombre_limpio = ""
            for caracter in nombre:
                if caracter.isalnum():
                    nombre_limpio = nombre_limpio + caracter
                else:
                    pass
                
            if len(nombre_limpio) > 15:
                nombre_limpio = nombre_limpio[:15]
                
            nombre_limpio = nombre_limpio.lower()
            
            fecha = cupituber["started"]
            anio = fecha[:4]
            mes = fecha [5:7]
            
            ultimos_dos = anio[2:]
            
            correo = nombre_limpio + "." + ultimos_dos + mes + "@cupitube.com"
            
            cupituber["correo"] = correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    categoria_info = obtener_categoria_con_mas_visitas(cupitube)
    categoria_ganadora = categoria_info["categoria"]
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            suscriptores = cupituber["subscribers"]
            fecha_inicio = cupituber["started"]
            videos = cupituber["video_count"]
            descripcion = cupituber["description"]
            
            if categoria == categoria_ganadora:
                if suscriptores_min <= suscriptores <= suscriptores_max:
                    if fecha_minima <= fecha_inicio <= fecha_maxima:
                        if videos >= videos_minimos:
                            palabra_clave_min = palabra_clave.lower()
                            descripcion_min = descripcion.lower()
                            
                            if palabra_clave_min in descripcion_min:
                                return cupituber
                            
    return {}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias_paises = {}
    
    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"]
            if categoria not in categorias_paises:
                categorias_paises[categoria] = []
                
            if pais not in categorias_paises[categoria]:
                categorias_paises[categoria].append(pais)
                
    return categorias_paises