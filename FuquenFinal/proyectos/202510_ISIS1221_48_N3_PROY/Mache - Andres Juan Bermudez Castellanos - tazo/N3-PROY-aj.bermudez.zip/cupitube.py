def cargar_cupitube(archivo: str) -> dict:
    with open(archivo, "r", encoding = "utf-8") as file:
        lineas = file.readlines()
        diccionario_paises = {}
        for linea in lineas[1:]:
            datos = linea.strip().split(",")
            rank = int(datos[0])
            nombre = datos[1]
            subscribers = int(datos[2])
            video_views = int(datos[3])
            video_count = int(datos[4])
            category = datos[5]
            started = datos[6]
            country = datos[7]
            monetization_type = datos[8]
            description = datos[9]
            cupituber = {
                "rank": rank,
                "cupituber": nombre,
                "subscribers": subscribers,
                "video_views": video_views,
                "video_count": video_count,
                "category": category,
                "started": started,
                "monetization_type": monetization_type,
                "description": description
            }
            if country not in diccionario_paises:
                diccionario_paises[country] = []

            diccionario_paises[country].append(cupituber)

        return diccionario_paises

def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    cupituber_por_cat_y_ran_sus = []
    for valores in cupitube.values():
        for cupituber in valores:
            if cupituber["category"] == categoria_buscada:
                if suscriptores_min < int(cupituber["subscribers"]) < suscriptores_max:
                    cupituber_por_cat_y_ran_sus.append(cupituber)
    return cupituber_por_cat_y_ran_sus

def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cupituber_por_pais_cat_mone = []
    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if cupituber["category"] == categoria_buscada and cupituber["monetization_type"] == monetizacion_buscada:
                cupituber_por_pais_cat_mone.append(cupituber)
    return cupituber_por_pais_cat_mone

def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    fecha_inicio = None
    for valores in cupitube.values():
        for cupituber in valores:
            if fecha_inicio is None:
                fecha_inicio = cupituber
            if cupituber["started"] < fecha_inicio["started"]:
                fecha_inicio = cupituber
    return fecha_inicio


def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    num_visitas = 0 
    for valores in cupitube.values():
        for cupituber in valores:
            if categoria_buscada == cupituber["category"]:
                num_visitas += cupituber["video_views"]
    return num_visitas

def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    cat_mas_visitas = {}
    lista_de_cat = []
    visitas_max = 0
    for valores in cupitube.values():
        for cupituber in valores:
            categoria = cupituber["category"]
            if categoria not in lista_de_cat:
                obtener_visitas_por_categoria(cupitube, categoria)
                visitas = obtener_visitas_por_categoria(cupitube, categoria)
                if visitas > visitas_max:
                    visitas_max = visitas
                    categoria_max = categoria
    cat_mas_visitas["categoria"] = categoria_max
    cat_mas_visitas["visitas"] = visitas_max
    return cat_mas_visitas


def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for valores in cupitube.values():
        for cupituber in valores:
            nombre = cupituber["cupituber"]
            usuario = ""
            for letra in nombre:
                if letra.isalnum():
                    usuario += letra
            usuario = usuario[0:15].lower()
            usuario += "." 
            fecha = cupituber["started"]
            separar_fecha = fecha.split("-")
            anio = separar_fecha[0][2:4]
            mes = separar_fecha[1]
            correo = ""
            correo = usuario + anio + mes + "@cupitube.com"
            cupituber["correo"] = correo

def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    cupituber_recomendado = {}
    categoria = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    candidatos = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria)
    i = 0
    encontrado = False
    
    while i < len(candidatos) and not encontrado:
        cupituber = candidatos[i]
        numero_de_videos = cupituber["video_count"]
        fecha_inicio = cupituber["started"]
        descripcion = cupituber["description"].lower()
        
        if (videos_minimos <= numero_de_videos and 
            fecha_minima <= fecha_inicio <= fecha_maxima 
            and palabra_clave.lower() in descripcion):
            encontrado = True
            cupituber_recomendado = cupituber
        i += 1
    return cupituber_recomendado
    
    
  
def paises_por_categoria(cupitube: dict) -> dict:
    paises_por_categoria = {}
    for valores in cupitube:
        cupitubers_en_ese_pais = cupitube[valores]
        for cupituber in cupitubers_en_ese_pais:
            categoria = cupituber["category"]
            if categoria not in paises_por_categoria:
                paises_por_categoria[categoria] = []
                paises_por_categoria[categoria].append(valores)
            elif valores not in paises_por_categoria[categoria]:
                paises_por_categoria[categoria].append(valores)
    return paises_por_categoria


