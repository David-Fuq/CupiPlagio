#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(nombre_archivo: str) -> dict:
    archivo = open(nombre_archivo, "r", encoding="utf-8")
    archivo.readline() 
    datos = {}

    for linea in archivo:
        partes = linea.strip().split(",")
        pais = partes[7]
        cupituber = {
            "rank": int(partes[0]),
            "cupituber": partes[1],
            "subscribers": int(partes[2]),
            "video_views": int(partes[3]),
            "video_count": int(partes[4]),
            "category": partes[5],
            "started": partes[6],
            "country": partes[7],
            "monetization_type": partes[8],
            "description": partes[9]
        }

        if pais not in datos:
            datos[pais] = []
        datos[pais].append(cupituber)

    archivo.close()
    return datos


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    rango_suscriptores = []
    for pais in cupitube:
        for elemento in cupitube[pais]:
            if elemento["category"].lower() == categoria_buscada.lower() and suscriptores_min <= elemento["subscribers"] <= suscriptores_max:
                rango_suscriptores.append(elemento)
    return rango_suscriptores


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    categoria_monetizacion = []
    for pais in cupitube:
        if pais == pais_buscado: 
            for elemento in cupitube[pais]:
                if elemento["category"].lower() == categoria_buscada.lower() and elemento["monetization_type"].lower() == monetizacion_buscada.lower():
                   categoria_monetizacion.append(elemento)
    return categoria_monetizacion
            


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None
    for pais in cupitube:
        for elemento in cupitube[pais]:
            if mas_antiguo is None or elemento["started"] < mas_antiguo["started"]:
                mas_antiguo = elemento
    return mas_antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0
    for pais in cupitube:
        for elemento in cupitube[pais]:
            if elemento["category"].lower() == categoria_buscada.lower():
                total += elemento["video_views"]
    return total

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categoria = {}
    for pais in cupitube:
        for elemento in cupitube[pais]:
            cat = elemento["category"]
            if cat in categoria:
                categoria[cat] += elemento["video_views"]
            else:
                categoria[cat] = elemento["video_views"]
    max_cat = ""
    max_visitas = -1
    for cat in categoria:
        if categoria[cat] > max_visitas:
            max_cat = cat
            max_visitas = categoria[cat]
    return {"categoria": max_cat, "visitas": max_visitas}



# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
   validos = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
   for pais in cupitube:
       for elemento in cupitube[pais]:
           nombre = ""
           for ch in elemento["cupituber"]:
               if ch in validos:
                   nombre += ch
           nombre = nombre[:15].lower()
           fecha = elemento["started"]
           correo = nombre + "." + fecha[2:4] + fecha[5:7] + "@cupitube.com"
           elemento["correo"] = correo
    

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    categoria_recomendada = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    palabra_clave = palabra_clave.lower()
    for pais in cupitube:
        for elemento in cupitube[pais]:
            if (elemento["category"] == categoria_recomendada and
                suscriptores_min <= elemento["subscribers"] <= suscriptores_max and
                fecha_minima <= elemento["started"] <= fecha_maxima and
                elemento["video_count"] >= videos_minimos and
                palabra_clave in elemento["description"].lower()):
                return elemento

    return {}


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    pais_por_categoria = {}

    for pais in cupitube:
        for elemento in cupitube[pais]:
            categoria = elemento["category"]
            if categoria not in pais_por_categoria:
                pais_por_categoria[categoria] = []

            if pais not in pais_por_categoria[categoria]:
                pais_por_categoria[categoria].append(pais)

    return pais_por_categoria