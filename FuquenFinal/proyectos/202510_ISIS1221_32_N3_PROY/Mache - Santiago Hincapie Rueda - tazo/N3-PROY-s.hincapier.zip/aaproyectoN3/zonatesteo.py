#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 11:42:48 2025

@author: jesushincapie
"""

cupitube={}
cupituber={}
archivo=open("cupitube.csv","r",encoding="utf-8")
tipos_dato=archivo.readline().strip().split(",")
linea=archivo.readline().strip()


while len(linea)>0:
    
    info=linea.split(",")
    cupituber[tipos_dato[0]]=int(info[0])
    cupituber[tipos_dato[1]]=info[1]
    cupituber[tipos_dato[2]]=int(info[2])
    cupituber[tipos_dato[3]]=int(info[3])
    cupituber[tipos_dato[4]]=int(info[4])
    cupituber[tipos_dato[5]]=info[5]
    cupituber[tipos_dato[6]]=info[6]
    cupituber[tipos_dato[7]]=info[7]
    cupituber[tipos_dato[8]]=info[8]
    cupituber[tipos_dato[9]]=info[9]
    if cupituber[tipos_dato[7]] not in cupitube:
        cupitube[cupituber["country"]]=[]
    cupitube[cupituber["country"]]+=[cupituber]
    cupituber={}
    linea=archivo.readline().strip()


#otra funcion
#valores
suscriptores_min=222000000
suscriptores_max=222000001
categoria_buscada="Music"
fecha_maxima="2020-02-20"
fecha_minima="2004-02-24"
videos_minimos=100
palabra_clave="best"
#funcion
lista=[]
for cada_pais in cupitube:
    cada_lista=cupitube[cada_pais]
    for cupituber in cada_lista:
        if cupituber["subscribers"]<=suscriptores_max and cupituber["subscribers"]>=suscriptores_min and cupituber["category"]==categoria_buscada:
            lista.append(cupituber)
            
            
            
            
recomendacion={}            
i=0
find=False
while i<len(lista) and find==False:
    if fecha_maxima >= lista[i]["started"] >= fecha_minima and lista[i]["video_count"]>=videos_minimos and palabra_clave.lower() in lista[i]["description"].lower():
        find==True
        recomendacion=lista[i]
    i+=1
    
print(len(recomendacion))
print(recomendacion)
    
    
    
    
    
    