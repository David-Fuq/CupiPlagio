#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    datos = {}
    f = open(archivo, "r", encoding="utf-8")
    f.readline()
    linea = f.readline().strip()
    while linea != "":
        partes = linea.split(",")
        rank = int(partes[0].strip())
        cupituber = partes[1].strip()
        subscribers = int(partes[2].strip())
        video_views = int(partes[3].strip())
        video_count = int(partes[4].strip())
        category = partes[5].strip()
        started = partes[6].strip()
        country = partes[7].strip()
        monetization_type = partes[8].strip()
        description = partes[9].strip()
        info = {
            "rank": rank,
            "cupituber": cupituber,
            "subscribers": subscribers,
            "video_views": video_views,
            "video_count": video_count,
            "category": category,
            "started": started,
            "monetization_type": monetization_type,
            "description": description
        }
        if country not in datos:
            datos[country] = []
        datos[country].append(info)
        linea = f.readline().strip()
    f.close()
    return datos

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resultado = []
    for lista in cupitube.values():
        for ct in lista:
            if ct["category"] == categoria_buscada and suscriptores_min <= ct["subscribers"] <= suscriptores_max:
                resultado.append(ct)
    return resultado

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []
    if pais_buscado in cupitube:
        for ct in cupitube[pais_buscado]:
            if ct["category"] == categoria_buscada and ct["monetization_type"] == monetizacion_buscada:
                resultado.append(ct)
    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    primero = None
    for lista in cupitube.values():
        for ct in lista:
            if primero is None or ct["started"] < primero["started"]:
                primero = ct
    return primero

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0
    for lista in cupitube.values():
        for ct in lista:
            if ct["category"] == categoria_buscada:
                total += ct["video_views"]
    return total

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    cat_vistas = {}
    for lista in cupitube.values():
        for ct in lista:
            cat_vistas[ct["category"]] = obtener_visitas_por_categoria(cupitube,ct["category"],)

    max_cat = ""
    max_vistas = -1
    for cat, vistas in cat_vistas.items():
        if vistas > max_vistas:
            max_vistas = vistas
            max_cat = cat
    resultado = {"categoria": max_cat, "visitas": max_vistas}
    return resultado

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for lista in cupitube.values():
        for ct in lista:
            nombre_raw = ""
            for c in ct["cupituber"]:
                if c.isalnum():
                    nombre_raw += c
            nombre = nombre_raw[:15].lower()
            year = ct["started"][2:4]
            month = ct["started"][5:7]
            ct["correo"] = nombre + "." + year + month + "@cupitube.com"

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    top_cat = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    candidatos = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, top_cat)
    clave = palabra_clave.lower()
    recomendado = {}

    for ct in candidatos:
        cumple_videos = ct["video_count"] >= videos_minimos
        cumple_fecha = fecha_minima <= ct["started"] <= fecha_maxima
        cumple_palabra = clave in ct["description"].lower()

        if cumple_videos and cumple_fecha and cumple_palabra and recomendado == {}:
            recomendado = ct

    return recomendado

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    cat_paises = {}
    for country, lista in cupitube.items():
        for ct in lista:
            cat = ct["category"]
            if cat not in cat_paises:
                cat_paises[cat] = []
            if country not in cat_paises[cat]:
                cat_paises[cat].append(country)
    return cat_paises
