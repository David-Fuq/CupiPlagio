#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
def cargar_cupitube(archivo: str) -> dict:
    
    paises = {}
    arc = open(archivo, "r", encoding="utf-8")  # encoding="utf-8" para leer caracteres especiales
    arc.readline()  # Leemos la primera línea (encabezados) y la descartamos
   
    linea = arc.readline().strip()
    while linea != "":  # Mientras haya líneas para leer
        datos = linea.split(",")
        
        # Creamos el diccionario del cupituber directamente aquí
        ct = {
            "rank": int(datos[0]),
            "cupituber": datos[1],
            "subscribers": int(datos[2]),
            "video_views": int(datos[3]),
            "video_count": int(datos[4]),
            "category": datos[5],
            "started": datos[6],
            "country": datos[7],
            "monetization_type": datos[8],
            "description": datos[9]
        }
       
        pais = datos[7]
        if pais not in paises:
            paises[pais] = []
        paises[pais].append(ct)  # .append() agrega el diccionario ct a la lista de paises[pais]
        
        linea = arc.readline().strip()
    
    arc.close()
    return paises


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
   
    cupitubers_filtrados = []
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (cupituber["category"] == categoria_buscada and 
                suscriptores_min <= cupituber["subscribers"] <= suscriptores_max):
                cupitubers_filtrados.append(cupituber)
    
    return cupitubers_filtrados


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
  
   cupitubers_encontrados = []
   
   if pais_buscado in cupitube:
       for cupituber in cupitube[pais_buscado]:
           if (cupituber["category"] == categoria_buscada and 
               cupituber["monetization_type"] == monetizacion_buscada):
               cupitubers_encontrados.append(cupituber)
   
   return cupitubers_encontrados


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
  
   cupituber_mas_antiguo = None
   fecha_mas_antigua = None
   
   for pais in cupitube:
       for cupituber in cupitube[pais]:
           if fecha_mas_antigua is None:
               cupituber_mas_antiguo = cupituber
               fecha_mas_antigua = cupituber["started"]
           elif cupituber["started"] < fecha_mas_antigua:
               cupituber_mas_antiguo = cupituber
               fecha_mas_antigua = cupituber["started"]
   
   return cupituber_mas_antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
   
   total_visitas = 0
   
   for pais in cupitube:
       for cupituber in cupitube[pais]:
           if cupituber["category"] == categoria_buscada:
               total_visitas += cupituber["video_views"]
   
   return total_visitas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    categorias_visitas = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]
            visitas = cupituber["video_views"]
            
            if categoria in categorias_visitas:
                categorias_visitas[categoria] += visitas
            else:
                categorias_visitas[categoria] = visitas
    
    categoria_max = ""
    visitas_max = 0
    
    for categoria, visitas in categorias_visitas.items():
        if visitas > visitas_max:
            categoria_max = categoria
            visitas_max = visitas
    return {"categoria": categoria_max, "visitas": visitas_max}


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre = cupituber["cupituber"]
            
            nombre_limpio = ""
            for caracter in nombre:
                if caracter.isalnum():
                    nombre_limpio += caracter
            
            nombre_limpio = nombre_limpio[:15].lower()
            
            fecha_inicio = cupituber["started"]  
            partes_fecha = fecha_inicio.split("-")
            año = partes_fecha[0][-2:]  
            mes = partes_fecha[1] 
            
            correo = f"{nombre_limpio}.{año}{mes}@cupitube.com"
            
            cupituber["correo"] = correo


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
   
    categoria_mas_visitas = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    
    todos_cupitubers = []
    for pais in cupitube.values():
        for ct in pais:
            todos_cupitubers.append(ct)
    
    for ct in todos_cupitubers:
        if ct["category"] != categoria_mas_visitas:
            continue
        
        suscriptores = ct["subscribers"]
        if not (suscriptores_min <= suscriptores <= suscriptores_max):
            continue
        
        if ct["video_count"] < videos_minimos:
            continue
        
        fecha_ct = ct["started"]
        if fecha_ct < fecha_minima or fecha_ct > fecha_maxima:
            continue
        
        descripcion = ct["description"].lower()
        if palabra_clave.lower() not in descripcion:
            continue
        
        return ct
    
    return {}


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    
    categorias = {}
    
    for pais, cupitubers in cupitube.items():
        for ct in cupitubers:
            categoria = ct["category"]
            
            if categoria not in categorias:
                categorias[categoria] = []
            
            if pais not in categorias[categoria]:
                categorias[categoria].append(pais)
    
    return categorias
