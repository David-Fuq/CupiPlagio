#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
    
# Función 1:
def cargar_cupitube(archivo: str):
    
    cupitube = open(archivo, "r", encoding="utf-8")
    cupitube.readline()
    linea = []
    paises = {}
    linea = (cupitube.readline().strip().split(","))
    while linea != [""]:
        
        ct = {"rank": int(linea[0]), "cupituber": linea[1], "subscribers": int(linea[2]),
        "video_views": int(linea[3]), "video_count": int(linea[4]), "category": linea[5],
        "started": linea[6], "monetization_type": linea[8], "description": linea[9]}
        pais = linea[7]
        
        if pais not in paises:
            paises[pais] = []
        paises[pais].append(ct)
        
        
        linea = cupitube.readline().strip().split(",")
    
    cupitube.close()
    
    return paises

    
    
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    
    cumplen = []
    
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for ct in cupitubers:
            suscriptores = ct["subscribers"]
            if (suscriptores >= suscriptores_min) and (suscriptores <= suscriptores_max) and (ct["category"] == categoria_buscada):
                cumplen.append(ct)
    
    return cumplen


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    cumplen = []
    cupitubers = cupitube.get(pais_buscado)
    
    if cupitubers != None:
       for ct in cupitubers:
           if (ct["category"] == categoria_buscada) and (ct["monetization_type"] == monetizacion_buscada):
               cumplen.append(ct)
                                                         
                                                             
    return cumplen
    
    """
    Busca los CupiTubers de un país, categoría y tipo de monetización buscados.
    
    
        pais_buscado (str): País de origen buscado.
        categoria_buscada (str): Categoría buscada.
        monetizacion_buscada (str): Tipo de monetización buscada (monetization_type).
        
    Ejemplo:    
       Dado el país "UK", la categoría "Gaming" y el tipo de monetización "Crowdfunding",  hay un CupiTuber que cumpliría con estos criterios de búsqueda:
           [{'rank': 842, 'cupituber': 'TommyInnit', 'subscribers': 11800000, 'video_views': 1590238217, 'video_count': 289, 'category': 'Gaming', 'started': '2015-03-07', 'monetization_type': 'Crowdfunding', 'description': 'wEird fActs aND ExPERiments!'}]
       ATENCIÓN: Este solo es un ejemplo de consulta existosa en el dataset. Su función debe ser implementada para cualquier valor dado de: pais_buscado, categoria_buscada y monetizacion_buscada
        
    Retorno:
        list: Lista con el o los diccionarios de los CupiTubers que tienen como origen el país buscado, su categoría coincide con la categoría buscada y su tipo de monetización coincide con la monetización buscada.
                Si no se encuentra ningún CupiTuber o el país buscado no existe, se retorna una lista vacía.
    """

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    fecha = "2026"
    for pais in cupitube:
        cupitubers = cupitube[pais]
        
        for ct in cupitubers:
            if ct["started"] < fecha:
                fecha = ct["started"] 
                mas_antiguo = ct
                
    return mas_antiguo
    """
    Busca al CupiTuber más antiguo con base en la fecha de inicio (started).
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
    
    Retorno:
        dict: Diccionario con la información del CupiTuber más antiguo.
              En caso de empate (misma fecha de inicio o started), se retorna el primer CupiTuber encontrado.
    
    Nota:
        Las fechas de inicio de los CupiTubers ("started") en el dataset están en el formato "YYYY-MM-DD" (Año-Mes-Día).
        En Python, este formato permite que las fechas puedan compararse directamente como strings, ya que el orden lexicográfico coincide con el orden cronológico.
        
        Ejemplos de comparaciones:
            "2005-02-15" < "2006-06-10"  # → True (Porque 2005 es anterior a 2006)
            "2010-08-23" > "2009-12-31"  # → True (Porque 2010 es posterior a 2009)
            "2015-03-10" < "2015-03-20"  # → True (Mismo año y mes, pero el día 10 es anterior al día 20)
    """
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for ct in cupitubers:
            if ct["category"] == categoria_buscada:
                total += ct["video_views"]
    
    return total
            

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mas_visitas = {}
    categorias = {}
    
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for ct in cupitubers:
            categoria = ct["category"]
            if categoria not in categorias:
                categorias[categoria] = obtener_visitas_por_categoria(cupitube, categoria)
    visitas = 0           
    for c in categorias:
        v = categorias[c]
        if v > visitas:
            mas_visitas["categoria"] = c
            mas_visitas["visitas"] = v
            visitas = v
    
    return mas_visitas
    
    
"""

    Identifica la categoría con el mayor número de visitas (video_views) acumuladas.
    
    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.
        
    Retorno:
        dict: Diccionario con las siguientes llaves:
            - "categoria": Cuyo valor asociado es el nombre de la categoría con más visitas.
            - "visitas": cuyo valor asociado es la cantidad total de visitas de la categoría con más visitas.
        Si hay varias categorías con la misma cantidad máxima de visitas, se retorna la primera encontrada en el recorrido total del diccionario.
"""


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for ct in cupitubers:
            nombre = ct["cupituber"].lower().replace(" ", "")
            for c in nombre:
                if not str.isalnum(c):
                    nombre = nombre.replace(c, "")
            
            año = ct["started"][2:4]
            mes = ct["started"][5:7]
            
            ct["correo"] = nombre[:15] + "." + año + mes +"@cupitube.com"
            


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    recomendado = {}
    categoria_mas_vista = obtener_categoria_con_mas_visitas(cupitube)["categoria"]
    ct_base = buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria_mas_vista)
    
    pos = 0
    if ct_base != []:
        while recomendado == {} and (pos < len(ct_base)):
            ct = ct_base[pos]
            fecha = ct["started"]
            if (ct["video_count"] >= videos_minimos) and (fecha <= fecha_maxima) and (fecha >= fecha_minima) and (palabra_clave.lower() in ct["description"].lower()):
                recomendado = ct    
            pos += 1
        
    return recomendado


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    paises_c = {}
    
    
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for ct in cupitubers:
            categoria = ct["category"]
            if categoria not in paises_c:
                paises_c[categoria] = [pais]
                
            if pais not in paises_c[categoria]:
                paises_c[categoria].append(pais)
                
    return paises_c


"""
    Crea un diccionario que relaciona cada categoría de CupiTubers con una lista de países (sin duplicados) de origen de los CupiTubers en esa categoría.

    Parámetros:
        cupitube (dict): Diccionario con la información de los CupiTubers.

    Retorno:
        dict: Diccionario en el que las llaves son los nombres de las categorías y 
              los valores son listas de los nombres de los países (sin duplicados) que tienen al menos un CupiTuber en dicha categoría.

    Nota:
        - No se permiten países repetidos en la misma categoría.
        - Un país puede aparecer en varias categorías.
        - Cada categoría debe tener al menos un país asociado.
        - Por favor recuerde que el nombre un país en el dataset inicia con letra mayúscula, por ejemplo: "India"
    
    Ejemplo:    
       Al considerar la categoría (llave) "Music", la lista de países únicos asociados a esta sería:
           ['India', 'USA', 'Sweden', 'Russia', 'South Korea', 'Canada', 'Brazil', 'UK', 'Argentina', 'Poland', 'Saudi Arabia', 'Australia', 'Thailand', 'Spain', 'Indonesia', 'Mexico', 'France', 'Netherlands', 'Italy', 'Japan', 'Germany', 'South Africa', 'UAE', 'Turkey', 'China']
       ATENCIÓN: Este solo es un ejemplo de una de las categorías que se reportaría como llave en el diccionario resultado. 
       Su función debe reportar todas las categorías con su respectiva lista de países sin duplicados.
"""
