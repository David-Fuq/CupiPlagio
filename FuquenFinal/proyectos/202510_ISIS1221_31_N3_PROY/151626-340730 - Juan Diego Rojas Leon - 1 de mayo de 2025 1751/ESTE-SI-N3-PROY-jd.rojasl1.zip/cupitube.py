#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    dict_de_cupitubers = {}
    documento = open(archivo, "r", encoding="utf-8")
    titulos = documento.readline().strip().split(",")
    datos = documento.readline().strip().split(",")
    while len(datos) == len(titulos):
        cupituber = {}
        pais = datos[7]
        cupituber[titulos[0]] = int(datos[0])
        cupituber[titulos[1]] = datos[1]
        cupituber[titulos[2]] = int(datos[2])
        cupituber[titulos[3]] = int(datos[3])
        cupituber[titulos[4]] = int(datos[4])
        cupituber[titulos[5]] = datos[5]
        cupituber[titulos[6]] = datos[6]
        cupituber[titulos[8]] = datos[8]
        cupituber[titulos[9]] = datos[9]
        if pais in dict_de_cupitubers:
            dict_de_cupitubers[pais].append(cupituber)
        else:
            dict_de_cupitubers[pais] = [cupituber]
        datos = documento.readline().strip().split(",")
    
    documento.close()
    return dict_de_cupitubers



# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    lista_categoria_suscriptores = []
    for pais in cupitube:
        for cupituber in cupitube[pais]: 
            if cupituber["category"] == categoria_buscada and cupituber["subscribers"] >= suscriptores_min and cupituber["subscribers"] <= suscriptores_max:
                lista_categoria_suscriptores.append(cupituber)
    return lista_categoria_suscriptores



# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    lista_cumple = []
    for pais in cupitube:
        if pais == pais_buscado:
            for cupituber in cupitube[pais]:
                if categoria_buscada == cupituber["category"] and cupituber["monetization_type"] == monetizacion_buscada:
                    lista_cumple.append(cupituber)
    return lista_cumple


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    cupituber_mas_antiguo = None
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber_mas_antiguo == None:
                cupituber_mas_antiguo = cupituber
            else:
                if cupituber["started"] < cupituber_mas_antiguo["started"]:
                    cupituber_mas_antiguo = cupituber
    return cupituber_mas_antiguo
        


# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total_visitas = 0
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if categoria_buscada == cupituber["category"]:
                total_visitas += cupituber["video_views"]
    return total_visitas

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    categorias = {}
    
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria_actual = cupituber["category"]
            visitas_actuales = cupituber["video_views"]
            
            if categoria_actual in categorias:
                categorias[categoria_actual] += visitas_actuales
            else:
                categorias[categoria_actual] = visitas_actuales
    
    categoria_ganadora = ""
    maximo_visitas = 0
    
    for categoria in categorias:
        if categorias[categoria] > maximo_visitas:
            maximo_visitas = categorias[categoria]
            categoria_ganadora = categoria
    
    return {"category": categoria_ganadora, "video_views": maximo_visitas}






# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre = (cupituber["cupituber"]).lower()
            new_name = ""
            for letra in nombre:
                if letra.isalnum():
                    new_name += letra
            if len(new_name) > 15:
                new_name = new_name[:15]
                
            
            fecha = (cupituber["started"])
            fecha = fecha.replace("-","")
            fecha = fecha[2:6]
            
            correo = f"{new_name}.{fecha}@cupitube.com"
            
            cupituber["correo"] = correo

        
    


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int,
                         fecha_minima: str, fecha_maxima: str, videos_minimos: int,
                         palabra_clave: str) -> dict:
    cupituber_recomendado = {}
    categoria_mas_vistas = obtener_categoria_con_mas_visitas(cupitube)["category"]
    encontrado = False
    paises = list(cupitube.keys())
    indice_pais = 0

    while indice_pais < len(paises) and not encontrado:
        pais_actual = paises[indice_pais]
        canales = cupitube[pais_actual]
        indice_canal = 0

        while indice_canal < len(canales) and not encontrado:
            canal = canales[indice_canal]
            if (canal["category"] == categoria_mas_vistas and
                suscriptores_min <= canal["subscribers"] <= suscriptores_max and
                canal["video_count"] >= videos_minimos and
                fecha_minima <= canal["started"] <= fecha_maxima and
                palabra_clave.lower() in canal["description"].lower()):
                cupituber_recomendado = canal
                encontrado = True
            indice_canal += 1

        indice_pais += 1

    return cupituber_recomendado

   

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categoria_paises = {}
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"]

            if categoria not in categoria_paises:
                categoria_paises[categoria] = []

            if pais not in categoria_paises[categoria]:
                categoria_paises[categoria].append(pais)

    return categoria_paises
            
   