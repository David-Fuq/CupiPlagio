#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    diccionario_paises = {}

    with open(archivo, "r", encoding="utf-8") as lineas:
        linea1 = lineas.readline().strip()
        for linea in lineas:
            linea2 = linea.strip().split(',')
            pais = linea2[7].strip()
            diccionario_cupituber={'rank':int(linea2[0]),
                             'cupituber':str(linea2[1]),
                             'subscribers':int(linea2[2]),
                             'video_views':int(linea2[3]),
                             'video_count':int(linea2[4]),
                             'category':str(linea2[5]),
                             'started':str(linea2[6]),
                             'monetization_type':str(linea2[8]),
                             'description':str(linea2[9])
                             }
            if pais not in diccionario_paises:
                diccionario_paises[pais] = []
            diccionario_paises[pais].append(diccionario_cupituber)
    return diccionario_paises


def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    lista_cumplen = []
    for pais in cupitube:
        for x in cupitube[pais]:
            if categoria_buscada == x['category'] and suscriptores_min <= x['subscribers'] <= suscriptores_max:
                lista_cumplen.append(x)
    return lista_cumplen


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    lista_cumplen = []
    for pais in cupitube:
        if pais_buscado.strip().lower() == pais.strip().lower(): 
            for x in cupitube[pais]:
                if (categoria_buscada.strip().lower() == str(x['category']).strip().lower() and monetizacion_buscada.strip().lower()==str(x['monetization_type']).strip().lower()):
                    lista_cumplen.append(x)
    return lista_cumplen

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    final = None
    for pais in cupitube:
        for x in cupitube[pais]:
            if final == None or x['started'] < final['started']:
                final = x
    return final


# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total = 0
    for pais in cupitube:
        for x in cupitube[pais]:
            if categoria_buscada == x['category']:
                total += x['video_views']
    return total


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    mayor = {}
    mayor2 = {'categoria': '', 'visitas': 0}
    
    for pais in cupitube:
        for x in cupitube[pais]:
            categoria = x['category']
            if categoria not in mayor:
                mayor[categoria] = obtener_visitas_por_categoria(cupitube, categoria)
            if mayor[categoria] > mayor2['visitas']:
                mayor2['categoria'] = categoria
                mayor2['visitas'] = mayor[categoria]
    return mayor2


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for x in cupitube[pais]:
            fecha = x['started'].split('-')  
            año = fecha[0][-2:]  
            mes = fecha[1]      
            nombre = x['cupituber'].lower().strip()
            nombre2= ''
            i = 0
            while i < len(nombre) and len(nombre2) < 15:
                if nombre[i].isalnum():
                    nombre2 += nombre[i]
                i += 1
            correo = nombre2 + '.' + año + mes + '@cupitube.com'
            x['correo']=correo

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    categoria_top = obtener_categoria_con_mas_visitas(cupitube)['categoria']
    paises = list(cupitube.keys())
    i = 0
    encontrado = False
    resultado = {}

    while i < len(paises) and not encontrado:
        pais = paises[i]
        cupitubers = cupitube[pais]
        j = 0
        while j < len(cupitubers) and not encontrado:
            x = cupitubers[j]
            if (x['category'] == categoria_top and 
                suscriptores_min <= x['subscribers'] <= suscriptores_max and 
                fecha_minima <= x['started'] <= fecha_maxima and
                x['video_count'] >= videos_minimos and 
                palabra_clave.lower() in x['description'].lower()):
                resultado = x
                encontrado = True
            j += 1
        i += 1
    return resultado


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    origen = {}
    for pais in cupitube:
        for x in cupitube[pais]:
            categoria = x['category']
            if categoria not in origen:
                origen[categoria] = []
            if pais not in origen[categoria]: 
                origen[categoria].append(pais) 
    return origen


