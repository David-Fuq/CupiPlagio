#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitubers = {}
    archivo_csv = open(archivo, "r", encoding="utf-8")
    archivo_csv.readline()
    linea = archivo_csv.readline()
    while linea != "":
        linea = linea.strip()
        partes = linea.split(",")
        cupituber = {}
        cupituber["rank"] = int(partes[0])
        cupituber["cupituber"] = partes[1]
        cupituber["subscribers"] = int(partes[2])
        cupituber["video_views"] = int(partes[3])
        cupituber["video_count"] = int(partes[4])
        cupituber["category"] = partes[5]
        cupituber["started"] = partes[6]
        cupituber["monetization_type"] = partes[7]
        cupituber["description"] = partes[8]
        pais = partes[9]
        if pais in cupitubers:
            cupitubers[pais].append(cupituber)
        else:
            cupitubers[pais] = [cupituber]
        linea = archivo_csv.readline()
    return cupitubers

    #TODO 1: Implemente la función tal y como se describe en la documentación.
    


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resultado = []

    for pais in cupitube:
        cupitubers = cupitube[pais]

        for cupituber in cupitubers:
            categoria_actual = cupituber["category"]
            suscriptores_actuales = cupituber["subscribers"]

            cumple_categoria = categoria_actual == categoria_buscada
            dentro_del_rango = suscriptores_actuales >= suscriptores_min and suscriptores_actuales <= suscriptores_max

            if cumple_categoria:
                if dentro_del_rango:
                    resultado.append(cupituber)

    return resultado

    
    #TODO 2: Implemente la función tal y como se describe en la documentación.
    


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultado = []  

    if pais_buscado in cupitube: 
        for cupituber in cupitube[pais_buscado]: 
            if (cupituber["category"] == categoria_buscada and
                cupituber["monetization_type"] == monetizacion_buscada):
                resultado.append(cupituber) 
                
    return resultado
    #TODO 3: Implemente la función tal y como se describe en la documentación.
    


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    cupituber_mas_antiguo=None
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber_mas_antiguo is None:
                cupituber_mas_antiguo = cupituber
            elif cupituber["started"] < cupituber_mas_antiguo["started"]:
                cupituber_mas_antiguo = cupituber

    return cupituber_mas_antiguo
    #TODO 4: Implemente la función tal y como se describe en la documentación.
    
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total_visitas = 0

    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        
        for cupituber in lista_cupitubers:
            categoria_actual = cupituber["category"]
            visitas_actuales = cupituber["video_views"]
            
            if categoria_actual == categoria_buscada:
                total_visitas += visitas_actuales

    if total_visitas == 0:
        print(f"No se encontraron visitas para la categoría: {categoria_buscada}")
    else:
        print(f"El total de visitas acumuladas para la categoría '{categoria_buscada}' es: {total_visitas}")
    
    return total_visitas
    
    #TODO 5: Implemente la función tal y como se describe en la documentación.
    


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {} 
    mayor_categoria = None 
    mayor_visitas = 0 
    
    for pais in cupitube: 
        cupitubers_pais = cupitube[pais] 
        
        for cupituber in cupitubers_pais: 
            categoria_actual = cupituber["category"] 
            visitas_actuales = cupituber["video_views"]  
            
            if categoria_actual not in visitas_por_categoria:  
                visitas_por_categoria[categoria_actual] = visitas_actuales 
            else:
                visitas_por_categoria[categoria_actual] += visitas_actuales  

    for categoria, visitas in visitas_por_categoria.items(): 
        if visitas > mayor_visitas:  
            mayor_visitas = visitas  
            mayor_categoria = categoria  
    
    if mayor_categoria is not None: 
        print(f"La categoría con más visitas es '{mayor_categoria}', con un total de {mayor_visitas} visitas.")
    else:
        print("No se encontró ninguna categoría con visitas.")

    return {"categoria": mayor_categoria, "visitas": mayor_visitas} 
    #TODO 6: Implemente la función tal y como se describe en la documentación.
    pass


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for pais in cupitube:
        cupitubers = cupitube[pais]
        for datos in cupitubers:
            nombre_original = datos["cupituber"]
            fecha_inicio = datos["started"]

            nombre_limpio = ""
            for caracter in nombre_original:
                if caracter.isalnum():
                    nombre_limpio += caracter
            if len(nombre_limpio) > 15:
                nombre_limpio = nombre_limpio[:15]
            nombre_limpio = nombre_limpio.lower()

            partes_fecha = fecha_inicio.split("-")
            if len(partes_fecha) == 3:
                anio = partes_fecha[0]
                mes = partes_fecha[1]
                anio_final = anio[-2:]
                mes_final = mes
            else:
                anio_final = "00"
                mes_final = "00"

            correo = nombre_limpio + "." + anio_final + mes_final + "@cupitube.com"
            datos["correo"] = correo

            print("Se creó el correo para " + datos["cupituber"] + ": " + correo)
    
    #TODO 7: Implemente la función tal y como se describe en la documentación.

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    categoria_con_mas_visitas = obtener_categoria_con_mas_visitas(cupitube) 
    if categoria_con_mas_visitas["categoria"] is None:
        print("No se encontró una categoría con visitas suficientes para realizar la búsqueda.")
        return {}

    categoria_destacada = categoria_con_mas_visitas["categoria"]
    for pais in cupitube: 
        lista_cupitubers = cupitube[pais]
        for datos_cupituber in lista_cupitubers: 
            cumple_criterios = True  
            
            if datos_cupituber["category"] != categoria_destacada:
                cumple_criterios = False

            if not (suscriptores_min <= datos_cupituber["subscribers"] <= suscriptores_max): 
                cumple_criterios = False
            
            if not (fecha_minima <= datos_cupituber["started"] <= fecha_maxima): 
                cumple_criterios = False
            
            if datos_cupituber["video_count"] < videos_minimos: 
                cumple_criterios = False
            
            if palabra_clave.lower() not in datos_cupituber["description"].lower(): 
                cumple_criterios = False

            if cumple_criterios: 
                print("Se ha encontrado un CupiTuber que cumple los criterios:")
                print(f"Nombre: {datos_cupituber['cupituber']}")
                print(f"Categoría: {datos_cupituber['category']}")
                print(f"Suscriptores: {datos_cupituber['subscribers']}")
                print(f"Fecha de inicio: {datos_cupituber['started']}")
                print(f"Videos publicados: {datos_cupituber['videos']}")
                print(f"Descripción: {datos_cupituber['description']}")
                return datos_cupituber

    print("No se encontró ningún CupiTuber que cumpla con los criterios.")
    return {}
    #TODO 8: Implemente la función tal y como se describe en la documentación.
    


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias_paises = {}  

    for pais in cupitube:  
        lista_cupitubers = cupitube[pais] 
        for cupituber in lista_cupitubers:  
            categoria = cupituber["category"] 
            if categoria not in categorias_paises:
                categorias_paises[categoria] = [] 

            if pais not in categorias_paises[categoria]: 
                categorias_paises[categoria].append(pais) 

    return categorias_paises 
    
    #TODO 9: Implemente la función tal y como se describe en la documentación.
#Final ProyN3 s.rojasc234@uniandes.edu.co
#202410713
