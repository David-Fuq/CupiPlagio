#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    abrir=open(archivo, "r", encoding="utf-8")
    abrir.readline()
    datos_cupitubers={}
    for linea in abrir:
        cupituber={}
        datos=linea.strip("").split(",")
        pais=datos[7]
        cupituber["rank"]=int(datos[0])
        cupituber["cupituber"]=(datos[1])
        cupituber["subscribers"]=int(datos[2])
        cupituber["video_views"]=int(datos[3])
        cupituber["video_count"]=int(datos[4])
        cupituber["category"]=(datos[5])
        cupituber["started"]=(datos[6])
        cupituber["monetization_type"]=(datos[8])
        cupituber["description"]=(datos[9])
        if pais not in datos_cupitubers:
            datos_cupitubers[pais]=[cupituber]
        elif pais in datos_cupitubers:
            datos_cupitubers[pais].append(cupituber)
    abrir.close()
    return datos_cupitubers
        

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    lista=[]
    for paises_cupitubers in cupitube.values():
        for cupituber in paises_cupitubers:
            categoria=  cupituber["category"]
            suscriptores= cupituber["subscriibers"]
            if categoria==categoria_buscada and suscriptores>=suscriptores_min and suscriptores <= suscriptores_max:
                lista.append(cupituber)
    return lista


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    lista1=[]
    if pais_buscado in cupitube:
       for cupituber in cupitube [pais_buscado]:
           categoria = cupituber["category"]
           monetizacion = cupituber["monetization_type"]
           if categoria == categoria_buscada and monetizacion == monetizacion_buscada:
              lista1.append(cupituber)
    return lista1


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    datos= cupitube.values()
    cupituber_mas_antiguo={} 
    fecha_mas_antigua = cupituber_mas_antiguo["started"]
    for pais_cupitubers in datos:
        for cupituber in pais_cupitubers:
            if cupituber["started"] < fecha_mas_antigua:
               cupituber_mas_antiguo = cupituber
               fecha_mas_antigua = cupituber["started"]
               
    return cupituber_mas_antiguo
    
    

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    total_visitas = 0
    for paises_cupitubers in cupitube.values():
        for cupituber in paises_cupitubers:
            if cupituber["category"] == categoria_buscada:
                total_visitas += cupituber["video_views"]
    return total_visitas

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:

    visitas_por_categoria = {}

    for pais_cupitubers in cupitube.values():
        for cupituber in pais_cupitubers:
            categoria = cupituber["category"]
            vistas = cupituber["video_views"]
            if categoria in visitas_por_categoria:
                visitas_por_categoria[categoria] += vistas
            else:
                visitas_por_categoria[categoria] = vistas
    categoria_max = ""
    visitas_max = 0

    for categoria in visitas_por_categoria.keys():
        total_visitas = visitas_por_categoria[categoria]
        if total_visitas > visitas_max:
            visitas_max = total_visitas

    return {"categoria": categoria_max,
           "visitas": visitas_max}


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    for llave in cupitube.keys():
        cupitubers = cupitube[llave]
        for cupituber in cupitubers:
            nombre = cupituber["cupituber"].lower()
            #print(nombre)
            anio = cupituber["started"][2:4]
            mes = cupituber["started"][5:7]
            
            cupituber["correo"]=nombre+"."+str(anio)+str(mes)+"@cupitube.com"
        
            #print(cupituber["correo"])
            

     
            
            
            

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    for pais_cupitubers in cupitube.values():
        for cupituber in pais_cupitubers:
           
            suscriptores = cupituber["subscribers"]
            fecha_inicio = cupituber["started"]
            video_count = cupituber["video_count"]
            descripcion = cupituber["description"].lower() 

            if (obtener_categoria_con_mas_visitas == cupituber["category"] and suscriptores_min <= suscriptores <= suscriptores_max and video_count >= videos_minimos and fecha_minima <= fecha_inicio <= fecha_maxima and palabra_clave.lower() in descripcion):
                return cupituber  

    return {}

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias_paises = {}

    for pais_cupitubers in cupitube.values():
        for cupituber in pais_cupitubers:
            categoria = cupituber["category"]
            pais = cupituber["cupituber"]  

            if categoria not in categorias_paises:
                categorias_paises[categoria] = {}  
            categorias_paises[categoria][pais] = True
    for categoria in categorias_paises:
        paises_unicos = ""
        for pais in categorias_paises[categoria]:
            if paises_unicos:  
                paises_unicos += ", "
            paises_unicos += pais
        categorias_paises[categoria] = paises_unicos  

    return categorias_paises

