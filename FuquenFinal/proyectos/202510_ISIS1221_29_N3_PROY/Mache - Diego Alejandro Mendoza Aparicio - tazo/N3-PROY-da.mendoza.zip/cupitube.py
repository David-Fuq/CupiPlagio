# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    resultado = {}
    
    archivo= open("cupitube.csv", "r", encoding="utf-8")

    lineas = archivo.readlines()
        
    for linea in lineas[1:]:
            valores = linea.strip().split(',')
            
            cupituber = {
                "rank": int(valores[0].strip()),
                "cupituber": valores[1].strip(),
                "subscribers": int(valores[2].strip()),
                "video_views": int(valores[3].strip()),
                "video_count": int(valores[4].strip()),
                "category": valores[5].strip(),
                "started": valores[6].strip(),
                "monetization_type": valores[8].strip(),
                "description": valores[9].strip()
            }
            
            pais = valores[7].strip()
            
            if pais:
                if pais not in resultado:
                    resultado[pais] = []  
                resultado[pais].append(cupituber) 

    return resultado

    pass


# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    cumple = []
    
    for lista_cupitubers in cupitube.values():  
        for cupituber in lista_cupitubers: 
            categoria = cupituber.get("category", "")
            suscriptores = cupituber.get("subscribers", 0)
            
            if categoria == categoria_buscada and suscriptores_min <= suscriptores <= suscriptores_max:
                cumple.append(cupituber)

    return cumple

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    buscador = []
    if pais_buscado in cupitube:
        for cupituber in cupitube[pais_buscado]:
            if cupituber.get("category", "") == categoria_buscada and cupituber.get("monetization_type", "") == monetizacion_buscada:
                buscador.append(cupituber)
    return buscador
    pass


# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber
    return mas_antiguo if mas_antiguo is not None else {}
    pass
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total_visitas = 0

    for pais in cupitube:
       
        for cupituber in cupitube[pais]:
            
            if cupituber.get("category", "") == categoria_buscada:
                
                total_visitas += cupituber.get("video_views", 0)
    return total_visitas
    pass


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {}
    
    for pais in cupitube:
  
        for cupituber in cupitube[pais]:
           
            categoria = cupituber.get("category", "")
        
            visitas = cupituber.get("video_views", 0)
           
            if categoria in visitas_por_categoria:
                visitas_por_categoria[categoria] += visitas
            else:
                visitas_por_categoria[categoria] = visitas

  
    categoria_max = None
    visitas_max = 0
    
    for categoria, total in visitas_por_categoria.items():
       
        if categoria_max is None or total > visitas_max:
            categoria_max = categoria
            visitas_max = total
    
    return {"categoria": categoria_max, "visitas": visitas_max}
    pass


# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    for pais in cupitube:
        for cupi in cupitube[pais]:
            nom = cupi.get("cupituber", "")
            limpio = ""
            for letra in nom:
                if letra.isalnum():
                    limpio = limpio + letra

            limpio = limpio[:15]
            
            inicia = cupi.get("started", "")
            partes = inicia.split("-")
            if len(partes) >= 2:
                year = partes[0]
                month = partes[1]
            else:
                year = "0000"
                month = "00"
            
            yy = year[-2:]
            
            mm = month if len(month) == 2 else "0" + month
            
            correo = limpio.lower() + "." + yy + mm + "@cupitube.com"
            cupi["correo"] = correo
    pass


# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    categoria_info = obtener_categoria_con_mas_visitas(cupitube)
    categoria_mas = categoria_info.get("categoria", "")

    for pais in cupitube:
        for cupi in cupitube[pais]:
           
            if cupi.get("category", "") != categoria_mas:
                cumpler = False
            elif not (suscriptores_min <= cupi.get("subscribers", 0) <= suscriptores_max):
                cumpler = False
            elif cupi.get("video_count", 0) < videos_minimos:
                cumpler = False
            elif not (fecha_minima <= cupi.get("started", "") <= fecha_maxima):
                cumpler = False
            elif palabra_clave.lower() not in cupi.get("description", "").lower():
                cumpler = False
            else:
                cumpler = True
            
            if cumpler:
                return cupi
    return {}


# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    resulta = {}
    
    for pais in cupitube:
       
        for cupituber in cupitube[pais]:
          
            categoria = cupituber.get("category", "")
            
            if categoria:
              
                if categoria not in resulta:
                    resulta[categoria] = []
                
                if pais not in resulta[categoria]:
                    resulta[categoria].append(pais)
    
    return resulta
    pass
