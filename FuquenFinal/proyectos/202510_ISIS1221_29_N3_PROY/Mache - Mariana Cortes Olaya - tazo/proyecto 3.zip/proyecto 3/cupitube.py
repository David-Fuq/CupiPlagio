#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    resultado={}
    archivo= open ("cupitable.csv","r", encoding="utf-8")
    linea=archivo.readline().strip()
    categoria=linea.split(",")
    cupituber={
        "rank":int(categoria[0].strip()),
        "cupitube":str(categoria[1].strip()),
        "subscribers":int(categoria[2].strip()),
        "video_views":int(categoria[3].strip()),
        "video_count":int(categoria[4].strip()),
        "category":str(categoria[5].strip()),
        "started":str(categoria[6].strip()),
        "monetization_type":str(categoria[8].strip()),
        "description":str(categoria[9].strip()),
        }
    pais=cupituber[7].strip()
    
    if pais not in resultado:
        resultado[pais]=[]
        resultado[pais].append(cupituber)
        archivo.close()
        return resultado
   
# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    respuesta=[]
    for pais in cupitube:
        for i in range(len(cupitube["pais"])):
            x=cupitube["pais"][i]
            seguidores=x["subscribers"]
            categoria=x["category"].lower()
        if categoria==categoria_buscada and suscriptores_min<= seguidores<=suscriptores_max:
             respuesta.append(x)
        return respuesta
    
# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    respuesta=[]
    pais=pais_buscado
    if pais in cupitube:
        for i in cupitube["pais"]:
            monetizacion=i["monetization_type"].lower()
            categoria=i["category"].lower()
            if categoria_buscada.lower()==categoria and monetizacion_buscada.lower()==monetizacion:
                respuesta.append(cupitube)
            return respuesta
  
# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    respuesta={}
    fecha="0000-00-00"
    for pais in cupitube:
        for i in cupitube["pais"]:
            if cupitube["started"]<i:
                fecha==cupitube["started"]
                respuesta=cupitube
                return respuesta
            
# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    suma=0
    for pais in cupitube:
        for i in range(len(cupitube["pais"])):
            categoria=cupitube["category"].lower()
            if categoria_buscada.lower()==categoria[i]:
                suma=+categoria[i]["video_views"]
                return suma

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    respuesta={}
    for pais in cupitube:
        for i in range(len(cupitube["pais"])):
            categoria=cupitube["category"].lower()
            visitas=cupitube["video_views"]
            if categoria[i] not in respuesta:
                respuesta(categoria[i])==visitas
            else:
                respuesta(categoria[i])==visitas
                maximo_valor1=None
                maximo_valor=-1
                for categoria[i] in respuesta:
                    if maximo_valor1<respuesta[categoria[i]]:
                        maximo_valor1=categoria[i]
                        maximo_valor=respuesta[categoria[i]]
                        x={"categoria":maximo_valor1,"visitas":maximo_valor}
                        return x
                        
# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    caracteres="a, b, c, d, e, f, g, h, i, j, k, l, m, n, ñ, o, p, q, r, s, t, u, v, w, x, y, z"
    num="0,1,2,3,4,5,6,7,8,9"
    contador=0
    X={}
    Y={}
    Z={}
    for pais in cupitube:
        for i in range(len(cupitube["pais"])):
            nombre={cupitube["cupituber"].replace(" ","")}
        for i in nombre:
            if i not in caracteres and i not in num and i not in caracteres.capitalize():
                contador =+ 1
                if contador==0:
                    return nombre 
                elif len(nombre)<15:
                    maximo_caracteres=nombre[:15].lower()
                    X["maximo_caracteres"]=[]
                    fecha=cupitube["started"]
                    partes=fecha.split("-")
                    mes=partes[1]
                    anio=partes[0]
                    anio_digitos=anio[-2:]
                    Z["mes"]=[]
                    Y["anio_digitos"]=[]
                    correo=maximo_caracteres+anio_digitos+mes+"@cupitube.com"
                    (cupitube["correo"][i])=correo
                    
                    
# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    respuesta={}
    categoria_top= obtener_categoria_con_mas_visitas(cupitube)["category"]
    for pais in cupitube:
        for i in cupitube["pais"]:
            categoria=cupitube["category"].lower()
            visitas=cupitube["video_views"]
            if categoria==categoria_top:
                return categoria_top
            visitas_top=obtener_visitas_por_categoria(cupitube, categoria_top)
            if visitas_top==visitas:
                return categoria_top
            numero_suscriptores_rango=buscar_por_categoria_y_rango_suscriptores(cupitube, suscriptores_min, suscriptores_max, categoria_top)
            if i in numero_suscriptores_rango:
                if cupitube["video_views"]==visitas_top:
                    return i
                else: return None
                if numero_suscriptores_rango:
                    return numero_suscriptores_rango
                for i in numero_suscriptores_rango:
                    if cupitube["video_count"]>=videos_minimos:
                        return i
                    else: return None
                    for i in videos_minimos:
                        if fecha_minima<=cupitube["started"]<=fecha_maxima:
                            return i
                        else: return None
                        for i in fecha_minima:
                            if palabra_clave.lower() in cupitube["description"].lower():
                                return i
                respuesta[i]=[]
                return respuesta

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    pais_categoria={}
    for pais in cupitube:
        for i in range(len(cupitube["pais"])):
            categoria=cupitube[i]["category"].lower()
            pais_cupi=cupitube[i]["country"]
            if categoria not in pais_categoria:
                pais_categoria["categoria"]=[]
                if pais_cupi not in pais_categoria:
                    pais_categoria["categoria"].append(pais_cupi)
                    return pais_categoria
    
