#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""
import csv
archivo = r"./cupitube.csv"
# Función 1: 
def cargar_cupitube(archivo: str) -> dict:

    resultado = {}

    with open(archivo, newline='', encoding='utf-8') as f:
        lector = csv.DictReader(f)

        for fila in lector:
            pais = fila["country"].strip()

            if pais != "":
                cupituber = {
                    "rank": int(fila["rank"]),
                    "cupituber": fila["cupituber"].strip(),
                    "subscribers": int(fila["subscribers"]),
                    "video_views": int(fila["video_views"]),
                    "video_count": int(fila["video_count"]),
                    "category": fila["category"].strip(),
                    "started": fila["started"].strip(),
                    "monetization_type": fila["monetization_type"].strip(),
                    "description": fila["description"].strip()
                }

                if pais not in resultado:
                    resultado[pais] = []

                resultado[pais].append(cupituber)

    return resultado

# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    #Generamos la lista donde quedara todo
    resultado = []
    
    #Entramos a la seccion de Cupitubers usando dos for simultaneamente
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            #Creamos y inicializamos las variables que necesitamos para que funcione de manera adecuada
            categoria = cupituber["category"].strip().lower()
            suscriptores = cupituber["subscribers"]
            
            #Verificamos que se cumplan las condiciones
            if categoria == categoria_buscada.strip().lower() and (suscriptores >= suscriptores_min and suscriptores <= suscriptores_max):
                resultado.append(cupituber)

    return resultado

# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    
    resultado = []
    for cupituber in cupitube[pais_buscado]:
            #Variables para usar
            categoria = cupituber["category"].strip().lower()
            monetizacion  = cupituber["monetization_type"].strip().lower()

            if (categoria == categoria_buscada.strip().lower() and monetizacion == monetizacion_buscada.strip().lower()):
                resultado.append(cupituber)

    return resultado

# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    
    #Variables necesarias
        #Variable para almacenar al cupituber
    cupituber_mas_antiguo = None
        #Creamos una fecha demasiado distante para tener de referencia
    fecha_mas_antigua = "9999-12-31"

    #Ingresamos al directorio de Cupituer
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            #Creamos la variable de fecha
            fecha = cupituber["started"].strip()
            #Comparamos tal cual gracias a la lexicografia que tienen
            if (fecha < fecha_mas_antigua):
                #Asignamos valores nuevos para poder repetir el ciclo
                cupituber_mas_antiguo = cupituber
                fecha_mas_antigua = fecha
    
    return cupituber_mas_antiguo

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    
    sumatoria = 0

    for listas_cupitubers in cupitube.values():
        for cupitubers in listas_cupitubers:
            categoria = cupitubers["category"].strip().lower()
            views = cupitubers["video_views"]

            if (categoria == categoria_buscada.lower()):
                sumatoria += views
    
    return sumatoria

# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    
    #Creamos el dict temporal
    visitas_por_categoria = {}

    #Planteamos bucle para recorrer cada CupiTuber
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"].strip()
            visitas = int(cupituber["video_views"])

            #Estructura para creacion de diccionarios
                #Creamos el diccionario en caso de no estar
            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = visitas
                #Agregamos las views en caso de ya encontrarse :)
            else:
                visitas_por_categoria[categoria] += visitas

    #Buscar la categoria con mas visitas usando variables "vacias"
    categoria_max = ""
    views_max = 0

    #Estructura para hacer comparación y encontrar el mayor :)
    for categoria in visitas_por_categoria:
        #Comparamos si el valor es el maximo
        if (visitas_por_categoria[categoria] > views_max):
            #Si es correcto cambiar nombre y numero a nuevo mayor temporal/definitivo
            categoria_max = categoria
            views_max = visitas_por_categoria[categoria]

    return {"categoria":categoria_max,"visitas":views_max}

# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    
    #For para ingresar al directorio de Cupitubers
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            #Variable con el nombre original del cupituber
            nombre_por_defecto = cupituber["cupituber"]

            #Sistema de bucle que nada mas recopila caracteres alfanumericos del STR ##############################
                #Creamos variable donde almacenar nombre alfanumerico
            nombre_alfanumerico = ""
            for caracter in nombre_por_defecto:
                if caracter.isalnum() == True:
                    nombre_alfanumerico += caracter

            #Convertir el nombre alfanumerico a minusculas y recortamos a los 15 primeros caracteres
            nombre_definitivo = nombre_alfanumerico.lower()[:15]  


            #Sistema de parte fechas #################################################################################
                #Obtenemos fecha en variable
            fecha = cupituber["started"]
                #Separamos el año y mes
            año = fecha[:4]
            mes = fecha[5:7]
                #Obtener nada mas ultimos dos digitos del año y juntar al mes
            parte_fecha = año[-2:] + mes

            #Generamos correo #########################################################################################
            correo = (nombre_definitivo+"."+parte_fecha+"@cupitube.com")

            #Añadimos correo como nueva pareja llave-valor del diccionario cupituber #####################################

            cupituber["correo"] = correo

# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos:int, palabra_clave: str) -> dict:
    
    # Validamos que la palabra clave no esté vacía
    if palabra_clave.strip() == "":
        return {}

    # Obtenemos la categoría con más visitas
    categoria_mas_visitas = obtener_categoria_con_mas_visitas(cupitube)["categoria"].strip().lower()

    # Recorremos todos los cupitubers para encontrar el primero que cumpla los criterios
    for lista_cupitubers in cupitube.values():
        for cupituber in lista_cupitubers:
            categoria = cupituber["category"].strip().lower()
            suscriptores = cupituber["subscribers"]
            fecha_inicio = cupituber["started"]
            c_videos = cupituber["video_count"]
            descripcion = cupituber["description"].lower()

            if (
                categoria == categoria_mas_visitas and
                (suscriptores >= suscriptores_min and suscriptores <= suscriptores_max) and
                (fecha_inicio >= fecha_minima and fecha_inicio <= fecha_maxima) and
                c_videos >= videos_minimos and
                palabra_clave.lower() in descripcion
            ):
                return cupituber  # Retorna inmediatamente el primero que cumpla

    return {}  # Si no encuentra ninguno, devuelve un diccionario vacío

# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    # Generamos el diccionario general donde estarán todas las categorías
    resultado = {}

    # Ingresamos directamente la zona de cupitubers para poder generar el diccionario
    for pais, lista_cupitubers in cupitube.items():
        for cupituber in lista_cupitubers:
            # Creamos la variable que almacene dentro el cupituber
            categoria = cupituber.get("category", None)

            if categoria is not None:
                if categoria not in resultado:
                    resultado[categoria] = []

                if pais not in resultado[categoria]:
                    resultado[categoria].append(pais)

    return resultado