#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CupiTube
"""

# Función 1: 
def cargar_cupitube(archivo: str) -> dict:
    cupitubers_por_pais = {}
    
    f = open(archivo, "r", encoding="utf-8")
    titulos = f.readline().strip().split(",")
    
    
    linea = f.readline()
    while len(linea) > 0:
        datos = linea.strip().split(",")
        
        cupituber_info = {}
        cupituber_info["rank"] = int(datos[0])
        cupituber_info["cupituber"] = datos[1].strip()
        cupituber_info["subscribers"] = int(datos[2])
        cupituber_info["video_views"] = int(datos[3])
        cupituber_info["video_count"] = int(datos[4])
        cupituber_info["category"] = datos[5].strip()
        cupituber_info["started"] = datos[6].strip()
        cupituber_info["monetization_type"] = datos[8].strip()
        cupituber_info["description"] = datos[9].strip()
        
        pais = datos[7].strip()
        
        if pais not in cupitubers_por_pais:
            cupitubers_por_pais[pais] = []
        
        cupitubers_por_pais[pais].append(cupituber_info)
        
        linea = f.readline()
    
    f.close()
    return cupitubers_por_pais



# Función 2:
def buscar_por_categoria_y_rango_suscriptores(cupitube: dict, suscriptores_min: int, suscriptores_max: int, categoria_buscada: str) -> list:
    resultados = []

    for pais in cupitube:
        lista_cupitubers = cupitube[pais]
        for cupituber in lista_cupitubers:
            categoria_actual = cupituber["category"].strip().lower()
            categoria_busqueda = categoria_buscada.strip().lower()
            suscriptores = cupituber["subscribers"]

            if categoria_actual == categoria_busqueda and suscriptores_min <= suscriptores <= suscriptores_max:
                resultados.append(cupituber)

    return resultados


# Función 3:
def buscar_cupitubers_por_pais_categoria_monetizacion(cupitube: dict, pais_buscado: str, categoria_buscada: str, monetizacion_buscada: str) -> list:
    resultados = []

    if pais_buscado in cupitube:
        lista_cupitubers = cupitube[pais_buscado]
        for cupituber in lista_cupitubers:
            categoria_actual = cupituber["category"].strip().lower()
            categoria_busqueda = categoria_buscada.strip().lower()
            monetizacion_actual = cupituber["monetization_type"].strip().lower()
            monetizacion_busqueda = monetizacion_buscada.strip().lower()

            if categoria_actual == categoria_busqueda and monetizacion_actual == monetizacion_busqueda:
                resultados.append(cupituber)

    return resultados



# Función 4:
def buscar_cupituber_mas_antiguo(cupitube: dict) -> dict:
    mas_antiguo = None

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if mas_antiguo is None or cupituber["started"] < mas_antiguo["started"]:
                mas_antiguo = cupituber

    return mas_antiguo
            

# Función 5:
def obtener_visitas_por_categoria(cupitube: dict, categoria_buscada: str) -> int:
    total_visitas = 0

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if cupituber["category"].strip().lower() == categoria_buscada.strip().lower():
                total_visitas += cupituber["video_views"]

    return total_visitas


# Función 6:
def obtener_categoria_con_mas_visitas(cupitube: dict) -> dict:
    visitas_por_categoria = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"].strip()
            visitas = cupituber["video_views"]

            if categoria not in visitas_por_categoria:
                visitas_por_categoria[categoria] = 0
            visitas_por_categoria[categoria] += visitas

    categoria_max = None
    max_visitas = -1

    for categoria, visitas in visitas_por_categoria.items():
        if visitas > max_visitas:
            max_visitas = visitas
            categoria_max = categoria

    return {"categoria": categoria_max, "visitas": max_visitas}



# Funcion 7:
def crear_correo_para_cupitubers(cupitube: dict) -> None:
    """
    Crea un correo para cada CupiTuber y lo añade al diccionario original.
    """
    for pais in cupitube:
        for cupituber in cupitube[pais]:
            nombre = cupituber["cupituber"]
            started = cupituber["started"]

           
            nombre_limpio = ""
            contador = 0  

            for c in nombre:
                if c.isalnum():
                    if contador < 15:
                        nombre_limpio += c
                        contador += 1

            
            año = started[2:4]
            mes = started[5:7]

           
            correo = (nombre_limpio + "." + año + mes + "@cupitube.com").lower()

           
            cupituber["correo"] = correo



# Función 8:
def recomendar_cupituber(cupitube: dict, suscriptores_min: int, suscriptores_max: int, fecha_minima: str, fecha_maxima: str, videos_minimos: int, palabra_clave: str) -> dict:
    categoria_top = obtener_categoria_con_mas_visitas(cupitube)["categoria"]

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            if (cupituber["category"].strip().lower() == categoria_top.strip().lower() and
                suscriptores_min <= cupituber["subscribers"] <= suscriptores_max and
                int(cupituber["video_count"]) >= videos_minimos and
                fecha_minima <= cupituber["started"] <= fecha_maxima and
                palabra_clave.lower() in cupituber["description"].lower()):
                return cupituber

    return {}



# Función 9:
def paises_por_categoria(cupitube: dict) -> dict:
    categorias_paises = {}

    for pais in cupitube:
        for cupituber in cupitube[pais]:
            categoria = cupituber["category"].strip()
            if categoria not in categorias_paises:
                categorias_paises[categoria] = []
            if pais not in categorias_paises[categoria]:
                categorias_paises[categoria].append(pais)

    return categorias_paises

